# VAULTBRO

**VAULTBRO: A Java-Based Personal Expense Tracking and Budget Management System**

*Take Control. Stack Smarter.*

VAULTBRO is a Java Swing desktop application for recording income and expenses, setting monthly spending limits, tracking savings goals, and exporting financial reports in Philippine pesos (PHP). One TCP server stores all accounts in SQLite. FlatLaf provides the dark theme, JFreeChart renders the charts, and BCrypt hashes account passwords.

## Run the server and desktop client

Extract the ZIP first. The included JAR runs with Java 17 or later. The server needs a Java installation containing `keytool`. In Windows double-click **start-server.cmd**, then **start-client.cmd**. On macOS or Linux, open two terminals in the extracted folder and run these commands, respectively.

```sh
java -cp vaultbro.jar com.vaultbro.net.Server
java -jar vaultbro.jar
```

The server prints its database path and TCP port. Keep it running while clients use the app. The distribution includes an initialized, empty **vaultbro.db** next to the JAR. If the database is absent, the server creates it in its working directory. Profile photos live in **profile-images** beside it. For another location, pass `-Dvaultbro.db=/path/to/vaultbro.db` before `-cp` on the server command.

### Connect another desktop

On the server PC, use `ipconfig` (Windows) to find the IPv4 address of the active LAN adapter. After first server startup, copy **vaultbro.jar**, **server.cer**, **client.properties** and **start-client.cmd** to the other PC using a trusted transfer. Keep the database and **server-private** folder on the host. In the client's **client.properties**, set `server.host` to that IPv4 address, for example `192.168.1.25`. Both computers need network access to each other. Permit incoming TCP 4782 on the host's private-network firewall if required. Start the client from that folder. For a different port, use `-Dvaultbro.port=4783` on the server and set `server.port=4783` on each client.

The first startup generates the server's private identity and public certificate. Clients check that exact certificate during the TLS handshake. Back up **server-private** securely with the database. A replacement identity requires distributing the new **server.cer** to each client. A disconnected client can sign out and back in. Refresh a view to see changes from another device.

### SMS configuration and sign-in

The host sends codes through Twilio Programmable Messaging. Supply a Twilio account SID, auth token, and SMS-capable sender authorized for your destination. Set these in the server's environment. For one Windows PowerShell session, replace the placeholders and launch the server from that same window.

```powershell
$env:TWILIO_ACCOUNT_SID = "<your account SID>"
$env:TWILIO_AUTH_TOKEN = "<your auth token>"
$env:TWILIO_FROM = "<your Twilio sender in international format>"
.\start-server.cmd
```

On macOS/Linux, export the same three variables before starting the server. The server needs internet access to reach Twilio. SMS charges and delivery depend on the provider account and destination. Keep credentials on the host.

- **Create an account** — enter your details and cellphone, select **Send SMS code**, then enter the code and submit. Philippine `09XXXXXXXXX` numbers and their `+639XXXXXXXXX` form identify the same account. Other countries use international format.
- **Sign in** — enter a username, email, or cellphone plus the password. If an old numeric username matches a local-format number, use the full `+63` number for cellphone sign-in.
- **Forgot password?** — enter the linked number, request a code, enter it and confirm a new password. Codes expire after five minutes. Each code allows five guesses and one successful use. Request another after 60 seconds. Restarting the server clears pending codes.
- **Existing accounts** — sign in with your original username or email, then open **Account Settings → Link a recovery cellphone** and verify it by SMS. A previously unlinked account needs this step before phone recovery works.

### Bring over your old database

Before starting the new server, close every copy of the old app. Back up the entire old folder (Windows: `%USERPROFILE%\.vaultbro`, macOS/Linux: `~/.vaultbro`). In a fresh extraction, replace the supplied empty **vaultbro.db** with the old **vaultbro.db**. Copy any **vaultbro.db-wal**, **vaultbro.db-shm**, **vaultbro.db-journal**, and **profile-images** from that same closed installation alongside it. Start the server. It upgrades the original version-1 schema in a transaction and preserves account IDs and financial records. Once this server contains new records, replacing its database would discard them. To back up the server, stop it and copy its data and identity together.

### Run source in VS Code or Maven

Open the folder containing `pom.xml` using JDK 17+ and the VS Code Extension Pack for Java. In Run and Debug, launch **VAULTBRO TCP Server**, then **VAULTBRO Swing Client**. With Maven, run `mvn clean package` and use `target/vaultbro.jar` in the commands above, keeping the project root as the working directory.

## Dashboard controls

Use **Add income** or **Add expense** on the Transactions page. **Export CSV** saves the rows currently displayed, in their current sort order. Select a savings goal to see its progress, deadline, and contribution and withdrawal history. The Budgets page highlights current-month warnings, and the Reports overview supports a year filter and a separate chart expense filter.

## Data and calculations

- Money is stored as integer centavos. Balance is income minus expenses. Savings activity is recorded in a separate ledger and shown as contributions minus withdrawals.
- Category limits count that category's expenses for the selected calendar month. The overall limit counts all expenses for the month once. A budget is **Near Limit** at 80% through 100%, and **Over Budget** above 100%. The notification bell surfaces budget warnings, prioritizes the current month, and lists overdue savings goals.
- Goal progress uses cumulative savings. The suggested weekly and monthly amounts round partial periods up and round the recommended amount up to a centavo. If the deadline is today or has passed, the goal shows the outstanding amount due. Overfunded goals display the amount above target.
- Date and month filters use inclusive boundaries. Reports apply the date range to transactions and savings activity. Budget reports show whole months overlapping the range, and savings goal reports show current balances. All six exports carry a generation timestamp.
- Report files use UTF-8. CSV includes report metadata before the data header. When importing into a spreadsheet, start at the data header on row 3. Formula-like user text is prefixed with an apostrophe for safe spreadsheet import.

## Testing

Run the automated integration tests with:

```sh
mvn test
```

The suite uses temporary on-disk SQLite files. It checks account edits and password changes, persistence, cross-account access, transaction and budget changes, savings history, concurrent withdrawal protection, all six exports, and backup of an unrecognized schema.

Use a separate test database for a manual desktop check.

1. Register an account. Check duplicate and invalid signup details, an incorrect login, and sign-in with the registered email.
2. Add an income of **₱1,500.00** and a current-month grocery expense of **₱800.00**. Check that the dashboard balance is **₱700.00**. Search and sort the table, switch the type and date filters, then open the expense details.
3. Create a **₱1,000.00** overall budget and a **₱1,000.00** grocery budget for the current month. Each should show 80% and **Near Limit**. Edit the grocery expense to **₱1,001.00**. Both budgets should show **Over Budget**, and the overall amount spent should be **₱1,001.00**.
4. Create a **₱2,000.00** savings goal, contribute **₱1,000.00**, then withdraw **₱250.00**. The goal should show **₱750.00** saved, **₱1,250.00** remaining, and 37.5% progress. A withdrawal greater than **₱750.00** should fail. Check the history and the unchanged transaction balance.
5. In **Reports & Analytics**, select a date or month filter and export each of the six formats. Open the files and verify generation dates, amounts, and the report scope.
6. Update your profile and password. Log out, create a second account, and verify it has an empty dashboard. Restart VAULTBRO and sign in to the first account to check persistence.

## Code organization and OOP

| Package | Responsibilities |
| --- | --- |
| `model` | Encapsulated transaction classes and immutable account, budget, goal and ledger models |
| `database` | SQLite connections, constraints, schema initialization and backups |
| `dao` | Prepared statements and account-scoped persistence |
| `controller` | Authentication, session state, financial validation and coordination |
| `ui` | Swing windows, reusable forms, tables, navigation and charts |
| `service` | Financial summaries, profile images and report exports |
| `util` | Theme, shared Swing controls, password hashing and form validation |

`Income` and `Expense` inherit from the abstract `Transaction` class and override `getType()` and `getSignedAmount()`. Calculations process a `List<Transaction>` using the shared interface. The overloaded `FinanceController.searchTransactions` methods support simple search and combined filters. `FinanceController` is composed with DAO dependencies and delegates SQL operations to them.
