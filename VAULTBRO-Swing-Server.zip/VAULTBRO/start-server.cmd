@echo off
cd /d "%~dp0"
java -cp vaultbro.jar com.vaultbro.net.Server
if errorlevel 1 pause
