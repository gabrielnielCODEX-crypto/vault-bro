package com.vaultbro.service;

import com.vaultbro.controller.FinanceOperations;
import com.vaultbro.model.*;
import java.sql.SQLException;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public final class FinancialCalculationService {
    public record Totals(long income, long expenses, long balance, long savings) {}
    public record MonthSummary(YearMonth month, long income, long expenses, long savingsActivity) {
        public long balance() { return income - expenses; }
    }

    public record Report(DateRange range, Totals totals, List<Transaction> transactions,
                         List<BudgetUsage> budgets, List<SavingsGoal> goals, List<GoalEntry> history,
                         List<MonthSummary> months, Map<String, Long> categories) {}

    private final FinanceOperations finance;

    public FinancialCalculationService(FinanceOperations finance) { this.finance = finance; }

    public Report report(DateRange range) throws SQLException {
        List<Transaction> transactions = finance.searchTransactions("", null, null, range);
        List<BudgetUsage> budgets = finance.budgets().stream()
                .filter(usage -> range.overlaps(usage.budget().period())).toList();
        List<SavingsGoal> goals = finance.goals();
        List<GoalEntry> history = finance.goalHistory(null).stream().filter(entry -> range.includes(entry.date())).toList();
        return new Report(range, totals(transactions, goals), transactions, budgets, goals, history,
                months(transactions, history, range), expenseCategories(transactions));
    }

    public static Totals totals(List<Transaction> transactions, List<SavingsGoal> goals) {
        long income = 0;
        long expenses = 0;
        long balance = 0;
        for (Transaction transaction : transactions) {
            long signed = transaction.getSignedAmount();
            if (signed > 0) income += signed;
            else expenses -= signed;
            balance += signed;
        }
        return new Totals(income, expenses, balance, goals.stream().mapToLong(SavingsGoal::savedAmount).sum());
    }

    public static Map<String, Long> expenseCategories(List<Transaction> transactions) {
        Map<String, Long> categories = new TreeMap<>();
        transactions.stream().filter(transaction -> transaction.getType() == Transaction.Type.EXPENSE)
                .forEach(transaction -> categories.merge(transaction.getCategory(), transaction.getAmount(), Long::sum));
        Map<String, Long> sorted = new LinkedHashMap<>();
        categories.entrySet().stream().sorted(Map.Entry.<String, Long>comparingByValue().reversed())
                .forEach(entry -> sorted.put(entry.getKey(), entry.getValue()));
        return Collections.unmodifiableMap(sorted);
    }

    public static List<MonthSummary> months(List<Transaction> transactions, List<GoalEntry> entries, DateRange range) {
        Map<YearMonth, MonthSummary> months = new TreeMap<>();
        for (Transaction transaction : transactions) {
            YearMonth month = YearMonth.from(transaction.getDate());
            MonthSummary previous = months.getOrDefault(month, emptyMonth(month));
            long signed = transaction.getSignedAmount();
            months.put(month, new MonthSummary(month, previous.income() + Math.max(0, signed),
                    previous.expenses() - Math.min(0, signed), previous.savingsActivity()));
        }
        for (GoalEntry entry : entries) {
            YearMonth month = YearMonth.from(entry.date());
            MonthSummary previous = months.getOrDefault(month, emptyMonth(month));
            months.put(month, new MonthSummary(month, previous.income(), previous.expenses(),
                    previous.savingsActivity() + entry.signedAmount()));
        }
        if (range.from() != null && range.to() != null) {
            YearMonth last = YearMonth.from(range.to());
            for (YearMonth month = YearMonth.from(range.from()); !month.isAfter(last); month = month.plusMonths(1)) {
                months.putIfAbsent(month, emptyMonth(month));
            }
        }
        return List.copyOf(months.values());
    }

    public static List<MonthSummary> trailingMonths(List<MonthSummary> data, YearMonth last, int count) {
        Map<YearMonth, MonthSummary> lookup = new TreeMap<>();
        for (MonthSummary month : data) lookup.put(month.month(), month);
        List<MonthSummary> result = new ArrayList<>();
        for (int offset = count - 1; offset >= 0; offset--) {
            YearMonth month = last.minusMonths(offset);
            result.add(lookup.getOrDefault(month, emptyMonth(month)));
        }
        return result;
    }

    private static MonthSummary emptyMonth(YearMonth month) { return new MonthSummary(month, 0, 0, 0); }
}
