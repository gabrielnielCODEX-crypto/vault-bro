package com.vaultbro.controller;

import com.vaultbro.model.*;
import java.sql.SQLException;
import java.util.List;

public interface FinanceOperations {
    List<Transaction> searchTransactions(String search) throws SQLException;
    List<Transaction> searchTransactions(String search, Transaction.Type type, String category, DateRange range)
            throws SQLException;
    void saveTransaction(Transaction.Type type, long id, String description, String category, String amount,
                                String date) throws SQLException;
    void deleteTransaction(long id) throws SQLException;
    List<BudgetUsage> budgets() throws SQLException;
    void saveBudget(long id, String category, String limit, String period) throws SQLException;
    void deleteBudget(long id) throws SQLException;
    List<SavingsGoal> goals() throws SQLException;
    List<GoalEntry> goalHistory(Long goalId) throws SQLException;
    void saveGoal(long id, String name, String category, String amount, String date) throws SQLException;
    void deleteGoal(long id) throws SQLException;
    void addGoalEntry(long goalId, GoalEntry.Type type, String amount, String date, String description)
            throws SQLException;
}
