package com.vaultbro.controller;

import com.vaultbro.dao.UserDAO;
import com.vaultbro.model.User;
import com.vaultbro.service.ProfileImages;
import com.vaultbro.util.PasswordUtil;
import com.vaultbro.util.ValidationUtil;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.sql.SQLException;

public final class AuthService {
    private static final String DUMMY_HASH = "$2a$12$8lqoUs2GVl2vRlcw1NZTlOSdr3SX7aws1p02KzfEDNvXoMRL1Ne66";
    private final UserDAO users;
    private final SessionManager session;
    private final ProfileImages images;

    public AuthService(UserDAO users, SessionManager session, ProfileImages images) {
        this.users = users;
        this.session = session;
        this.images = images;
    }

    public void register(String name, String username, String email, char[] password, char[] confirmation)
            throws SQLException {
        register(name, username, email, null, password, confirmation);
    }

    public void register(String name, String username, String email, String phone, char[] password, char[] confirmation)
            throws SQLException {
        name = ValidationUtil.required(name, "Full name", 100);
        username = ValidationUtil.username(username);
        email = ValidationUtil.email(email);
        users.create(name, username, email, PasswordUtil.hash(password, confirmation), phone);
    }

    public User authenticate(String login, char[] password) throws SQLException {
        return authenticateCredentials(login, password).user();
    }

    public UserDAO.Credentials authenticateCredentials(String login, char[] password) throws SQLException {
        login = ValidationUtil.required(login, "Username or email", 254);
        if (password.length == 0) throw new IllegalArgumentException("Enter your password.");
        var credentials = users.byLogin(login);
        boolean valid = PasswordUtil.verify(password, credentials.map(UserDAO.Credentials::passwordHash).orElse(DUMMY_HASH));
        if (!valid || credentials.isEmpty()) throw new IllegalArgumentException("Incorrect sign-in details.");
        return credentials.get();
    }

    public void startSession(User user) { session.set(user); }

    public void updateProfile(String name, String username, String email, BufferedImage picture, boolean removePicture)
            throws SQLException, IOException {
        User active = session.user();
        name = ValidationUtil.required(name, "Full name", 100);
        username = ValidationUtil.username(username);
        email = ValidationUtil.email(email);
        boolean replaceImage = picture != null || removePicture;
        String image = picture == null ? null : images.save(active.id(), picture);
        UserDAO.ProfileUpdate saved;
        try {
            saved = users.updateProfile(active.id(), name, username, email, replaceImage, image);
        } catch (SQLException | IllegalArgumentException exception) {
            if (image != null) images.remove(active.id(), image);
            throw exception;
        }
        session.set(saved.user());
        if (replaceImage) images.remove(active.id(), saved.previousImage());
    }

    public void changePassword(long userId, char[] current, char[] password, char[] confirmation) throws SQLException {
        if (session.user().id() != userId) throw new IllegalStateException("Sign in again to change your password.");
        var credentials = users.byId(userId);
        if (!PasswordUtil.verify(current, credentials.passwordHash())) {
            throw new IllegalArgumentException("The current password is incorrect.");
        }
        users.changePassword(userId, credentials.passwordHash(), PasswordUtil.hash(password, confirmation));
    }

    public void logout() { session.clear(); }
}
