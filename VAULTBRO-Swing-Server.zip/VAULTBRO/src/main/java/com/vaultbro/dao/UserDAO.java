package com.vaultbro.dao;

import com.vaultbro.database.Database;
import com.vaultbro.model.User;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;

public final class UserDAO {
    public record Credentials(User user, String passwordHash) {}
    public record ProfileUpdate(User user, String previousImage) {}

    private final Database database;

    public UserDAO(Database database) { this.database = database; }

    public Optional<Credentials> byLogin(String login) throws SQLException {
        try (var connection = database.open();
             var query = connection.prepareStatement("SELECT * FROM users WHERE username = ? OR email = ? OR phone = ? ORDER BY (username = ?) DESC LIMIT 1")) {
            query.setString(1, login);
            query.setString(2, login);
            query.setString(3, com.vaultbro.net.Phone.optional(login));
            query.setString(4, login);
            try (var result = query.executeQuery()) {
                return result.next() ? Optional.of(read(result)) : Optional.empty();
            }
        }
    }

    public Credentials byId(long userId) throws SQLException {
        try (var connection = database.open();
             var query = connection.prepareStatement("SELECT * FROM users WHERE id = ?")) {
            query.setLong(1, userId);
            try (var result = query.executeQuery()) {
                if (!result.next()) throw new IllegalArgumentException("Your account is no longer available.");
                return read(result);
            }
        }
    }

    public void create(String name, String username, String email, String hash, String phone) throws SQLException {
        try (var connection = database.open(); var query = connection.prepareStatement("""
                INSERT INTO users(full_name, username, email, password_hash, phone) VALUES (?, ?, ?, ?, ?)
                """)) {
            query.setString(1, name);
            query.setString(2, username);
            query.setString(3, email);
            query.setString(4, hash);
            query.setString(5, phone);
            query.executeUpdate();
        } catch (SQLException exception) {
            throw DaoErrors.duplicate(exception, "That username, email address, or phone number is already registered.");
        }
    }

    public ProfileUpdate updateProfile(long userId, String name, String username, String email,
                                       boolean replaceImage, String image) throws SQLException {
        try (var connection = database.open(); var before = connection.prepareStatement(
                "SELECT profile_image_path FROM users WHERE id = ?"); var update = connection.prepareStatement("""
                UPDATE users SET full_name = ?, username = ?, email = ?, profile_image_path = ?,
                updated_at = CURRENT_TIMESTAMP WHERE id = ?
                """)) {
            connection.setAutoCommit(false);
            before.setLong(1, userId);
            String previousImage;
            try (var result = before.executeQuery()) {
                if (!result.next()) throw new IllegalArgumentException("Your account is no longer available.");
                previousImage = result.getString(1);
            }
            String savedImage = replaceImage ? image : previousImage;
            update.setString(1, name);
            update.setString(2, username);
            update.setString(3, email);
            update.setString(4, savedImage);
            update.setLong(5, userId);
            DaoErrors.found(update.executeUpdate());
            connection.commit();
            return new ProfileUpdate(new User(userId, name, username, email, savedImage), previousImage);
        } catch (SQLException exception) {
            throw DaoErrors.duplicate(exception, "That username, email address, or phone number is already registered.");
        }
    }

    public void changePassword(long userId, String previousHash, String newHash) throws SQLException {
        try (var connection = database.open(); var query = connection.prepareStatement("""
                UPDATE users SET password_hash = ?, updated_at = CURRENT_TIMESTAMP
                WHERE id = ? AND password_hash = ?
                """)) {
            query.setString(1, newHash);
            query.setLong(2, userId);
            query.setString(3, previousHash);
            if (query.executeUpdate() == 0) {
                throw new IllegalArgumentException("Your password changed in another session. Sign in again and retry.");
            }
        }
    }

    private static Credentials read(ResultSet row) throws SQLException {
        User user = new User(row.getLong("id"), row.getString("full_name"), row.getString("username"),
                row.getString("email"), row.getString("profile_image_path"));
        return new Credentials(user, row.getString("password_hash"));
    }
}
