package com.vaultbro.net;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.awt.image.BufferedImage;
import java.nio.ByteBuffer;

// Each field is length-prefixed UTF-8. Requests and responses carry no executable types.
final class Wire {
    static void write(OutputStream stream, List<String> fields) throws IOException {
        DataOutputStream out = new DataOutputStream(stream);
        out.writeInt(fields.size());
        for (String field : fields) {
            byte[] data = field.getBytes(StandardCharsets.UTF_8);
            out.writeInt(data.length);
            out.write(data);
        }
        out.flush();
    }

    static List<String> read(InputStream stream, int maxFields, int maxBytes) throws IOException {
        DataInputStream in = new DataInputStream(stream);
        int count = in.readInt();
        if (count < 0 || count > maxFields) throw new IOException("Invalid field count.");
        List<String> fields = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            int size = in.readInt();
            if (size < 0 || size > maxBytes) throw new IOException("Message exceeds the size limit.");
            byte[] bytes = new byte[size];
            in.readFully(bytes);
            maxBytes -= size;
            fields.add(new String(bytes, StandardCharsets.UTF_8));
        }
        return fields;
    }

    static String image(BufferedImage image) {
        if (image == null) return "";
        ByteBuffer data = ByteBuffer.allocate(256 * 256 * 4);
        data.asIntBuffer().put(image.getRGB(0, 0, 256, 256, null, 0, 256));
        return Base64.getEncoder().encodeToString(data.array());
    }

    static BufferedImage image(String value) {
        if (value.isEmpty()) return null;
        byte[] data = Base64.getDecoder().decode(value);
        if (data.length != 256 * 256 * 4) throw new IllegalArgumentException("Invalid profile photo size.");
        int[] pixels = new int[256 * 256];
        ByteBuffer.wrap(data).asIntBuffer().get(pixels);
        BufferedImage image = new BufferedImage(256, 256, BufferedImage.TYPE_INT_ARGB);
        image.setRGB(0, 0, 256, 256, pixels, 0, 256);
        return image;
    }
    static String value(Object o) { return o == null ? "" : o instanceof Enum<?> e ? e.name() : o.toString(); }
    static List<String> fields(Object... values) { return Arrays.stream(values).map(Wire::value).toList(); }
}
