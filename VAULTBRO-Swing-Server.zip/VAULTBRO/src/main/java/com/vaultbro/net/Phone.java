package com.vaultbro.net;

public final class Phone {
    private Phone() {}
    public static String optional(String value) {
        String phone = value.strip().replaceAll("[ ()-]", "");
        if (phone.matches("09[0-9]{9}")) phone = "+63" + phone.substring(1);
        return phone.matches("\\+[1-9][0-9]{7,14}") ? phone : null;
    }
    static String required(String value) {
        String phone = optional(value);
        if (phone == null) throw new IllegalArgumentException("Use 09XXXXXXXXX or a number with its +country code.");
        return phone;
    }
}
