package com.vaultbro.net;

import java.net.*;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.time.Duration;
import java.util.*;

final class SmsCodes {
    interface Sender { void send(String phone, String message) throws Exception; }
    private record Challenge(String purpose, String account, String code, long expires, int attempts) {}
    private final Map<String, Challenge> codes = new HashMap<>();
    private final Map<String, Long> recent = new HashMap<>();
    private final ArrayDeque<Long> sends = new ArrayDeque<>();
    private final SecureRandom random = new SecureRandom();
    private final Sender sender;
    SmsCodes(Sender sender) { this.sender = sender; }

    void issue(String purpose, String phone, String account, boolean eligible) throws Exception {
        String code = String.format(Locale.ROOT, "%06d", random.nextInt(1_000_000));
        Challenge challenge;
        synchronized (this) {
            long now = System.currentTimeMillis();
            recent.values().removeIf(t -> now - t >= 60_000);
            codes.values().removeIf(c -> c.expires() <= now);
            while (!sends.isEmpty() && now - sends.peek() >= 3_600_000) sends.remove();
            if (recent.containsKey(phone)) return;
            if (sends.size() >= 100) throw new IllegalArgumentException("SMS limit reached. Try again later.");
            recent.put(phone, now);
            sends.add(now);
            if (!eligible) return;
            challenge = new Challenge(purpose, account, code, now + 300_000, 5);
            codes.put(phone, challenge);
        }
        try { sender.send(phone, "VAULTBRO " + purpose + " code: " + code + ". Expires in 5 minutes. Do not share it."); }
        catch (Exception e) {
            synchronized (this) { codes.remove(phone, challenge); recent.remove(phone); }
            throw new IllegalArgumentException("SMS delivery is unavailable. Check the server's SMS configuration or try later.");
        }
    }
    synchronized void consume(String purpose, String phone, String account, String supplied) {
        Challenge c = codes.get(phone);
        if (c != null && c.expires() > System.currentTimeMillis() && c.purpose().equals(purpose) && c.account().equals(account)) {
            codes.remove(phone);
            if (MessageDigest.isEqual(c.code().getBytes(StandardCharsets.UTF_8), supplied.getBytes(StandardCharsets.UTF_8))) return;
            if (c.attempts() > 1) codes.put(phone, new Challenge(purpose, account, c.code(), c.expires(), c.attempts()-1));
        }
        throw new IllegalArgumentException("Invalid or expired SMS code. Request a new code if needed.");
    }

    static Sender twilio() {
        HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();
        return (phone, body) -> {
            String sid = System.getenv("TWILIO_ACCOUNT_SID"), token = System.getenv("TWILIO_AUTH_TOKEN"), from = System.getenv("TWILIO_FROM");
            if (sid == null || !sid.matches("AC[0-9a-fA-F]{32}") || token == null || from == null) throw new IllegalStateException();
            String basic = Base64.getEncoder().encodeToString((sid + ":" + token).getBytes(StandardCharsets.UTF_8));
            var request = HttpRequest.newBuilder(URI.create("https://api.twilio.com/2010-04-01/Accounts/" + sid + "/Messages.json"))
                    .timeout(Duration.ofSeconds(12)).header("Authorization", "Basic " + basic)
                    .header("Content-Type", "application/x-www-form-urlencoded")
                    .POST(HttpRequest.BodyPublishers.ofString("To=" + encode(phone) + "&From=" + encode(from) + "&Body=" + encode(body))).build();
            if (http.send(request, HttpResponse.BodyHandlers.discarding()).statusCode() != 201) throw new IllegalStateException();
        };
    }
    private static String encode(String s) { return URLEncoder.encode(s, StandardCharsets.UTF_8); }
}
