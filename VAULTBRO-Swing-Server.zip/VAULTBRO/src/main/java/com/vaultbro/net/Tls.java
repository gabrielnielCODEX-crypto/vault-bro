package com.vaultbro.net;

import java.nio.file.*;
import java.security.*;
import java.security.cert.*;
import java.util.*;
import javax.net.ssl.*;

final class Tls {
    static SSLContext server(Path directory) throws Exception {
        Path keys = directory.resolve("server-private");
        if (keys.getFileSystem().supportedFileAttributeViews().contains("posix")) {
            Files.createDirectories(keys, java.nio.file.attribute.PosixFilePermissions.asFileAttribute(
                    java.nio.file.attribute.PosixFilePermissions.fromString("rwx------")));
        } else Files.createDirectories(keys);
        Path password = keys.resolve("store-password.txt");
        Path store = keys.resolve("identity.p12");
        if (!Files.exists(store)) {
            if (!Files.exists(password)) Files.writeString(password, UUID.randomUUID().toString(), StandardOpenOption.CREATE_NEW);
            String tool = System.getProperty("os.name").startsWith("Windows") ? "keytool.exe" : "keytool";
            ProcessBuilder builder = new ProcessBuilder(Path.of(System.getProperty("java.home"), "bin", tool).toString(),
                    "-genkeypair", "-alias", "vaultbro", "-keyalg", "RSA", "-keysize", "3072", "-validity", "3650",
                    "-dname", "CN=VAULTBRO Server", "-storetype", "PKCS12", "-keystore", store.toString(),
                    "-storepass:env", "VAULTBRO_KEY_PASSWORD");
            builder.environment().put("VAULTBRO_KEY_PASSWORD", Files.readString(password).strip());
            if (builder.inheritIO().start().waitFor() != 0) throw new IllegalStateException("Server key creation failed.");
        }
        char[] pass = Files.readString(password).strip().toCharArray();
        KeyStore identity = KeyStore.getInstance(store.toFile(), pass);
        Files.write(directory.resolve("server.cer"), identity.getCertificate("vaultbro").getEncoded());
        var km = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        km.init(identity, pass);
        SSLContext context = SSLContext.getInstance("TLS");
        context.init(km.getKeyManagers(), null, null);
        Arrays.fill(pass, '\0');
        return context;
    }

    static SSLContext client(Path certificate) throws Exception {
        X509Certificate expected;
        try (var in = Files.newInputStream(certificate)) {
            expected = (X509Certificate) CertificateFactory.getInstance("X.509").generateCertificate(in);
        }
        X509TrustManager pin = new X509TrustManager() {
            public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[]{expected}; }
            public void checkClientTrusted(X509Certificate[] chain, String type) throws CertificateException {
                throw new CertificateException("Client certificates unsupported.");
            }
            public void checkServerTrusted(X509Certificate[] chain, String type) throws CertificateException {
                if (chain.length == 0 || !expected.equals(chain[0])) throw new CertificateException("Server certificate mismatch.");
                expected.checkValidity();
            }
        };
        SSLContext context = SSLContext.getInstance("TLS");
        context.init(null, new TrustManager[]{pin}, null);
        return context;
    }
}
