package com.vaultbro.net;

import com.vaultbro.controller.*;
import com.vaultbro.model.*;
import com.vaultbro.service.ProfileImages;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.sql.SQLException;
import java.time.*;
import java.util.*;
import java.util.function.Function;
import javax.net.ssl.*;

public final class Client implements FinanceOperations {
    private final String host;
    private final int port;
    private final Path certificate;
    private final SessionManager session;
    private SSLSocket socket;
    private BufferedInputStream input;
    private BufferedOutputStream output;
    private BufferedImage photo;
    public final ProfileImages images = new ProfileImages(Path.of(".")) {
        @Override public BufferedImage load(long id, String name) { return photo; }
    };

    public Client(String host, int port, Path certificate, SessionManager session) {
        this.host = host;
        this.port = port;
        this.certificate = certificate;
        this.session = session;
    }

    synchronized List<String> call(Object... args) throws SQLException {
        List<String> result;
        try {
            if (socket == null) {
                if (!Files.isRegularFile(certificate)) throw new IOException("Copy server.cer from your server into the client folder.");
                socket = (SSLSocket) Tls.client(certificate).getSocketFactory().createSocket();
                socket.connect(new InetSocketAddress(host, port), 5000);
                socket.setSoTimeout(20000);
                socket.startHandshake();
                input = new BufferedInputStream(socket.getInputStream());
                output = new BufferedOutputStream(socket.getOutputStream());
            }
            Wire.write(output, Wire.fields(args));
            result = Wire.read(input, 8_000_000, 128_000_000);
        } catch (Exception e) {
            disconnect();
            throw new IllegalStateException("Connection to " + host + ":" + port + " failed. " + e.getMessage()
                    + " Check the server and sign in again. Refresh before repeating a save.", e);
        }
        if (!result.get(0).equals("ok")) throw new IllegalArgumentException(result.get(1));
        return result.subList(1, result.size());
    }
    private synchronized void disconnect() {
        try { if (socket != null) socket.close(); } catch (IOException ignored) {}
        socket = null;
    }
    public void logout() { disconnect(); session.clear(); photo = null; }
    private User user(List<String> row) {
        photo = Wire.image(row.get(5));
        return new User(num(row,0), row.get(1), row.get(2), row.get(3), row.get(4).isEmpty() ? null : row.get(4));
    }
    public User authenticate(String login, char[] password) throws SQLException {
        return user(call("login", login, new String(password)));
    }
    public void sendCode(String purpose, String phone) throws SQLException { call(purpose + "-code", phone); }
    public void register(String name, String handle, String email, String phone, String code, char[] password, char[] confirm) throws SQLException {
        call("register", name, handle, email, phone, code, new String(password), new String(confirm));
    }
    public void recover(String phone, String code, char[] password, char[] confirm) throws SQLException {
        call("reset", phone, code, new String(password), new String(confirm));
    }
    public void link(String phone, String code) throws SQLException { call("link", phone, code); }
    public void changePassword(long id, char[] current, char[] password, char[] confirm) throws SQLException {
        call("password", new String(current), new String(password), new String(confirm));
    }
    public void updateProfile(String name, String username, String email, BufferedImage image, boolean remove) throws SQLException {
        session.set(user(call("profile", name, username, email, Wire.image(image), remove)));
    }
    private static long num(List<String> row, int i) { return Long.parseLong(row.get(i)); }
    private static <T> List<T> rows(List<String> fields, int width, Function<List<String>, T> decode) {
        List<T> list = new ArrayList<>(fields.size() / width);
        for (int i = 0; i < fields.size(); i += width) list.add(decode.apply(fields.subList(i, i + width)));
        return list;
    }
    public List<Transaction> searchTransactions(String search) throws SQLException {
        return searchTransactions(search, null, null, DateRange.ALL);
    }
    public List<Transaction> searchTransactions(String search, Transaction.Type type, String category, DateRange range) throws SQLException {
        return rows(call("transactions", search, type, category, range.from(), range.to()), 6,
                r -> TransactionFactory.create(Transaction.Type.valueOf(r.get(0)), num(r,1), r.get(2), r.get(3), num(r,4), LocalDate.parse(r.get(5))));
    }
    public void saveTransaction(Transaction.Type type, long id, String description, String category, String amount, String date) throws SQLException {
        call("save-transaction", type, id, description, category, amount, date);
    }
    public void deleteTransaction(long id) throws SQLException { call("delete-transaction", id); }
    public List<BudgetUsage> budgets() throws SQLException {
        return rows(call("budgets"), 5, r -> new BudgetUsage(new Budget(num(r,0),r.get(1),num(r,2),YearMonth.parse(r.get(3))),num(r,4)));
    }
    public void saveBudget(long id, String category, String limit, String period) throws SQLException { call("save-budget",id,category,limit,period); }
    public void deleteBudget(long id) throws SQLException { call("delete-budget",id); }
    public List<SavingsGoal> goals() throws SQLException {
        return rows(call("goals"),6,r -> new SavingsGoal(num(r,0),r.get(1),r.get(2),num(r,3),LocalDate.parse(r.get(4)),num(r,5)));
    }
    public void saveGoal(long id,String name,String category,String amount,String date) throws SQLException { call("save-goal",id,name,category,amount,date); }
    public void deleteGoal(long id) throws SQLException { call("delete-goal",id); }
    public List<GoalEntry> goalHistory(Long id) throws SQLException {
        return rows(call("history",id),7,r -> new GoalEntry(num(r,0),num(r,1),r.get(2),GoalEntry.Type.valueOf(r.get(3)),num(r,4),LocalDate.parse(r.get(5)),r.get(6)));
    }
    public void addGoalEntry(long id,GoalEntry.Type type,String amount,String date,String description) throws SQLException {
        call("add-entry",id,type,amount,date,description);
    }
}
