package com.vaultbro.net;

import com.vaultbro.controller.*;
import com.vaultbro.dao.*;
import com.vaultbro.database.Database;
import com.vaultbro.model.*;
import com.vaultbro.service.ProfileImages;
import com.vaultbro.util.PasswordUtil;
import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.sql.*;
import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.Semaphore;
import javax.net.ssl.*;

public final class Server {
    public static void main(String[] args) throws Exception {
        Path file = Path.of(System.getProperty("vaultbro.db", "vaultbro.db")).toAbsolutePath().normalize();
        Database db = new Database(file);
        db.initialize();
        var tls = Tls.server(file.getParent());
        int port = Integer.getInteger("vaultbro.port", 4782);
        var sms = new SmsCodes(SmsCodes.twilio());
        var slots = new Semaphore(64);
        try (var listener = tls.getServerSocketFactory().createServerSocket(port)) {
            System.out.println("VAULTBRO server listening on TCP port " + port + "\nSQLite: " + file);
            while (true) {
                Socket socket = listener.accept();
                if (!slots.tryAcquire()) { socket.close(); continue; }
                Thread worker = new Thread(() -> {
                    try (socket) {
                        socket.setSoTimeout(30 * 60_000);
                        new ConnectionHandler(db, sms).serve(socket);
                    } catch (IOException ignored) {
                        // Client disconnected, timed out, or rejected the certificate.
                    } finally { slots.release(); }
                });
                worker.start();
            }
        }
    }

    static final class ConnectionHandler {
        private final Database db;
        private final SmsCodes sms;
        private final SessionManager session = new SessionManager();
        private final UserDAO users;
        private final AuthService auth;
        private final FinanceController finance;
        private final ProfileImages images;
        private String sessionHash;

        ConnectionHandler(Database db, SmsCodes sms) {
            this.db = db;
            this.sms = sms;
            users = new UserDAO(db);
            images = new ProfileImages(db.directory());
            auth = new AuthService(users, session, images);
            finance = new FinanceController(session, new TransactionDAO(db), new BudgetDAO(db), new GoalDAO(db));
        }

        void serve(Socket socket) throws IOException {
            var in = new BufferedInputStream(socket.getInputStream());
            var out = new BufferedOutputStream(socket.getOutputStream());
            while (true) {
                List<String> request = Wire.read(in, 12, 370_000);
                List<String> response = new ArrayList<>();
                try {
                    response.add("ok");
                    execute(request, response);
                } catch (IllegalArgumentException | IllegalStateException e) {
                    response = List.of("error", Objects.toString(e.getMessage(), "Invalid request."));
                } catch (Exception e) {
                    System.err.println("Request failed (" + e.getClass().getSimpleName() + ").");
                    response = List.of("error", "The server could not complete this request.");
                }
                Wire.write(out, response);
            }
        }

        private String accountPhone(long id) throws SQLException {
            try (var conn = db.open(); var q = conn.prepareStatement("SELECT phone FROM users WHERE id=?")) {
                q.setLong(1, id);
                try (var r = q.executeQuery()) { return r.next() ? r.getString(1) : null; }
            }
        }
        private UserDAO.Credentials phoneOwner(String phone) throws SQLException {
            var found = users.byLogin(phone);
            return found.isPresent() && phone.equals(accountPhone(found.get().user().id())) ? found.get() : null;
        }
        private void user(List<String> out, User u) {
            out.addAll(Wire.fields(u.id(), u.fullName(), u.username(), u.email(), u.profileImagePath(),
                    Wire.image(images.load(u.id(), u.profileImagePath()))));
        }
        private void execute(List<String> a, List<String> out) throws Exception {
            String op = a.get(0);
            switch (op) {
                case "login" -> {
                    auth.logout();
                    var credentials = auth.authenticateCredentials(a.get(1), a.get(2).toCharArray());
                    User u = credentials.user();
                    sessionHash = credentials.passwordHash();
                    auth.startSession(u);
                    user(out, u);
                    return;
                }
                case "signup-code", "reset-code" -> {
                    String phone = Phone.required(a.get(1));
                    var owner = phoneOwner(phone);
                    boolean reset = op.equals("reset-code");
                    sms.issue(reset ? "reset" : "registration", phone, reset && owner != null ? owner.passwordHash() : "",
                            reset ? owner != null : owner == null);
                    return;
                }
                case "register" -> {
                    String phone = Phone.required(a.get(4));
                    sms.consume("registration", phone, "", a.get(5));
                    auth.register(a.get(1), a.get(2), a.get(3), phone, a.get(6).toCharArray(), a.get(7).toCharArray());
                    return;
                }
                case "reset" -> {
                    String phone = Phone.required(a.get(1));
                    var owner = phoneOwner(phone);
                    sms.consume("reset", phone, owner == null ? "" : owner.passwordHash(), a.get(2));
                    users.changePassword(owner.user().id(), owner.passwordHash(), PasswordUtil.hash(a.get(3).toCharArray(), a.get(4).toCharArray()));
                    return;
                }
            }
            long id = session.user().id();
            if (!users.byId(id).passwordHash().equals(sessionHash)) {
                auth.logout();
                throw new IllegalStateException("Your password changed. Sign in again.");
            }
            switch (op) {
                case "link-code", "link" -> {
                    String phone = Phone.required(a.get(1));
                    if (accountPhone(id) != null) throw new IllegalArgumentException("Your account already has a recovery number.");
                    if (op.equals("link-code")) sms.issue("link", phone, id + ":" + sessionHash, phoneOwner(phone) == null);
                    else {
                        sms.consume("link", phone, id + ":" + sessionHash, a.get(2));
                        try (var conn = db.open(); var q = conn.prepareStatement("UPDATE users SET phone=? WHERE id=? AND phone IS NULL AND password_hash=?")) {
                            q.setString(1, phone); q.setLong(2, id); q.setString(3,sessionHash);
                            if (q.executeUpdate() != 1) throw new IllegalStateException("Account changed. Sign in again.");
                        }
                    }
                }
                case "password" -> {
                    if (!PasswordUtil.verify(a.get(1).toCharArray(), sessionHash)) throw new IllegalArgumentException("Incorrect current password.");
                    String next = PasswordUtil.hash(a.get(2).toCharArray(), a.get(3).toCharArray());
                    users.changePassword(id, sessionHash, next);
                    sessionHash = next;
                }
                case "profile" -> {
                    auth.updateProfile(a.get(1), a.get(2), a.get(3), Wire.image(a.get(4)), Boolean.parseBoolean(a.get(5)));
                    user(out, session.user());
                }
                case "transactions" -> {
                    var range = new DateRange(date(a.get(4)), date(a.get(5)));
                    var type = a.get(2).isEmpty() ? null : Transaction.Type.valueOf(a.get(2));
                    for (var t : finance.searchTransactions(a.get(1), type, a.get(3).isEmpty() ? null : a.get(3), range))
                        out.addAll(Wire.fields(t.getType(), t.getId(), t.getDescription(), t.getCategory(), t.getAmount(), t.getDate()));
                }
                case "save-transaction" -> finance.saveTransaction(Transaction.Type.valueOf(a.get(1)), number(a,2), a.get(3), a.get(4), a.get(5), a.get(6));
                case "delete-transaction" -> finance.deleteTransaction(number(a,1));
                case "budgets" -> {
                    for (var u : finance.budgets()) {
                        Budget b = u.budget();
                        out.addAll(Wire.fields(b.id(), b.category(), b.monthlyLimit(), b.period(), u.spent()));
                    }
                }
                case "save-budget" -> finance.saveBudget(number(a,1), a.get(2), a.get(3), a.get(4));
                case "delete-budget" -> finance.deleteBudget(number(a,1));
                case "goals" -> {
                    for (var g : finance.goals()) out.addAll(Wire.fields(g.id(), g.name(), g.category(), g.targetAmount(), g.targetDate(), g.savedAmount()));
                }
                case "save-goal" -> finance.saveGoal(number(a,1), a.get(2), a.get(3), a.get(4), a.get(5));
                case "delete-goal" -> finance.deleteGoal(number(a,1));
                case "history" -> {
                    for (var e : finance.goalHistory(a.get(1).isEmpty() ? null : number(a,1)))
                        out.addAll(Wire.fields(e.id(), e.goalId(), e.goalName(), e.type(), e.amount(), e.date(), e.description()));
                }
                case "add-entry" -> finance.addGoalEntry(number(a,1), GoalEntry.Type.valueOf(a.get(2)), a.get(3), a.get(4), a.get(5));
                default -> throw new IllegalArgumentException("Unknown operation.");
            }
        }
        private static long number(List<String> a, int i) { return Long.parseLong(a.get(i)); }
        private static LocalDate date(String s) { return s.isEmpty() ? null : LocalDate.parse(s); }
    }
}
