package com.vaultbro.ui;

import com.vaultbro.controller.SessionManager;
import com.vaultbro.net.Client;
import com.vaultbro.service.FinancialCalculationService;
import com.vaultbro.util.Ui;
import java.nio.file.*;
import java.util.Properties;
import javax.swing.*;

public final class Main {
    private final SessionManager session = new SessionManager();
    private final Client client;
    private Main(Properties settings) {
        client = new Client(settings.getProperty("server.host", "localhost").strip(),
                Integer.parseInt(settings.getProperty("server.port", "4782").strip()), Path.of("server.cer"), session);
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Ui.setup();
            try {
                Properties settings = new Properties();
                Path config = Path.of("client.properties");
                if (Files.exists(config)) try (var in = Files.newInputStream(config)) { settings.load(in); }
                new Main(settings).showLogin();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Check client.properties. " + e.getMessage());
            }
        });
    }
    private void showLogin() {
        new LoginFrame(client, user -> {
            session.set(user);
            new MainFrame(session, client, client, new FinancialCalculationService(client), client.images, this::showLogin).setVisible(true);
        }).setVisible(true);
    }
}
