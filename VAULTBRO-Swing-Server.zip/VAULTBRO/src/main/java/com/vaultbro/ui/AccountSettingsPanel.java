package com.vaultbro.ui;

import com.vaultbro.net.Client;
import com.vaultbro.controller.SessionManager;
import com.vaultbro.service.ProfileImages;
import com.vaultbro.util.Ui;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.Arrays;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;

final class AccountSettingsPanel extends JPanel implements MainFrame.View {
    private final MainFrame owner;
    private final Client auth;
    private final SessionManager session;
    private final ProfileImages images;
    private final JTextField name = Ui.field(25, "Full name");
    private final JTextField username = Ui.field(25, "Username");
    private final JTextField email = Ui.field(25, "Email address");
    private final JLabel avatar = Ui.label("", 13, false, Ui.MUTED);
    private final JButton remove = Ui.button("Remove", false, this::removePhoto);
    private BufferedImage pendingPicture;
    private boolean removePicture;

    AccountSettingsPanel(MainFrame owner, Client auth, SessionManager session, ProfileImages images) {
        super(new BorderLayout());
        this.owner = owner;
        this.auth = auth;
        this.session = session;
        this.images = images;
        JPanel content = Ui.column();
        Ui.stack(content, Ui.pageHeading("Account Settings", "Manage your profile and sign-in details.", null), 20);

        JPanel profile = Ui.card(new BorderLayout(0, 17), 20);
        profile.add(Ui.label("Profile information", 18, true, Ui.TEXT), BorderLayout.NORTH);
        JPanel form = Ui.column();
        JPanel photo = Ui.transparent(new FlowLayout(FlowLayout.LEFT, 11, 0));
        photo.add(avatar);
        photo.add(Ui.button("Choose photo", false, this::choosePhoto));
        photo.add(remove);
        Ui.stack(form, Ui.label("Profile picture", 13, true, Ui.TEXT), 8);
        Ui.stack(form, photo, 18);
        Ui.fieldRow(form, "Full name", name);
        JPanel pair = Ui.transparent(new GridLayout(1, 2, 14, 0));
        JPanel handle = Ui.column();
        Ui.fieldRow(handle, "Username", username);
        JPanel address = Ui.column();
        Ui.fieldRow(address, "Email address", email);
        pair.add(handle);
        pair.add(address);
        Ui.stack(form, pair, 0);
        profile.add(form);
        profile.add(Ui.actions(Ui.button("Cancel changes", false, this::refresh),
                Ui.button("Save changes", true, this::save)), BorderLayout.SOUTH);
        Ui.stack(content, profile, 16);

        JPanel security = Ui.card(new BorderLayout(15, 7), 20);
        JPanel securityText = Ui.column();
        Ui.stack(securityText, Ui.label("Password", 18, true, Ui.TEXT), 8);
        Ui.stack(securityText, Ui.label("Use your current password to set a new one.", 14, false, Ui.MUTED), 0);
        security.add(securityText);
        security.add(Ui.actions(Ui.button("Change password", false, this::password)), BorderLayout.EAST);
        Ui.stack(content, security, 16);
        Ui.stack(content, Ui.button("Link a recovery cellphone", false, () -> PhoneFields.dialog(this, auth, false)), 16);

        JPanel logout = Ui.card(new BorderLayout(15, 5), 20);
        logout.add(Ui.label("Session", 18, true, Ui.TEXT));
        JButton exit = Ui.button("Logout", false, owner::logout);
        exit.setForeground(Ui.RED);
        logout.add(Ui.actions(exit), BorderLayout.EAST);
        Ui.stack(content, logout, 0);
        add(Ui.page(content));
    }

    @Override public void refresh() {
        var user = session.user();
        name.setText(user.fullName());
        username.setText(user.username());
        email.setText(user.email());
        pendingPicture = null;
        removePicture = false;
        updateAvatar();
    }

    private void choosePhoto() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Choose a profile photo");
        chooser.setFileFilter(new FileNameExtensionFilter("PNG and JPEG images", "png", "jpg", "jpeg"));
        if (chooser.showOpenDialog(owner) == JFileChooser.APPROVE_OPTION) {
            Ui.run(this, () -> {
                pendingPicture = images.preview(chooser.getSelectedFile().toPath());
                removePicture = false;
                updateAvatar();
            });
        }
    }

    private void removePhoto() {
        pendingPicture = null;
        removePicture = true;
        updateAvatar();
    }

    private void updateAvatar() {
        var user = session.user();
        BufferedImage current = pendingPicture;
        if (current == null && !removePicture) current = images.load(user.id(), user.profileImagePath());
        avatar.setIcon(Ui.avatar(name.getText(), current, 63));
        remove.setEnabled(current != null);
    }

    private void save() {
        Ui.run(this, () -> {
            auth.updateProfile(name.getText(), username.getText(), email.getText(), pendingPicture, removePicture);
            refresh();
            owner.updateProfile();
            JOptionPane.showMessageDialog(owner, "Your profile changes were saved.");
        });
    }

    private void password() {
        JPanel fields = Ui.column();
        JPasswordField old = Ui.password(25, "Current password");
        JPasswordField next = Ui.password(25, "8+ characters, letters and numbers");
        JPasswordField confirm = Ui.password(25, "Retype new password");
        Ui.fieldRow(fields, "Current password", old);
        Ui.fieldRow(fields, "New password", next);
        Ui.fieldRow(fields, "Confirm new password", confirm);
        JDialog dialog = new JDialog(owner, "Change Password", Dialog.ModalityType.APPLICATION_MODAL);
        JPanel body = new JPanel(new BorderLayout());
        body.setBorder(BorderFactory.createEmptyBorder(20, 22, 18, 22));
        body.add(fields);
        JButton submit = Ui.button("Update password", true, null);
        JButton cancel = Ui.button("Cancel", false, dialog::dispose);
        submit.addActionListener(event -> {
            long userId = session.user().id();
            char[] current = old.getPassword();
            char[] password = next.getPassword();
            char[] confirmation = confirm.getPassword();
            old.setText("");
            next.setText("");
            confirm.setText("");
            Ui.background(dialog, submit, () -> {
                try {
                    auth.changePassword(userId, current, password, confirmation);
                    return true;
                } finally {
                    Arrays.fill(current, '\0');
                    Arrays.fill(password, '\0');
                    Arrays.fill(confirmation, '\0');
                }
            }, ignored -> {
                dialog.dispose();
                JOptionPane.showMessageDialog(owner, "Your password was updated.");
            });
        });
        submit.addPropertyChangeListener("enabled", event -> {
            cancel.setEnabled(submit.isEnabled());
            dialog.setDefaultCloseOperation(submit.isEnabled() ? WindowConstants.DISPOSE_ON_CLOSE : WindowConstants.DO_NOTHING_ON_CLOSE);
        });
        body.add(Ui.actions(cancel, submit), BorderLayout.SOUTH);
        dialog.setContentPane(body);
        dialog.getRootPane().setDefaultButton(submit);
        dialog.pack();
        dialog.setMinimumSize(dialog.getSize());
        dialog.setLocationRelativeTo(owner);
        dialog.setVisible(true);
    }
}
