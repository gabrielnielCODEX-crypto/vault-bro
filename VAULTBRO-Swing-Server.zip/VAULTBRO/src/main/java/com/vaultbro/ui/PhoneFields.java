package com.vaultbro.ui;

import com.vaultbro.net.Client;
import com.vaultbro.util.Ui;
import java.awt.Component;
import java.util.Arrays;
import javax.swing.*;

final class PhoneFields {
    final JTextField phone = Ui.field(24, "09XXXXXXXXX or +country code");
    final JTextField code = Ui.field(10, "6-digit SMS code");

    PhoneFields(Component owner, JPanel form, Client client, String purpose) {
        Ui.fieldRow(form, "Cellphone number", phone);
        JButton send = Ui.button("Send SMS code", false, null);
        send.addActionListener(event -> {
            String number = phone.getText();
            Ui.background(owner, send, () -> {
                client.sendCode(purpose, number);
                return true;
            }, ok -> JOptionPane.showMessageDialog(owner,
                    "If this number is eligible, a code will arrive by SMS. It expires in 5 minutes."));
        });
        Ui.stack(form, send, 8);
        Ui.fieldRow(form, "SMS code", code);
    }

    static void dialog(Component owner, Client client, boolean reset) {
        String title = reset ? "Reset password" : "Link recovery number";
        JDialog dialog = new JDialog(SwingUtilities.getWindowAncestor(owner), title, java.awt.Dialog.ModalityType.APPLICATION_MODAL);
        JPanel form = Ui.column();
        form.setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));
        PhoneFields fields = new PhoneFields(dialog, form, client, reset ? "reset" : "link");
        var password = Ui.password(24, "8+ characters, letters and numbers");
        var confirm = Ui.password(24, "Retype password");
        if (reset) {
            Ui.fieldRow(form, "New password", password);
            Ui.fieldRow(form, "Confirm new password", confirm);
        }
        JButton submit = Ui.button(title, true, null);
        submit.addActionListener(event -> {
            String number = fields.phone.getText(), code = fields.code.getText();
            char[] next = password.getPassword(), repeat = confirm.getPassword();
            Ui.background(dialog, submit, () -> {
                try {
                    if (reset) client.recover(number, code, next, repeat);
                    else client.link(number, code);
                    return true;
                } finally { Arrays.fill(next, '\0'); Arrays.fill(repeat, '\0'); }
            }, ok -> {
                dialog.dispose();
                JOptionPane.showMessageDialog(owner, reset ? "Password changed. Sign in with your new password." : "Recovery number linked.");
            });
        });
        Ui.stack(form, submit, 0);
        dialog.setContentPane(form);
        dialog.pack();
        dialog.setLocationRelativeTo(owner);
        dialog.setVisible(true);
    }
}
