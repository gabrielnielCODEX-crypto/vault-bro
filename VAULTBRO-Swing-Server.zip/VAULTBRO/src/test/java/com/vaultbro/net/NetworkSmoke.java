package com.vaultbro.net;

import com.vaultbro.controller.*;
import com.vaultbro.database.Database;
import com.vaultbro.model.*;
import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.awt.image.BufferedImage;
import java.util.concurrent.atomic.AtomicReference;

// Standalone integration check. Uses a temporary database and an in-memory SMS mailbox.
public class NetworkSmoke {
    public static void main(String[] args) throws Exception {
        Path dir = Files.createTempDirectory("vaultbro-network-test");
        Database db = new Database(dir.resolve("vaultbro.db"));
        db.initialize();
        var mailbox = new AtomicReference<String>();
        var sms = new SmsCodes((phone, text) -> mailbox.set(text.split("code: ")[1].substring(0, 6)));
        // Separate fixtures allow testing reset immediately without waiting for the signup cooldown.
        var resetSms = new SmsCodes((phone, text) -> mailbox.set(text.split("code: ")[1].substring(0, 6)));
        var activeSender = new AtomicReference<>(sms);
        try (var server = Tls.server(dir).getServerSocketFactory().createServerSocket(0, 10, InetAddress.getLoopbackAddress())) {
            Thread listener = new Thread(() -> {
                while (!server.isClosed()) {
                    try {
                        Socket s = server.accept();
                        var handler = new Server.ConnectionHandler(db, activeSender.get());
                        Thread worker = new Thread(() -> {
                            try (s) { handler.serve(s); } catch (IOException expectedOnClose) {}
                        });
                        worker.setDaemon(true);
                        worker.start();
                    } catch (IOException stopped) { return; }
                }
            });
            listener.setDaemon(true);
            listener.start();
            var legacyAuth = new AuthService(new com.vaultbro.dao.UserDAO(db), new SessionManager(),
                    new com.vaultbro.service.ProfileImages(dir));
            char[] legacyPass = "LegacyPass123".toCharArray();
            legacyAuth.register("Legacy","legacy","legacy@example.com",legacyPass,legacyPass);
            var legacy = client(dir,server);
            legacy.authenticate("legacy",legacyPass);
            legacy.sendCode("link","09171234569");
            legacy.link("+639171234569",mailbox.get());
            check(legacy.authenticate("09171234569",legacyPass).username().equals("legacy"));
            legacy.logout();
            var a = client(dir, server);
            var b = client(dir, server);
            char[] old = "SamplePass123".toCharArray(), next = "ChangedPass456".toCharArray();
            String phone = "09171234567";
            rejected(() -> a.goals());
            a.sendCode("signup", phone);
            a.register("Network test","netuser","test@example.com",phone,mailbox.get(),old,old);
            var u = a.authenticate("+639171234567",old);
            check(b.authenticate("test@example.com",old).id() == u.id());
            a.saveTransaction(Transaction.Type.EXPENSE,0,"Lunch","Food & Dining","100","2026-11-23");
            check(b.searchTransactions("lunch").get(0).getAmount() == 10_000);
            a.saveBudget(0,"Food & Dining","500","2026-11");
            check(b.budgets().get(0).spent() == 10_000);
            a.saveGoal(0,"Trip","Travel","3000","2027-01-01");
            long goal = b.goals().get(0).id();
            b.addGoalEntry(goal,GoalEntry.Type.CONTRIBUTION,"250","2026-11-23","First deposit");
            check(a.goalHistory(null).get(0).amount() == 25_000);
            var image = new BufferedImage(256,256,BufferedImage.TYPE_INT_ARGB);
            image.setRGB(3,4,0xffabcdef);
            a.updateProfile("Updated","netuser","test@example.com",image,false);
            var updated = b.authenticate("netuser",old);
            check(updated.fullName().equals("Updated") && b.images.load(updated.id(),updated.profileImagePath()).getRGB(3,4)==0xffabcdef);
            activeSender.set(resetSms);
            var recovery = client(dir,server);
            recovery.sendCode("reset",phone);
            String code = mailbox.get();
            rejected(() -> recovery.recover(phone,"wrong",next,next));
            recovery.recover(phone,code,next,next);
            rejected(() -> recovery.recover(phone,code,next,next));
            rejected(() -> a.goals());
            rejected(() -> b.authenticate(phone,old));
            check(b.authenticate(phone,next).id()==u.id());
            check(b.searchTransactions("").size()==1);
            var other = client(dir,server);
            String otherPhone="09171234568";
            other.sendCode("signup",otherPhone);
            other.register("Other","otheruser","other@example.com",otherPhone,mailbox.get(),old,old);
            other.authenticate(otherPhone,old);
            check(other.searchTransactions("").isEmpty());
            rejected(() -> other.deleteGoal(goal));
            a.logout(); b.logout(); other.logout(); recovery.logout();
            System.out.println("PASS: TLS clients, account ownership, financial records, photos, OTP recovery and session revocation.");
        }
    }
    private static Client client(Path dir, ServerSocket s) {
        return new Client(s.getInetAddress().getHostAddress(), s.getLocalPort(), dir.resolve("server.cer"), new SessionManager());
    }
    private static void check(boolean condition) {
        if (!condition) throw new AssertionError();
    }
    interface Action { void run() throws Exception; }
    private static void rejected(Action action) throws Exception {
        try { action.run(); } catch (IllegalArgumentException | IllegalStateException e) { return; }
        throw new AssertionError("Expected rejection");
    }
}
