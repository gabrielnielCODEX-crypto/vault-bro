package com.vaultbro.net;

import org.junit.jupiter.api.Test;

final class NetworkIntegrationTest {
    @Test void sharesFinanceDataAndVerifiesPhoneRecovery() throws Exception {
        NetworkSmoke.main(new String[0]);
    }
}
