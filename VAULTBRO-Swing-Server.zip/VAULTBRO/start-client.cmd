@echo off
cd /d "%~dp0"
java -jar vaultbro.jar
if errorlevel 1 pause
