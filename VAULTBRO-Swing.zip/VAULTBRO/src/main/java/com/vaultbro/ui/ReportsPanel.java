package com.vaultbro.ui;

import com.vaultbro.model.*;
import com.vaultbro.service.FinancialCalculationService;
import com.vaultbro.service.FinancialCalculationService.Report;
import com.vaultbro.service.ReportExporter;
import com.vaultbro.service.ReportExporter.Format;
import com.vaultbro.util.Ui;
import java.awt.*;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

final class ReportsPanel extends JPanel implements MainFrame.View {
    private final MainFrame owner;
    private final FinancialCalculationService calculations;
    private final ReportExporter exporter = new ReportExporter();
    private final JPanel content = Ui.column();
    private final JPanel metrics = Ui.transparent(new BorderLayout());
    private final JTabbedPane tabs = new JTabbedPane();
    private final JComboBox<Format> format = new JComboBox<>(Format.values());
    private final JButton export = Ui.button("Export", true, this::export);
    private final JLabel scope = Ui.label(" ", 12, false, Ui.MUTED);
    private final JComboBox<String> expenseCategory = new JComboBox<>();
    private static final int ANALYTICS_TAB = 0;
    private DateRange range = DateRange.ALL;
    private Report displayed;

    ReportsPanel(MainFrame owner, FinancialCalculationService calculations) {
        super(new BorderLayout());
        this.owner = owner;
        this.calculations = calculations;
        export.setIcon(Symbol.EXPORT.icon(Color.WHITE, 17));
        export.setEnabled(false);
        JPanel tools = Ui.card(new BorderLayout(0, 8), 12);
        JPanel filters = Ui.transparent(new FlowLayout(FlowLayout.LEFT, 8, 0));
        JPanel filterRows = Ui.column();
        Ui.stack(filterRows, new DateFilter(true, value -> {
            range = value;
            Ui.run(this, this::refresh);
        }), 7);
        expenseCategory.addItem("All categories");
        Categories.EXPENSES.forEach(expenseCategory::addItem);
        filters.add(Ui.fieldLabel("Chart expenses", expenseCategory));
        filters.add(expenseCategory);
        Ui.stack(filterRows, filters, 0);
        tools.add(filterRows, BorderLayout.NORTH);

        JPanel exportRow = Ui.transparent(new BorderLayout(7, 0));
        scope.setToolTipText("The expense category filters chart spending. Exports use the selected dates.");
        exportRow.add(scope, BorderLayout.WEST);
        JPanel exportControls = Ui.transparent(new FlowLayout(FlowLayout.RIGHT, 7, 0));
        format.getAccessibleContext().setAccessibleName("Report export format");
        exportControls.add(format);
        exportControls.add(export);
        exportRow.add(exportControls, BorderLayout.EAST);
        tools.add(exportRow, BorderLayout.SOUTH);
        Ui.stack(content, tools, 14);

        content.add(metrics);
        content.add(Box.createVerticalStrut(14));
        tabs.addChangeListener(event -> sizeTabs());
        expenseCategory.addActionListener(event -> {
            if (displayed != null) {
                tabs.setComponentAt(ANALYTICS_TAB, analytics(displayed));
                tabs.setSelectedIndex(ANALYTICS_TAB);
            }
        });
        Ui.stack(content, tabs, 0);
        add(Ui.page(content));
    }

    @Override public void refresh() throws SQLException {
        Report report = calculations.report(range);
        int selected = Math.max(0, tabs.getSelectedIndex());
        displayed = report;
        export.setEnabled(true);
        scope.setText((range.equals(DateRange.ALL) ? "All dates" : range.toString())
                + "  ·  Savings shown at current balances");
        metrics.removeAll();
        metrics.add(DashboardPanel.stats(report.totals()));
        metrics.setAlignmentX(Component.LEFT_ALIGNMENT);
        metrics.setMaximumSize(new Dimension(Short.MAX_VALUE, metrics.getPreferredSize().height));
        tabs.removeAll();
        tabs.addTab("Overview", analytics(report));
        tabs.addTab("Monthly Summary", monthly(report));
        tabs.addTab("Expense Breakdown", expenses(report));
        tabs.addTab("Budgets", budgets(report));
        tabs.addTab("Savings Goals", goals(report));
        tabs.addTab("Transactions", transactions(report));
        tabs.setSelectedIndex(selected);
        sizeTabs();
        content.revalidate();
        content.repaint();
    }

    private void sizeTabs() {
        int height = tabs.getSelectedIndex() == ANALYTICS_TAB ? 554 : 420;
        tabs.setPreferredSize(new Dimension(480, height));
        tabs.setMaximumSize(new Dimension(Short.MAX_VALUE, height));
        content.revalidate();
    }

    private JComponent analytics(Report report) {
        List<Transaction> scoped = report.transactions();
        List<FinancialCalculationService.MonthSummary> months = report.months();
        if (expenseCategory.getSelectedIndex() > 0) {
            String category = (String) expenseCategory.getSelectedItem();
            scoped = scoped.stream()
                    .filter(transaction -> transaction.getType() == Transaction.Type.INCOME
                            || transaction.getCategory().equals(category))
                    .toList();
            months = FinancialCalculationService.months(scoped, report.history(), report.range());
        }
        String periodLabel = months.size() > 12 ? "Latest 12 months in the date range" : "Selected dates";
        List<FinancialCalculationService.MonthSummary> monthsInChart =
                months.subList(Math.max(0, months.size() - 12), months.size());
        List<BudgetUsage> budgets = report.budgets();
        String budgetScope = budgets.size() > 6 ? "First 6 budgets in the date range" : "Selected dates";
        JPanel grid = Ui.transparent(new GridLayout(2, 2, 13, 13));
        grid.setBorder(new EmptyBorder(8, 1, 1, 1));
        grid.add(DashboardPanel.chartCard("Expense distribution", "Selected dates",
                FinanceCharts.distribution(FinancialCalculationService.expenseCategories(scoped))));
        grid.add(DashboardPanel.chartCard("Monthly income vs expenses", periodLabel, FinanceCharts.cashFlow(monthsInChart)));
        grid.add(DashboardPanel.chartCard("Monthly spending trend", periodLabel, FinanceCharts.trend(monthsInChart)));
        grid.add(DashboardPanel.chartCard("Budget utilization", budgetScope,
                FinanceCharts.budgetUtilization(budgets.subList(0, Math.min(6, budgets.size())))));
        return grid;
    }

    private JComponent monthly(Report report) {
        var model = Ui.tableModel(new String[]{"Month", "Income", "Expenses", "Balance", "Savings activity"},
                new Class<?>[]{YearMonth.class, Long.class, Long.class, Long.class, Long.class});
        JTable table = Ui.table(model);
        for (int column = 1; column < 5; column++) FinanceTables.money(table, column, column >= 3);
        for (var month : report.months()) {
            model.addRow(new Object[]{month.month(), month.income(), month.expenses(), month.balance(), month.savingsActivity()});
        }
        return tableCard("Monthly financial summary", table,
                "Savings activity is contributions minus withdrawals during the selected dates.");
    }

    private JComponent expenses(Report report) {
        JPanel layout = Ui.transparent(new GridLayout(1, 2, 12, 0));
        layout.add(DashboardPanel.chartCard("Expense distribution", null, FinanceCharts.distribution(report.categories())));
        var model = Ui.tableModel(new String[]{"Category", "Expenses"}, new Class<?>[]{String.class, Long.class});
        JTable table = Ui.table(model);
        FinanceTables.money(table, 1, false);
        report.categories().forEach((category, amount) -> model.addRow(new Object[]{category, amount}));
        layout.add(tableCard("Expenses by category", table, null));
        return layout;
    }

    private JComponent budgets(Report report) {
        var model = FinanceTables.budgetModel();
        JTable table = FinanceTables.budgetTable(model);
        FinanceTables.budgetRows(model, report.budgets());
        return tableCard("Budget performance", table, "Usage covers the full month for each listed budget.");
    }

    private JComponent goals(Report report) {
        var model = Ui.tableModel(new String[]{"Goal", "Target", "Saved", "Remaining", "Due", "Progress", "Status"},
                new Class<?>[]{String.class, Long.class, Long.class, Long.class, LocalDate.class, String.class, String.class});
        JTable table = Ui.table(model);
        table.getColumnModel().getColumn(0).setPreferredWidth(180);
        for (int column = 1; column <= 3; column++) FinanceTables.money(table, column, false);
        LocalDate today = LocalDate.now();
        for (SavingsGoal goal : report.goals()) {
            model.addRow(new Object[]{goal.name(), goal.targetAmount(), goal.savedAmount(), goal.remaining(),
                    goal.targetDate(), FinanceTables.percent(goal.percent()), goal.status(today).toString()});
        }
        return tableCard("Savings goal progress", table, "Goal amounts reflect all recorded savings activity.");
    }

    private JComponent transactions(Report report) {
        var table = new FinanceTables.Transactions(false);
        table.set(report.transactions());
        return tableCard("Transaction history", table.table, null);
    }

    private static JComponent tableCard(String title, JTable table, String note) {
        JPanel card = Ui.card(new BorderLayout(0, 10), 14);
        card.add(Ui.label(title, 16, true, Ui.TEXT), BorderLayout.NORTH);
        card.add(FinanceTables.tableScroll(table, 300), BorderLayout.CENTER);
        if (note != null) card.add(Ui.label(note, 12, false, Ui.MUTED), BorderLayout.SOUTH);
        return card;
    }

    private void export() {
        Format selected = (Format) format.getSelectedItem();
        Report snapshot = displayed;
        if (selected == null || snapshot == null) return;
        ReportExportDialog.show(owner, export, selected, destination -> exporter.export(destination, selected, snapshot));
    }
}
