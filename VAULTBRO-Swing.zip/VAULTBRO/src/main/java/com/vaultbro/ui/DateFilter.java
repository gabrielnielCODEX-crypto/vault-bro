package com.vaultbro.ui;

import com.vaultbro.model.DateRange;
import com.vaultbro.util.Ui;
import com.vaultbro.util.ValidationUtil;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.function.Consumer;
import javax.swing.*;

final class DateFilter extends JPanel {
    private enum Mode {
        ALL("All dates"), DAY("By day"), MONTH("By month"), YEAR("By year"), RANGE("Date range");
        private final String label;
        Mode(String label) { this.label = label; }
        @Override public String toString() { return label; }
    }

    private final JComboBox<Mode> mode;
    private final JTextField day = Ui.field(9, "YYYY-MM-DD");
    private final JTextField year = Ui.field(6, "YYYY");
    private final JTextField month = Ui.field(8, "YYYY-MM");
    private final JTextField from = Ui.field(9, "YYYY-MM-DD");
    private final JTextField to = Ui.field(9, "YYYY-MM-DD");
    private final JPanel details = Ui.transparent(new FlowLayout(FlowLayout.LEFT, 7, 0));
    private final Consumer<DateRange> change;

    DateFilter(boolean includeYear, Consumer<DateRange> change) {
        super(new FlowLayout(FlowLayout.LEFT, 7, 0));
        this.change = change;
        mode = new JComboBox<>(includeYear
                ? new Mode[]{Mode.ALL, Mode.YEAR, Mode.MONTH, Mode.DAY, Mode.RANGE}
                : new Mode[]{Mode.ALL, Mode.DAY, Mode.MONTH, Mode.RANGE});
        setOpaque(false);
        month.setText(YearMonth.now().toString());
        year.setText(Integer.toString(YearMonth.now().getYear()));
        day.setText(LocalDate.now().toString());
        mode.getAccessibleContext().setAccessibleName("Date filter");
        day.getAccessibleContext().setAccessibleName("Filter day");
        year.getAccessibleContext().setAccessibleName("Filter year");
        month.getAccessibleContext().setAccessibleName("Filter month");
        from.getAccessibleContext().setAccessibleName("Filter start date");
        to.getAccessibleContext().setAccessibleName("Filter end date");
        add(mode);
        add(details);
        mode.addActionListener(event -> edit());
        for (JTextField field : new JTextField[]{day, month, year, from, to}) field.addActionListener(event -> apply());
    }

    @Override public Dimension getPreferredSize() {
        Dimension size = super.getPreferredSize();
        size.height = Math.max(43, size.height);
        return size;
    }

    private void edit() {
        details.removeAll();
        Mode selected = (Mode) mode.getSelectedItem();
        if (selected == Mode.DAY) details.add(day);
        if (selected == Mode.YEAR) details.add(year);
        if (selected == Mode.MONTH) details.add(month);
        if (selected == Mode.RANGE) {
            details.add(Ui.fieldLabel("From", from));
            details.add(from);
            details.add(Ui.fieldLabel("To", to));
            details.add(to);
        }
        if (selected != Mode.ALL) details.add(Ui.button("Apply", false, this::apply));
        details.revalidate();
        details.repaint();
        apply();
    }

    private void apply() {
        Ui.run(this, () -> {
            DateRange range = switch ((Mode) mode.getSelectedItem()) {
                case ALL -> DateRange.ALL;
                case DAY -> {
                    LocalDate exact = ValidationUtil.date(day.getText(), "Day");
                    yield new DateRange(exact, exact);
                }
                case YEAR -> {
                    String value = year.getText().strip();
                    if (!value.matches("[0-9]{4}")) throw new IllegalArgumentException("Enter a four-digit year.");
                    LocalDate first = ValidationUtil.date(value + "-01-01", "Year");
                    yield new DateRange(first, first.withDayOfYear(first.lengthOfYear()));
                }
                case MONTH -> DateRange.month(ValidationUtil.month(month.getText()));
                case RANGE -> new DateRange(optionalDate(from, "Start date"), optionalDate(to, "End date"));
            };
            change.accept(range);
        });
    }

    void reset() {
        day.setText(LocalDate.now().toString());
        month.setText(YearMonth.now().toString());
        year.setText(Integer.toString(YearMonth.now().getYear()));
        from.setText("");
        to.setText("");
        if (mode.getSelectedItem() == Mode.ALL) apply();
        else mode.setSelectedItem(Mode.ALL);
    }

    private static LocalDate optionalDate(JTextField field, String label) {
        return field.getText().isBlank() ? null : ValidationUtil.date(field.getText(), label);
    }
}
