package com.vaultbro.controller;

import com.vaultbro.dao.BudgetDAO;
import com.vaultbro.dao.GoalDAO;
import com.vaultbro.dao.TransactionDAO;
import com.vaultbro.model.*;
import com.vaultbro.util.ValidationUtil;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class FinanceController {
    private final SessionManager session;
    private final TransactionDAO transactions;
    private final BudgetDAO budgets;
    private final GoalDAO goals;

    public FinanceController(SessionManager session, TransactionDAO transactions, BudgetDAO budgets, GoalDAO goals) {
        this.session = session;
        this.transactions = transactions;
        this.budgets = budgets;
        this.goals = goals;
    }

    public List<Transaction> searchTransactions(String search) throws SQLException {
        return searchTransactions(search, null, null, DateRange.ALL);
    }

    public List<Transaction> searchTransactions(String search, Transaction.Type type, String category, DateRange range)
            throws SQLException {
        String term = search.strip().toLowerCase(Locale.ROOT);
        return transactions.find(userId(), range).stream()
                .filter(transaction -> type == null || transaction.getType() == type)
                .filter(transaction -> category == null || transaction.getCategory().equals(category))
                .filter(transaction -> term.isEmpty()
                        || transaction.getDescription().toLowerCase(Locale.ROOT).contains(term)
                        || transaction.getCategory().toLowerCase(Locale.ROOT).contains(term)
                        || Long.toString(transaction.getId()).equals(term))
                .toList();
    }

    public void saveTransaction(Transaction.Type type, long id, String description, String category, String amount,
                                String date) throws SQLException {
        if (type == null) throw new IllegalArgumentException("Select a transaction type.");
        description = ValidationUtil.required(description, "Description", 300);
        ValidationUtil.category(category, type == Transaction.Type.INCOME ? Categories.INCOME : Categories.EXPENSES);
        transactions.save(userId(), TransactionFactory.create(type, id, description, category,
                Money.parsePositive(amount), ValidationUtil.date(date, "Transaction date")));
    }

    public void deleteTransaction(long id) throws SQLException { transactions.delete(userId(), id); }

    public List<BudgetUsage> budgets() throws SQLException { return budgets.find(userId()); }

    public static List<String> budgetCategories() {
        List<String> categories = new ArrayList<>(Categories.EXPENSES);
        categories.add(0, Budget.OVERALL);
        return categories;
    }

    public void saveBudget(long id, String category, String limit, String period) throws SQLException {
        ValidationUtil.category(category, budgetCategories());
        budgets.save(userId(), new Budget(id, category, Money.parsePositive(limit), ValidationUtil.month(period)));
    }

    public void deleteBudget(long id) throws SQLException { budgets.delete(userId(), id); }

    public List<SavingsGoal> goals() throws SQLException { return goals.find(userId()); }

    public List<GoalEntry> goalHistory(Long goalId) throws SQLException { return goals.history(userId(), goalId); }

    public void saveGoal(long id, String name, String category, String amount, String date) throws SQLException {
        name = ValidationUtil.required(name, "Goal name", 100);
        ValidationUtil.category(category, Categories.GOALS);
        goals.save(userId(), new SavingsGoal(id, name, category, Money.parsePositive(amount),
                ValidationUtil.date(date, "Target date"), 0));
    }

    public void deleteGoal(long id) throws SQLException { goals.delete(userId(), id); }

    public void addGoalEntry(long goalId, GoalEntry.Type type, String amount, String date, String description)
            throws SQLException {
        if (type == null) throw new IllegalArgumentException("Select an entry type.");
        LocalDate entryDate = ValidationUtil.date(date, "Entry date");
        goals.addEntry(userId(), goalId, type, Money.parsePositive(amount), entryDate,
                ValidationUtil.optional(description, "Description", 300));
    }

    private long userId() { return session.user().id(); }
}
