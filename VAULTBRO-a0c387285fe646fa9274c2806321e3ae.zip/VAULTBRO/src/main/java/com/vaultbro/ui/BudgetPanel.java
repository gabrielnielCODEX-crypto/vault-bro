package com.vaultbro.ui;

import com.vaultbro.controller.FinanceController;
import com.vaultbro.model.*;
import com.vaultbro.util.Ui;
import com.vaultbro.util.ValidationUtil;
import java.awt.*;
import java.sql.SQLException;
import java.time.YearMonth;
import java.util.List;
import java.util.Locale;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

final class BudgetPanel extends JPanel implements MainFrame.View {
    private final MainFrame owner;
    private final FinanceController finance;
    private final DefaultTableModel model = FinanceTables.budgetModel();
    private final JTable table = FinanceTables.budgetTable(model);
    private final JLabel count = Ui.label("", 13, true, Ui.MUTED);
    private final JComboBox<String> category = new JComboBox<>();
    private final JComboBox<String> status = new JComboBox<>(new String[]{"All statuses", "On Track", "Near Limit", "Over Budget"});
    private final JTextField month = Ui.field(8, "YYYY-MM");
    private final CardLayout listLayout = new CardLayout();
    private final JPanel list = Ui.transparent(listLayout);
    private List<BudgetUsage> all = List.of();
    private List<BudgetUsage> visible = List.of();
    private YearMonth period;
    private String search = "";

    BudgetPanel(MainFrame owner, FinanceController finance) {
        super(new BorderLayout(0, 17));
        this.owner = owner;
        this.finance = finance;
        setBorder(new EmptyBorder(24, 30, 24, 30));
        JButton add = Ui.button("Create budget", true, () -> edit(null));
        add.setIcon(Symbol.PLUS.icon(Color.WHITE, 17));
        JPanel top = Ui.column();
        Ui.stack(top, Ui.pageHeading("Budgets", "Set monthly limits and track how much you’ve spent.", add), 18);
        JPanel filters = Ui.card(new FlowLayout(FlowLayout.LEFT, 8, 0), 12);
        category.addItem("All categories");
        FinanceController.budgetCategories().forEach(category::addItem);
        month.getAccessibleContext().setAccessibleName("Budget month");
        filters.add(category);
        filters.add(status);
        filters.add(Ui.fieldLabel("Month", month));
        filters.add(month);
        filters.add(Ui.button("Apply", false, this::filterMonth));
        filters.add(Ui.button("Clear month", false, () -> {
            month.setText("");
            filterMonth();
        }));
        month.addActionListener(event -> filterMonth());
        category.addActionListener(event -> filter());
        status.addActionListener(event -> filter());
        Ui.stack(top, filters, 0);
        add(top, BorderLayout.NORTH);

        JPanel card = Ui.card(new BorderLayout(0, 9), 15);
        JPanel header = Ui.transparent(new BorderLayout());
        header.add(count, BorderLayout.WEST);
        JButton details = Ui.button("Details", false, () -> details(selected()));
        JButton edit = Ui.button("Edit", false, () -> edit(selected().budget()));
        JButton delete = Ui.button("Delete", false, this::delete);
        delete.setForeground(Ui.RED);
        JButton[] actions = {details, edit, delete};
        for (JButton button : actions) button.setEnabled(false);
        table.getSelectionModel().addListSelectionListener(event -> {
            for (JButton button : actions) button.setEnabled(table.getSelectedRow() >= 0);
        });
        header.add(Ui.actions(actions), BorderLayout.EAST);
        card.add(header, BorderLayout.NORTH);
        list.add(FinanceTables.tableScroll(table, 340), "table");
        JPanel blank = Ui.transparent(new GridBagLayout());
        blank.add(Ui.label("No budgets match these filters.", 14, false, Ui.MUTED));
        list.add(blank, "empty");
        card.add(list);
        add(card);
    }

    @Override public void refresh() throws SQLException {
        all = finance.budgets();
        filter();
    }

    @Override public void search(String text) {
        search = text.strip().toLowerCase(Locale.ROOT);
        filter();
    }

    private void filterMonth() {
        Ui.run(this, () -> {
            period = month.getText().isBlank() ? null : ValidationUtil.month(month.getText());
            filter();
        });
    }

    private void filter() {
        visible = all.stream()
                .filter(item -> period == null || item.budget().period().equals(period))
                .filter(item -> category.getSelectedIndex() == 0 || item.budget().category().equals(category.getSelectedItem()))
                .filter(item -> status.getSelectedIndex() == 0 || item.status().toString().equals(status.getSelectedItem()))
                .filter(item -> (item.budget().category() + " " + item.budget().period() + " " + item.status())
                        .toLowerCase(Locale.ROOT).contains(search))
                .toList();
        FinanceTables.budgetRows(model, visible);
        count.setText(visible.size() + (visible.size() == 1 ? " budget" : " budgets"));
        listLayout.show(list, visible.isEmpty() ? "empty" : "table");
    }

    private BudgetUsage selected() { return visible.get(table.convertRowIndexToModel(table.getSelectedRow())); }

    private void edit(Budget budget) {
        JPanel form = Ui.column();
        JComboBox<String> choice = new JComboBox<>(FinanceController.budgetCategories().toArray(String[]::new));
        JTextField limit = Ui.field(22, "0.00");
        JTextField selectedMonth = Ui.field(22, "YYYY-MM");
        if (budget != null) {
            choice.setSelectedItem(budget.category());
            limit.setText(Money.decimal(budget.monthlyLimit()));
        }
        YearMonth initialMonth = period == null ? YearMonth.now() : period;
        selectedMonth.setText((budget == null ? initialMonth : budget.period()).toString());
        Ui.fieldRow(form, "Category", choice);
        Ui.fieldRow(form, "Monthly limit (₱)", limit);
        Ui.fieldRow(form, "Month (YYYY-MM)", selectedMonth);
        Ui.formSubmit(owner, budget == null ? "Create Budget" : "Edit Budget", "Save budget", form, () -> {
            finance.saveBudget(budget == null ? 0 : budget.id(), (String) choice.getSelectedItem(),
                    limit.getText(), selectedMonth.getText());
            owner.dataChanged();
        });
    }

    private void delete() {
        Budget budget = selected().budget();
        if (Ui.confirm(owner, "Delete Budget", "Delete the " + budget.category() + " budget for " + budget.period() + "?")) {
            Ui.run(this, () -> {
                finance.deleteBudget(budget.id());
                owner.dataChanged();
            });
        }
    }

    private void details(BudgetUsage usage) {
        Budget budget = usage.budget();
        JPanel panel = Ui.column();
        Color color = FinanceTables.budgetColor(usage.status());
        Ui.stack(panel, Ui.label(budget.category() + " · " + budget.period(), 20, true, Ui.TEXT), 12);
        Ui.stack(panel, Ui.label(usage.status() + " · " + FinanceTables.percent(usage.percent()), 14, true, color), 10);
        Ui.stack(panel, Ui.progress(usage.percent(), color), 13);
        Ui.stack(panel, Ui.label("Monthly limit  " + Money.format(budget.monthlyLimit()), 14, false, Ui.TEXT), 6);
        Ui.stack(panel, Ui.label("Amount spent  " + Money.format(usage.spent()), 14, false, Ui.TEXT), 6);
        Ui.stack(panel, Ui.label("Remaining  " + Money.format(usage.remaining()), 14, false, Ui.TEXT), 0);
        JOptionPane.showMessageDialog(owner, panel, "Budget #" + budget.id(), JOptionPane.PLAIN_MESSAGE);
    }
}
