package com.vaultbro.ui;

import com.vaultbro.controller.FinanceController;
import com.vaultbro.model.Categories;
import com.vaultbro.model.Money;
import com.vaultbro.model.Transaction;
import com.vaultbro.util.Ui;
import java.time.LocalDate;
import javax.swing.*;

final class TransactionDialog {
    private TransactionDialog() {}

    static void show(MainFrame owner, FinanceController finance, Transaction record) {
        JPanel form = Ui.column();
        JComboBox<Transaction.Type> type = new JComboBox<>(Transaction.Type.values());
        JComboBox<String> category = new JComboBox<>();
        JTextArea description = FinanceTables.notes(record == null ? "" : record.getDescription(), 3);
        JTextField amount = Ui.field(22, "0.00");
        JTextField date = Ui.field(22, "YYYY-MM-DD");
        if (record != null) {
            type.setSelectedItem(record.getType());
            amount.setText(Money.decimal(record.getAmount()));
        } else {
            type.setSelectedItem(Transaction.Type.EXPENSE);
        }
        date.setText((record == null ? LocalDate.now() : record.getDate()).toString());
        Runnable loadCategories = () -> {
            var all = type.getSelectedItem() == Transaction.Type.INCOME ? Categories.INCOME : Categories.EXPENSES;
            category.setModel(new DefaultComboBoxModel<>(all.toArray(String[]::new)));
            category.setSelectedIndex(-1);
        };
        loadCategories.run();
        if (record != null) category.setSelectedItem(record.getCategory());
        type.addActionListener(event -> loadCategories.run());
        Ui.fieldRow(form, "Type", type);
        Ui.fieldRow(form, "Category", category);
        Ui.stack(form, Ui.fieldLabel("Description", description), 7);
        Ui.stack(form, new JScrollPane(description), 13);
        Ui.fieldRow(form, "Amount (₱)", amount);
        Ui.fieldRow(form, "Date (YYYY-MM-DD)", date);
        Ui.formSubmit(owner, record == null ? "Add Transaction" : "Edit Transaction", "Save transaction", form, () -> {
            finance.saveTransaction((Transaction.Type) type.getSelectedItem(), record == null ? 0 : record.getId(),
                    description.getText(), (String) category.getSelectedItem(), amount.getText(), date.getText());
            owner.dataChanged();
        });
    }

    static void details(MainFrame owner, Transaction record) {
        JPanel content = Ui.column();
        Ui.stack(content, Ui.label(record.getType() + " · " + Money.format(record.getAmount()), 20, true, Ui.TEXT), 10);
        Ui.stack(content, Ui.label("Transaction #" + record.getId() + "   •   " + record.getDate()
                + "   •   " + record.getCategory(), 13, false, Ui.MUTED), 12);
        JTextArea description = FinanceTables.notes(record.getDescription(), 4);
        description.setEditable(false);
        Ui.stack(content, Ui.scroll(description), 0);
        JOptionPane.showMessageDialog(owner, content, "Transaction Details", JOptionPane.PLAIN_MESSAGE);
    }
}
