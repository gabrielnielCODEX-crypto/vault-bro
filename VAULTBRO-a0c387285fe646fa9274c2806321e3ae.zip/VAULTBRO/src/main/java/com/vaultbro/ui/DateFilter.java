package com.vaultbro.ui;

import com.vaultbro.model.DateRange;
import com.vaultbro.util.Ui;
import com.vaultbro.util.ValidationUtil;
import java.awt.FlowLayout;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.function.Consumer;
import javax.swing.*;

final class DateFilter extends JPanel {
    private enum Mode { ALL, MONTH, RANGE }
    private final JComboBox<String> mode = new JComboBox<>(new String[]{"All dates", "By month", "Date range"});
    private final JTextField month = Ui.field(8, "YYYY-MM");
    private final JTextField from = Ui.field(9, "YYYY-MM-DD");
    private final JTextField to = Ui.field(9, "YYYY-MM-DD");
    private final JPanel details = Ui.transparent(new FlowLayout(FlowLayout.LEFT, 7, 0));
    private final Consumer<DateRange> change;

    DateFilter(Consumer<DateRange> change) {
        super(new FlowLayout(FlowLayout.LEFT, 7, 0));
        this.change = change;
        setOpaque(false);
        month.setText(YearMonth.now().toString());
        month.getAccessibleContext().setAccessibleName("Filter month");
        from.getAccessibleContext().setAccessibleName("Filter start date");
        to.getAccessibleContext().setAccessibleName("Filter end date");
        add(mode);
        add(details);
        mode.addActionListener(event -> edit());
        for (JTextField field : new JTextField[]{month, from, to}) field.addActionListener(event -> apply());
    }

    private void edit() {
        details.removeAll();
        Mode selected = Mode.values()[mode.getSelectedIndex()];
        if (selected == Mode.MONTH) details.add(month);
        if (selected == Mode.RANGE) {
            details.add(Ui.fieldLabel("From", from));
            details.add(from);
            details.add(Ui.fieldLabel("To", to));
            details.add(to);
        }
        if (selected != Mode.ALL) details.add(Ui.button("Apply", false, this::apply));
        details.revalidate();
        details.repaint();
        if (selected != Mode.RANGE || !from.getText().isBlank() || !to.getText().isBlank()) apply();
    }

    private void apply() {
        Ui.run(this, () -> {
            DateRange range = switch (Mode.values()[mode.getSelectedIndex()]) {
                case ALL -> DateRange.ALL;
                case MONTH -> DateRange.month(ValidationUtil.month(month.getText()));
                case RANGE -> new DateRange(optionalDate(from, "Start date"), optionalDate(to, "End date"));
            };
            change.accept(range);
        });
    }

    private static LocalDate optionalDate(JTextField field, String label) {
        return field.getText().isBlank() ? null : ValidationUtil.date(field.getText(), label);
    }
}
