package com.vaultbro.ui;

import com.vaultbro.model.*;
import com.vaultbro.service.FinancialCalculationService;
import com.vaultbro.service.FinancialCalculationService.Report;
import com.vaultbro.service.ReportExporter;
import com.vaultbro.service.ReportExporter.Format;
import com.vaultbro.util.Ui;
import java.awt.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.Locale;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;

final class ReportsPanel extends JPanel implements MainFrame.View {
    private final MainFrame owner;
    private final FinancialCalculationService calculations;
    private final ReportExporter exporter = new ReportExporter();
    private final JPanel content = Ui.column();
    private final JPanel metrics = Ui.transparent(new BorderLayout());
    private final JTabbedPane tabs = new JTabbedPane();
    private final JComboBox<Format> format = new JComboBox<>(Format.values());
    private final JButton export = Ui.button("Export", true, this::export);
    private final JLabel scope = Ui.label("", 13, false, Ui.MUTED);
    private DateRange range = DateRange.ALL;
    private Report displayed;

    ReportsPanel(MainFrame owner, FinancialCalculationService calculations) {
        super(new BorderLayout());
        this.owner = owner;
        this.calculations = calculations;
        export.setIcon(Symbol.EXPORT.icon(Color.WHITE, 17));
        export.setEnabled(false);
        JPanel tools = Ui.transparent(new FlowLayout(FlowLayout.RIGHT, 7, 0));
        format.getAccessibleContext().setAccessibleName("Report export format");
        tools.add(format);
        tools.add(export);
        Ui.stack(content, Ui.pageHeading("Reports & Analytics", "Review your activity and export your financial records.", tools), 18);
        JPanel filters = Ui.card(new BorderLayout(12, 5), 12);
        filters.add(new DateFilter(value -> {
            range = value;
            Ui.run(this, this::refresh);
        }), BorderLayout.NORTH);
        scope.setToolTipText("Savings is the current total. Budgets show full months that overlap the selected dates.");
        filters.add(scope, BorderLayout.SOUTH);
        Ui.stack(content, filters, 15);
        content.add(metrics);
        content.add(Box.createVerticalStrut(15));
        tabs.setPreferredSize(new Dimension(480, 430));
        Ui.stack(content, tabs, 0);
        add(Ui.page(content));
    }

    @Override public void refresh() throws SQLException {
        Report report = calculations.report(range);
        int selected = Math.max(0, tabs.getSelectedIndex());
        displayed = report;
        export.setEnabled(true);
        scope.setText((range.equals(DateRange.ALL) ? "All dates" : range.toString())
                + "  ·  Savings shown at current balances");
        metrics.removeAll();
        metrics.add(DashboardPanel.stats(report.totals()));
        metrics.setAlignmentX(Component.LEFT_ALIGNMENT);
        metrics.setMaximumSize(new Dimension(Short.MAX_VALUE, metrics.getPreferredSize().height));
        tabs.removeAll();
        tabs.addTab("Monthly Summary", monthly(report));
        tabs.addTab("Expense Breakdown", expenses(report));
        tabs.addTab("Budgets", budgets(report));
        tabs.addTab("Savings Goals", goals(report));
        tabs.addTab("Transactions", transactions(report));
        tabs.setSelectedIndex(selected);
        content.revalidate();
        content.repaint();
    }

    private JComponent monthly(Report report) {
        var model = Ui.tableModel(new String[]{"Month", "Income", "Expenses", "Balance", "Savings activity"},
                new Class<?>[]{YearMonth.class, Long.class, Long.class, Long.class, Long.class});
        JTable table = Ui.table(model);
        for (int column = 1; column < 5; column++) FinanceTables.money(table, column, column >= 3);
        for (var month : report.months()) {
            model.addRow(new Object[]{month.month(), month.income(), month.expenses(), month.balance(), month.savingsActivity()});
        }
        return tableCard("Monthly financial summary", table,
                "Savings activity is contributions minus withdrawals during the selected dates.");
    }

    private JComponent expenses(Report report) {
        JPanel layout = Ui.transparent(new GridLayout(1, 2, 12, 0));
        layout.add(DashboardPanel.chartCard("Expense distribution", null, FinanceCharts.distribution(report.categories())));
        var model = Ui.tableModel(new String[]{"Category", "Expenses"}, new Class<?>[]{String.class, Long.class});
        JTable table = Ui.table(model);
        FinanceTables.money(table, 1, false);
        report.categories().forEach((category, amount) -> model.addRow(new Object[]{category, amount}));
        layout.add(tableCard("Expenses by category", table, null));
        return layout;
    }

    private JComponent budgets(Report report) {
        var model = FinanceTables.budgetModel();
        JTable table = FinanceTables.budgetTable(model);
        FinanceTables.budgetRows(model, report.budgets());
        return tableCard("Budget performance", table, "Usage covers the full month for each listed budget.");
    }

    private JComponent goals(Report report) {
        var model = Ui.tableModel(new String[]{"Goal", "Target", "Saved", "Remaining", "Due", "Progress", "Status"},
                new Class<?>[]{String.class, Long.class, Long.class, Long.class, LocalDate.class, String.class, String.class});
        JTable table = Ui.table(model);
        table.getColumnModel().getColumn(0).setPreferredWidth(180);
        for (int column = 1; column <= 3; column++) FinanceTables.money(table, column, false);
        LocalDate today = LocalDate.now();
        for (SavingsGoal goal : report.goals()) {
            model.addRow(new Object[]{goal.name(), goal.targetAmount(), goal.savedAmount(), goal.remaining(),
                    goal.targetDate(), FinanceTables.percent(goal.percent()), goal.status(today).toString()});
        }
        return tableCard("Savings goal progress", table, "Goal amounts reflect all recorded savings activity.");
    }

    private JComponent transactions(Report report) {
        var table = new FinanceTables.Transactions(false);
        table.set(report.transactions());
        return tableCard("Transaction history", table.table, null);
    }

    private static JComponent tableCard(String title, JTable table, String note) {
        JPanel card = Ui.card(new BorderLayout(0, 10), 14);
        card.add(Ui.label(title, 16, true, Ui.TEXT), BorderLayout.NORTH);
        card.add(FinanceTables.tableScroll(table, 300), BorderLayout.CENTER);
        if (note != null) card.add(Ui.label(note, 12, false, Ui.MUTED), BorderLayout.SOUTH);
        return card;
    }

    private void export() {
        Format selected = (Format) format.getSelectedItem();
        Report snapshot = displayed;
        if (selected == null || snapshot == null) return;
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Save " + selected);
        chooser.setFileFilter(new FileNameExtensionFilter(selected.toString(), selected.extension()));
        chooser.setSelectedFile(new java.io.File(selected.filename()));
        if (chooser.showSaveDialog(owner) != JFileChooser.APPROVE_OPTION) return;
        Path target = chooser.getSelectedFile().toPath();
        String name = target.getFileName().toString();
        if (!name.toLowerCase(Locale.ROOT).endsWith("." + selected.extension())) {
            target = target.resolveSibling(name + "." + selected.extension());
        }
        if (Files.exists(target) && !Ui.confirm(owner, "Replace File", "Replace the existing file " + target.getFileName() + "?")) return;
        final Path destination = target;
        Ui.background(this, export, () -> {
            exporter.export(destination, selected, snapshot);
            return destination;
        }, path -> JOptionPane.showMessageDialog(owner, "Report saved to " + path.toAbsolutePath()));
    }
}
