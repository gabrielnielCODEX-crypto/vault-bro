package com.vaultbro.ui;

import com.vaultbro.controller.FinanceController;
import com.vaultbro.model.*;
import com.vaultbro.util.Ui;
import java.awt.Dimension;
import java.time.LocalDate;
import javax.swing.*;

final class GoalDialog {
    private GoalDialog() {}

    static void edit(MainFrame owner, FinanceController finance, SavingsGoal goal) {
        JPanel form = Ui.column();
        JTextField name = Ui.field(22, "e.g. Emergency fund");
        JComboBox<String> category = new JComboBox<>(Categories.GOALS.toArray(String[]::new));
        JTextField amount = Ui.field(22, "0.00");
        JTextField date = Ui.field(22, "YYYY-MM-DD");
        if (goal != null) {
            name.setText(goal.name());
            category.setSelectedItem(goal.category());
            amount.setText(Money.decimal(goal.targetAmount()));
            date.setText(goal.targetDate().toString());
        } else {
            category.setSelectedIndex(-1);
            date.setText(LocalDate.now().plusMonths(6).toString());
        }
        Ui.fieldRow(form, "Goal name", name);
        Ui.fieldRow(form, "Category", category);
        Ui.fieldRow(form, "Target amount (₱)", amount);
        Ui.fieldRow(form, "Target date (YYYY-MM-DD)", date);
        Ui.formSubmit(owner, goal == null ? "Create Savings Goal" : "Edit Savings Goal", "Save goal", form, () -> {
            finance.saveGoal(goal == null ? 0 : goal.id(), name.getText(), (String) category.getSelectedItem(),
                    amount.getText(), date.getText());
            owner.dataChanged();
        });
    }

    static void entry(MainFrame owner, FinanceController finance, SavingsGoal goal, GoalEntry.Type type) {
        JPanel form = Ui.column();
        JTextField amount = Ui.field(22, "0.00");
        JTextField date = Ui.field(22, "YYYY-MM-DD");
        JTextArea notes = FinanceTables.notes("", 3);
        date.setText(LocalDate.now().toString());
        Ui.stack(form, Ui.label("Available savings  " + Money.format(goal.savedAmount()), 15, true, Ui.LAVENDER), 14);
        Ui.fieldRow(form, "Amount (₱)", amount);
        Ui.fieldRow(form, "Date (YYYY-MM-DD)", date);
        Ui.stack(form, Ui.fieldLabel("Description (optional)", notes), 7);
        Ui.stack(form, new JScrollPane(notes), 13);
        Ui.formSubmit(owner, type == GoalEntry.Type.CONTRIBUTION ? "Add Contribution" : "Record Withdrawal",
                "Save " + type.toString().toLowerCase(java.util.Locale.ROOT), form, () -> {
                    finance.addGoalEntry(goal.id(), type, amount.getText(), date.getText(), notes.getText());
                    owner.dataChanged();
                });
    }

    static void history(MainFrame owner, FinanceController finance, SavingsGoal goal) {
        Ui.run(owner, () -> {
            var entries = finance.goalHistory(goal.id());
            var model = Ui.tableModel(new String[]{"ID", "Date", "Type", "Amount", "Description"},
                    new Class<?>[]{Long.class, LocalDate.class, String.class, Long.class, String.class});
            JTable table = Ui.table(model);
            table.getColumnModel().getColumn(0).setMaxWidth(55);
            table.getColumnModel().getColumn(4).setPreferredWidth(230);
            FinanceTables.money(table, 3, true);
            for (GoalEntry entry : entries) {
                model.addRow(new Object[]{entry.id(), entry.date(), entry.type().toString(), entry.signedAmount(), entry.description()});
            }
            JPanel content = Ui.column();
            Ui.stack(content, Ui.label("Saved balance  " + Money.format(goal.savedAmount()), 17, true, Ui.GREEN), 10);
            if (entries.isEmpty()) {
                Ui.stack(content, Ui.label("No contributions or withdrawals yet.", 14, false, Ui.MUTED), 0);
            } else {
                JScrollPane scroll = FinanceTables.tableScroll(table, 260);
                scroll.setPreferredSize(new Dimension(680, 260));
                Ui.stack(content, scroll, 0);
            }
            JOptionPane.showMessageDialog(owner, content, "Savings History", JOptionPane.PLAIN_MESSAGE);
        });
    }
}
