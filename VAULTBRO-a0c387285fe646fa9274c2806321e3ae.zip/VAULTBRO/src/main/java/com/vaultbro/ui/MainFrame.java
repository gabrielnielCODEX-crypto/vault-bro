package com.vaultbro.ui;

import com.vaultbro.controller.AuthService;
import com.vaultbro.controller.FinanceController;
import com.vaultbro.controller.SessionManager;
import com.vaultbro.model.BudgetUsage;
import com.vaultbro.model.SavingsGoal;
import com.vaultbro.service.FinancialCalculationService;
import com.vaultbro.service.ProfileImages;
import com.vaultbro.util.Ui;
import java.awt.*;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

final class MainFrame extends JFrame {
    enum Page {
        DASHBOARD("Dashboard", Symbol.DASHBOARD, null),
        TRANSACTIONS("Transactions", Symbol.TRANSACTIONS, "Search transactions"),
        BUDGETS("Budgets", Symbol.BUDGETS, "Search budgets"),
        GOALS("Savings Goals", Symbol.GOALS, "Search savings goals"),
        REPORTS("Reports & Analytics", Symbol.REPORTS, null),
        ACCOUNT("Account Settings", Symbol.SETTINGS, null);

        final String label;
        final Symbol symbol;
        final String search;
        Page(String label, Symbol symbol, String search) {
            this.label = label;
            this.symbol = symbol;
            this.search = search;
        }
    }

    interface View {
        void refresh() throws SQLException;
        default void search(String text) {}
    }

    record Alert(String title, String detail, Color color, Page page) {}

    private final SessionManager session;
    private final AuthService auth;
    private final FinanceController finance;
    private final ProfileImages images;
    private final Runnable onLogout;
    private final Map<Page, JButton> navigation = new EnumMap<>(Page.class);
    private final Map<Page, JPanel> panels = new EnumMap<>(Page.class);
    private final Map<Page, String> searches = new EnumMap<>(Page.class);
    private final CardLayout cards = new CardLayout();
    private final JPanel body = new JPanel(cards);
    private final JLabel pageTitle = Ui.label("", 18, true, Ui.TEXT);
    private final JLabel profile = Ui.label("", 13, true, Ui.TEXT);
    private final JTextField search = Ui.field(17, "");
    private final JButton bell = Ui.button("", false, this::showAlerts);
    private List<Alert> alerts = List.of();
    private Page current;
    private boolean switching;

    MainFrame(SessionManager session, AuthService auth, FinanceController finance,
              FinancialCalculationService calculations, ProfileImages images, Runnable onLogout) {
        super("VAULTBRO");
        this.session = session;
        this.auth = auth;
        this.finance = finance;
        this.images = images;
        this.onLogout = onLogout;
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(1040, 670));
        Rectangle bounds = GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds();
        setSize(Math.min(1390, bounds.width), Math.min(920, bounds.height));
        setLocationRelativeTo(null);
        add(sidebar(), BorderLayout.WEST);
        JPanel main = new JPanel(new BorderLayout());
        main.add(topBar(), BorderLayout.NORTH);
        main.add(body, BorderLayout.CENTER);
        add(main, BorderLayout.CENTER);
        addPage(Page.DASHBOARD, new DashboardPanel(this, calculations, session));
        addPage(Page.TRANSACTIONS, new TransactionPanel(this, finance));
        addPage(Page.BUDGETS, new BudgetPanel(this, finance));
        addPage(Page.GOALS, new GoalPanel(this, finance));
        addPage(Page.REPORTS, new ReportsPanel(this, calculations));
        addPage(Page.ACCOUNT, new AccountSettingsPanel(this, auth, session, images));
        updateProfile();
        Ui.run(this, this::updateAlerts);
        showPage(Page.DASHBOARD);
    }

    private void addPage(Page page, JPanel panel) {
        panels.put(page, panel);
        body.add(panel, page.name());
    }

    private JPanel sidebar() {
        JPanel sidebar = new JPanel(new BorderLayout());
        sidebar.setBackground(Ui.SIDEBAR);
        sidebar.setPreferredSize(new Dimension(227, 0));
        sidebar.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, Ui.BORDER));
        JPanel links = Ui.column();
        links.setBorder(new EmptyBorder(25, 15, 0, 15));
        JLabel mark = AuthLayout.wordmark(19);
        mark.setBorder(new EmptyBorder(0, 8, 0, 0));
        Ui.stack(links, mark, 37);
        for (Page page : Page.values()) {
            JButton button = navButton(page.label, page.symbol, () -> showPage(page));
            navigation.put(page, button);
            Ui.stack(links, button, 7);
        }
        sidebar.add(links, BorderLayout.NORTH);
        JPanel bottom = Ui.column();
        bottom.setBorder(new EmptyBorder(0, 15, 20, 15));
        Ui.stack(bottom, new JSeparator(), 14);
        Ui.stack(bottom, navButton("Logout", Symbol.LOGOUT, this::logout), 0);
        sidebar.add(bottom, BorderLayout.SOUTH);
        return sidebar;
    }

    private JButton navButton(String label, Symbol icon, Runnable action) {
        JButton button = Ui.button(label, false, action);
        button.setIcon(icon.icon(Ui.MUTED, 18));
        button.setIconTextGap(9);
        button.setMargin(new Insets(9, 11, 9, 8));
        button.setHorizontalAlignment(SwingConstants.LEFT);
        button.setPreferredSize(new Dimension(180, 43));
        button.setBackground(Ui.SIDEBAR);
        button.setForeground(Ui.MUTED);
        button.putClientProperty("FlatLaf.style", "borderColor: #141521; hoverBackground: #222437");
        return button;
    }

    private JPanel topBar() {
        JPanel bar = new JPanel(new BorderLayout(15, 0));
        bar.setBackground(Ui.SIDEBAR);
        bar.setPreferredSize(new Dimension(0, 65));
        bar.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Ui.BORDER),
                new EmptyBorder(0, 30, 0, 27)));
        bar.add(pageTitle, BorderLayout.WEST);
        JPanel right = Ui.transparent(new FlowLayout(FlowLayout.RIGHT, 14, 0));
        search.setPreferredSize(new Dimension(225, 35));
        search.putClientProperty("JTextField.leadingIcon", Symbol.SEARCH.icon(Ui.MUTED, 16));
        Ui.changed(search, () -> {
            if (switching || current == null || current.search == null) return;
            searches.put(current, search.getText());
            view(current).search(search.getText());
        });
        bell.setPreferredSize(new Dimension(48, 34));
        bell.getAccessibleContext().setAccessibleName("Notifications");
        bell.setMargin(new Insets(3, 5, 3, 5));
        right.add(search);
        right.add(bell);
        right.add(profile);
        JPanel alignment = Ui.transparent(new GridBagLayout());
        alignment.add(right);
        bar.add(alignment, BorderLayout.EAST);
        return bar;
    }

    void showPage(Page page) {
        switching = true;
        current = page;
        pageTitle.setText(page.label);
        search.setVisible(page.search != null);
        search.putClientProperty("JTextField.placeholderText", page.search);
        search.getAccessibleContext().setAccessibleName(page.search);
        search.setText(searches.getOrDefault(page, ""));
        navigation.forEach((item, button) -> {
            boolean active = item == page;
            button.setBackground(active ? Ui.color(0x30234F) : Ui.SIDEBAR);
            button.setForeground(active ? Ui.LAVENDER : Ui.MUTED);
            button.setIcon(item.symbol.icon(active ? Ui.LAVENDER : Ui.MUTED, 18));
        });
        switching = false;
        cards.show(body, page.name());
        Ui.run(this, view(page)::refresh);
    }

    private View view(Page page) { return (View) panels.get(page); }

    void dataChanged() {
        Ui.run(this, () -> {
            updateAlerts();
            view(current).refresh();
        });
    }

    void updateProfile() {
        var user = session.user();
        String name = user.fullName();
        int length = name.codePointCount(0, name.length());
        profile.setText(length > 23 ? name.substring(0, name.offsetByCodePoints(0, 22)) + "…" : name);
        profile.setToolTipText(name);
        profile.setIcon(Ui.avatar(name, images.load(user.id(), user.profileImagePath()), 32));
        profile.setIconTextGap(9);
    }

    List<Alert> alerts() { return alerts; }

    private void updateAlerts() throws SQLException {
        List<Alert> updated = new ArrayList<>();
        YearMonth month = YearMonth.now();
        var budgets = finance.budgets().stream()
                .filter(usage -> usage.status() != BudgetUsage.Status.ON_TRACK)
                .sorted(Comparator.comparing(usage -> !usage.budget().period().equals(month))).toList();
        for (BudgetUsage usage : budgets) {
            updated.add(new Alert(usage.budget().category() + " · " + usage.status(),
                    String.format(java.util.Locale.ROOT, "%s · %.1f%% of limit used", usage.budget().period(), usage.percent()),
                    usage.status() == BudgetUsage.Status.OVER_BUDGET ? Ui.RED : Ui.AMBER, Page.BUDGETS));
        }
        LocalDate today = LocalDate.now();
        for (SavingsGoal goal : finance.goals()) {
            if (goal.status(today) == SavingsGoal.Status.OVERDUE) {
                updated.add(new Alert(goal.name() + " · Overdue", "Target date " + goal.targetDate(), Ui.AMBER, Page.GOALS));
            }
        }
        alerts = List.copyOf(updated);
        bell.setIcon(Symbol.BELL.icon(alerts.isEmpty() ? Ui.MUTED : Ui.AMBER, 17));
        bell.setText(alerts.isEmpty() ? "" : alerts.size() > 9 ? "9+" : Integer.toString(alerts.size()));
        bell.setToolTipText(alerts.size() + " financial alerts");
    }

    private void showAlerts() {
        Ui.run(this, () -> {
            updateAlerts();
            JPopupMenu popup = new JPopupMenu();
            if (alerts.isEmpty()) {
                JMenuItem empty = new JMenuItem("No active financial alerts");
                empty.setEnabled(false);
                popup.add(empty);
            } else {
                JPanel list = Ui.column();
                for (Alert alert : alerts) {
                    JButton item = Ui.button(alert.title(), false, () -> {
                        popup.setVisible(false);
                        showPage(alert.page());
                    });
                    item.setHorizontalAlignment(SwingConstants.LEFT);
                    item.setToolTipText(alert.detail());
                    item.setForeground(alert.color());
                    Ui.stack(list, item, 3);
                }
                JScrollPane scroll = Ui.scroll(list);
                scroll.setPreferredSize(new Dimension(355, Math.min(300, list.getPreferredSize().height + 10)));
                popup.add(scroll);
            }
            popup.show(bell, bell.getWidth() - popup.getPreferredSize().width, bell.getHeight());
        });
    }

    void logout() {
        if (Ui.confirm(this, "Log out", "Log out of VAULTBRO?")) {
            auth.logout();
            dispose();
            onLogout.run();
        }
    }
}
