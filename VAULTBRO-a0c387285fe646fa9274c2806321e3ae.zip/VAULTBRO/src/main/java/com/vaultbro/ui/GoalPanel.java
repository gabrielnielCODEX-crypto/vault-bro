package com.vaultbro.ui;

import com.vaultbro.controller.FinanceController;
import com.vaultbro.model.*;
import com.vaultbro.util.Ui;
import java.awt.*;
import java.awt.geom.Arc2D;
import java.awt.geom.Ellipse2D;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Locale;
import javax.swing.*;

final class GoalPanel extends JPanel implements MainFrame.View {
    private final MainFrame owner;
    private final FinanceController finance;
    private final JPanel content = Ui.column();
    private final JPanel grid = Ui.transparent(new GridLayout(0, 2, 15, 15));
    private final JComboBox<String> category = new JComboBox<>();
    private final JComboBox<String> status = new JComboBox<>(new String[]{"All statuses", "In Progress", "Achieved", "Overdue"});
    private final JLabel count = Ui.label("", 13, false, Ui.MUTED);
    private List<SavingsGoal> all = List.of();
    private String query = "";

    GoalPanel(MainFrame owner, FinanceController finance) {
        super(new BorderLayout());
        this.owner = owner;
        this.finance = finance;
        JButton create = Ui.button("New savings goal", true, () -> GoalDialog.edit(owner, finance, null));
        create.setIcon(Symbol.PLUS.icon(Color.WHITE, 17));
        Ui.stack(content, Ui.pageHeading("Savings Goals", "Set targets and track every contribution or withdrawal.", create), 18);
        JPanel filters = Ui.card(new BorderLayout(), 12);
        JPanel left = Ui.transparent(new FlowLayout(FlowLayout.LEFT, 7, 0));
        category.addItem("All categories");
        Categories.GOALS.forEach(category::addItem);
        left.add(category);
        left.add(status);
        category.addActionListener(event -> filter());
        status.addActionListener(event -> filter());
        filters.add(left, BorderLayout.WEST);
        filters.add(count, BorderLayout.EAST);
        Ui.stack(content, filters, 15);
        content.add(grid);
        add(Ui.page(content));
    }

    @Override public void refresh() throws SQLException {
        all = finance.goals();
        filter();
    }

    @Override public void search(String text) {
        query = text.strip().toLowerCase(Locale.ROOT);
        filter();
    }

    private void filter() {
        LocalDate today = LocalDate.now();
        List<SavingsGoal> filtered = all.stream()
                .filter(goal -> category.getSelectedIndex() == 0 || goal.category().equals(category.getSelectedItem()))
                .filter(goal -> status.getSelectedIndex() == 0 || goal.status(today).toString().equals(status.getSelectedItem()))
                .filter(goal -> (goal.name() + " " + goal.category()).toLowerCase(Locale.ROOT).contains(query))
                .toList();
        count.setText(filtered.size() + (filtered.size() == 1 ? " goal" : " goals"));
        grid.removeAll();
        if (filtered.isEmpty()) {
            JPanel blank = Ui.card(new GridBagLayout(), 30);
            blank.add(Ui.label("No savings goals match these filters.", 14, false, Ui.MUTED));
            grid.add(blank);
        } else {
            for (SavingsGoal goal : filtered) grid.add(goalCard(goal, today));
        }
        grid.setAlignmentX(Component.LEFT_ALIGNMENT);
        grid.setMaximumSize(new Dimension(Short.MAX_VALUE, grid.getPreferredSize().height));
        content.revalidate();
        content.repaint();
    }

    private JPanel goalCard(SavingsGoal goal, LocalDate today) {
        SavingsGoal.Status state = goal.status(today);
        Color color = FinanceTables.goalColor(state);
        JPanel card = Ui.card(new BorderLayout(0, 14), 15);
        JPanel summary = Ui.transparent(new BorderLayout(10, 0));
        JPanel name = Ui.column();
        JLabel title = Ui.label(goal.name(), 19, true, Ui.TEXT);
        title.setToolTipText(goal.name());
        title.setPreferredSize(new Dimension(220, title.getPreferredSize().height));
        Ui.stack(name, Ui.label(goal.category(), 12, true, Ui.MUTED), 5);
        Ui.stack(name, title, 5);
        Ui.stack(name, Ui.label(state.toString(), 13, true, color), 0);
        summary.add(name);
        summary.add(new Ring(goal.percent(), color), BorderLayout.EAST);
        card.add(summary, BorderLayout.NORTH);
        JPanel amounts = Ui.column();
        Ui.stack(amounts, Ui.label(Money.format(goal.savedAmount()) + " saved", 19, true, Ui.TEXT), 6);
        Ui.stack(amounts, Ui.label("Target  " + Money.format(goal.targetAmount()), 13, false, Ui.MUTED), 5);
        String remaining = goal.remaining() < 0
                ? Money.format(-goal.remaining()) + " above target" : Money.format(goal.remaining()) + " remaining";
        Ui.stack(amounts, Ui.label(remaining, 13, false, Ui.MUTED), 8);
        Ui.stack(amounts, Ui.progress(goal.percent(), color), 11);
        Ui.stack(amounts, Ui.label("Target date  " + goal.targetDate(), 13, false, Ui.MUTED), 6);
        if (goal.remaining() > 0 && !goal.targetDate().isAfter(today)) {
            Ui.stack(amounts, Ui.label("Amount due  " + Money.format(goal.remaining()), 12, false, Ui.AMBER), 0);
        } else {
            Ui.stack(amounts, Ui.label(Money.format(goal.monthlySavings(today)) + " / month   ·   "
                    + Money.format(goal.weeklySavings(today)) + " / week", 12, false, Ui.MUTED), 0);
        }
        card.add(amounts);
        JPanel buttons = Ui.transparent(new FlowLayout(FlowLayout.LEFT, 5, 0));
        JButton contribute = Ui.button("Contribute", true,
                () -> GoalDialog.entry(owner, finance, goal, GoalEntry.Type.CONTRIBUTION));
        JButton history = Ui.button("History", false, () -> GoalDialog.history(owner, finance, goal));
        JButton more = Ui.button("More", false, null);
        JPopupMenu menu = new JPopupMenu();
        addMenu(menu, "Withdraw", () -> GoalDialog.entry(owner, finance, goal, GoalEntry.Type.WITHDRAWAL));
        addMenu(menu, "Edit goal", () -> GoalDialog.edit(owner, finance, goal));
        addMenu(menu, "Delete goal", () -> delete(goal));
        more.addActionListener(event -> menu.show(more, 0, more.getHeight()));
        buttons.add(contribute);
        buttons.add(history);
        buttons.add(more);
        card.add(buttons, BorderLayout.SOUTH);
        return card;
    }

    private static void addMenu(JPopupMenu menu, String title, Runnable action) {
        JMenuItem item = new JMenuItem(title);
        item.addActionListener(event -> action.run());
        menu.add(item);
    }

    private void delete(SavingsGoal goal) {
        if (Ui.confirm(owner, "Delete Savings Goal", "Delete this savings goal and its contribution and withdrawal history?")) {
            Ui.run(this, () -> {
                finance.deleteGoal(goal.id());
                owner.dataChanged();
            });
        }
    }

    private static final class Ring extends JComponent {
        private final double percent;
        private final Color color;

        Ring(double percent, Color color) {
            this.percent = percent;
            this.color = color;
            setPreferredSize(new Dimension(66, 66));
            setToolTipText(FinanceTables.percent(percent) + " of target saved");
        }

        @Override protected void paintComponent(Graphics graphics) {
            Graphics2D draw = (Graphics2D) graphics.create();
            draw.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            double size = 52;
            double x = (getWidth() - size) / 2;
            double y = (getHeight() - size) / 2;
            draw.setStroke(new BasicStroke(5, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            draw.setColor(Ui.CONTROL);
            draw.draw(new Ellipse2D.Double(x, y, size, size));
            draw.setColor(color);
            if (percent > 0) draw.draw(new Arc2D.Double(x, y, size, size, 90, -Math.min(360, percent * 3.6), Arc2D.OPEN));
            draw.setFont(new Font("SansSerif", Font.BOLD, 12));
            String value = percent >= 1000 ? "999%+" : FinanceTables.percent(percent).replace(".0%", "%");
            FontMetrics metrics = draw.getFontMetrics();
            draw.drawString(value, (getWidth() - metrics.stringWidth(value)) / 2,
                    (getHeight() - metrics.getHeight()) / 2 + metrics.getAscent());
            draw.dispose();
        }
    }
}
