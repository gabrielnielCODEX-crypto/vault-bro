package com.vaultbro.ui;

import com.vaultbro.service.FinancialCalculationService.MonthSummary;
import com.vaultbro.util.Ui;
import java.awt.*;
import java.text.DecimalFormat;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.swing.*;
import org.jfree.chart.*;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.RingPlot;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.chart.renderer.category.StandardBarPainter;
import org.jfree.chart.ui.RectangleEdge;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;

final class FinanceCharts {
    private static final Color[] PALETTE = {Ui.color(0x9D7EF7), Ui.CYAN, Ui.GREEN, Ui.AMBER, Ui.RED,
            Ui.color(0x7286EF), Ui.color(0xE29DE9), Ui.color(0x4BA7AD)};

    private FinanceCharts() {}

    static JComponent cashFlow(List<MonthSummary> months) {
        DefaultCategoryDataset data = new DefaultCategoryDataset();
        for (MonthSummary month : months) {
            String label = month.month().format(DateTimeFormatter.ofPattern("MMM", Locale.ENGLISH));
            data.addValue(month.income() / 100.0, "Income", label);
            data.addValue(month.expenses() / 100.0, "Expenses", label);
        }
        JFreeChart chart = ChartFactory.createBarChart(null, null, null, data,
                PlotOrientation.VERTICAL, true, true, false);
        CategoryPlot plot = prepare(chart);
        BarRenderer renderer = (BarRenderer) plot.getRenderer();
        renderer.setSeriesPaint(0, Ui.GREEN);
        renderer.setSeriesPaint(1, Ui.color(0x9A77F3));
        renderer.setBarPainter(new StandardBarPainter());
        renderer.setShadowVisible(false);
        renderer.setMaximumBarWidth(.06);
        renderer.setItemMargin(.12);
        return panel(chart, 190);
    }

    static JComponent trend(List<MonthSummary> months) {
        DefaultCategoryDataset data = new DefaultCategoryDataset();
        for (MonthSummary month : months) {
            String label = month.month().format(DateTimeFormatter.ofPattern("MMM", Locale.ENGLISH));
            data.addValue(month.expenses() / 100.0, "Expenses", label);
        }
        JFreeChart chart = ChartFactory.createLineChart(null, null, null, data,
                PlotOrientation.VERTICAL, false, true, false);
        CategoryPlot plot = prepare(chart);
        LineAndShapeRenderer renderer = (LineAndShapeRenderer) plot.getRenderer();
        renderer.setSeriesPaint(0, Ui.CYAN);
        renderer.setSeriesStroke(0, new BasicStroke(2.6f));
        renderer.setDefaultShapesVisible(true);
        return panel(chart, 170);
    }

    static JComponent distribution(Map<String, Long> categories) {
        if (categories.isEmpty()) return empty("No expenses recorded for this period.", 190);
        DefaultPieDataset<String> data = new DefaultPieDataset<>();
        categories.forEach((category, amount) -> data.setValue(category, amount / 100.0));
        return doughnut(data, PALETTE, 190);
    }

    static JComponent saved(long saved, long remaining, boolean hasGoals) {
        if (!hasGoals) return empty("No savings goals yet.", 170);
        DefaultPieDataset<String> data = new DefaultPieDataset<>();
        data.setValue("Saved", saved / 100.0);
        data.setValue("Remaining", remaining / 100.0);
        return doughnut(data, new Color[]{Ui.LAVENDER, Ui.CONTROL}, 170);
    }

    private static JComponent doughnut(DefaultPieDataset<String> data, Color[] colors, int height) {
        JFreeChart chart = ChartFactory.createRingChart(null, data, true, true, false);
        base(chart);
        RingPlot plot = (RingPlot) chart.getPlot();
        plot.setBackgroundPaint(Ui.CARD);
        plot.setOutlineVisible(false);
        plot.setShadowPaint(null);
        plot.setSeparatorsVisible(false);
        plot.setSectionOutlinesVisible(false);
        plot.setLabelGenerator(null);
        plot.setIgnoreZeroValues(false);
        plot.setSectionDepth(.31);
        for (int index = 0; index < data.getItemCount(); index++) {
            plot.setSectionPaint(data.getKey(index), colors[index % colors.length]);
        }
        return panel(chart, height);
    }

    private static CategoryPlot prepare(JFreeChart chart) {
        base(chart);
        CategoryPlot plot = chart.getCategoryPlot();
        plot.setBackgroundPaint(Ui.CARD);
        plot.setOutlineVisible(false);
        plot.setRangeGridlinePaint(Ui.BORDER);
        plot.getDomainAxis().setTickLabelPaint(Ui.MUTED);
        plot.getDomainAxis().setAxisLinePaint(Ui.BORDER);
        plot.getDomainAxis().setTickMarksVisible(false);
        NumberAxis axis = (NumberAxis) plot.getRangeAxis();
        axis.setTickLabelPaint(Ui.MUTED);
        axis.setAxisLineVisible(false);
        axis.setTickMarksVisible(false);
        axis.setNumberFormatOverride(new DecimalFormat("₱#,##0.##"));
        return plot;
    }

    private static void base(JFreeChart chart) {
        chart.setBackgroundPaint(Ui.CARD);
        chart.setAntiAlias(true);
        if (chart.getLegend() != null) {
            chart.getLegend().setBackgroundPaint(Ui.CARD);
            chart.getLegend().setItemPaint(Ui.MUTED);
            chart.getLegend().setPosition(RectangleEdge.BOTTOM);
        }
    }

    private static ChartPanel panel(JFreeChart chart, int height) {
        ChartPanel panel = new ChartPanel(chart, false);
        panel.setMinimumDrawWidth(100);
        panel.setMinimumDrawHeight(100);
        panel.setPreferredSize(new Dimension(250, height));
        panel.setOpaque(false);
        return panel;
    }

    private static JPanel empty(String message, int height) {
        JPanel panel = Ui.transparent(new GridBagLayout());
        panel.add(Ui.label(message, 13, false, Ui.MUTED));
        panel.setPreferredSize(new Dimension(250, height));
        return panel;
    }
}
