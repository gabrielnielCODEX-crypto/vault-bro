package com.vaultbro.ui;

import com.vaultbro.controller.SessionManager;
import com.vaultbro.model.*;
import com.vaultbro.service.FinancialCalculationService;
import com.vaultbro.service.FinancialCalculationService.Totals;
import com.vaultbro.util.Ui;
import java.awt.*;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import javax.swing.*;

final class DashboardPanel extends JPanel implements MainFrame.View {
    private final MainFrame owner;
    private final FinancialCalculationService calculations;
    private final SessionManager session;
    private final JPanel content = Ui.column();

    DashboardPanel(MainFrame owner, FinancialCalculationService calculations, SessionManager session) {
        super(new BorderLayout());
        this.owner = owner;
        this.calculations = calculations;
        this.session = session;
        add(Ui.page(content));
    }

    @Override public void refresh() throws SQLException {
        YearMonth month = YearMonth.now();
        var report = calculations.report(DateRange.ALL);
        List<Transaction> monthlyTransactions = report.transactions().stream()
                .filter(transaction -> YearMonth.from(transaction.getDate()).equals(month)).toList();
        var monthly = FinancialCalculationService.totals(monthlyTransactions, report.goals());
        var history = FinancialCalculationService.trailingMonths(report.months(), month, 6);
        String name = session.user().fullName().strip().split("\\s+", 2)[0];
        int nameLength = name.codePointCount(0, name.length());
        if (nameLength > 25) name = name.substring(0, name.offsetByCodePoints(0, 24)) + "…";
        JLabel period = Ui.label(month.format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale.ENGLISH)), 13, true, Ui.MUTED);
        period.setIcon(Symbol.CALENDAR.icon(Ui.LAVENDER, 17));
        period.setIconTextGap(7);
        JPanel dateBadge = Ui.card(new GridBagLayout(), 10);
        dateBadge.add(period);

        content.removeAll();
        Ui.stack(content, Ui.pageHeading("Welcome, " + name, "Here’s where your finances stand today.", dateBadge), 21);
        Ui.stack(content, stats(report.totals()), 16);

        JPanel visual = Ui.transparent(new GridLayout(1, 2, 15, 0));
        visual.add(chartCard("Income vs expenses", "Last 6 months", FinanceCharts.cashFlow(history)));
        visual.add(chartCard("Expense distribution", "Current month",
                FinanceCharts.distribution(FinancialCalculationService.expenseCategories(monthlyTransactions))));
        Ui.stack(content, visual, 16);
        JPanel analytics = Ui.transparent(new GridLayout(1, 2, 15, 0));
        analytics.add(chartCard("Monthly expense trend", "Last 6 months", FinanceCharts.trend(history)));
        long remaining = report.goals().stream().mapToLong(goal -> Math.max(0, goal.remaining())).sum();
        long towardTargets = report.goals().stream().mapToLong(goal -> Math.min(goal.savedAmount(), goal.targetAmount())).sum();
        analytics.add(chartCard("Savings progress", "Across all savings goals",
                FinanceCharts.saved(towardTargets, remaining, !report.goals().isEmpty())));
        Ui.stack(content, analytics, 16);

        JPanel recentAndBudgets = Ui.transparent(new GridLayout(1, 2, 15, 0));
        recentAndBudgets.add(recent(report.transactions()));
        recentAndBudgets.add(budgetUsage(report.budgets().stream().filter(usage -> usage.budget().period().equals(month)).toList()));
        Ui.stack(content, recentAndBudgets, 16);
        JPanel summaryAndAlerts = Ui.transparent(new GridLayout(1, 2, 15, 0));
        summaryAndAlerts.add(monthlySummary(monthly, monthlyTransactions.size()));
        summaryAndAlerts.add(alertCard());
        Ui.stack(content, summaryAndAlerts, 0);
        content.revalidate();
        content.repaint();
    }

    static JPanel stats(Totals totals) {
        JPanel cards = Ui.transparent(new GridLayout(1, 4, 13, 0));
        cards.add(metric("Total balance", totals.balance(), Symbol.WALLET, Ui.LAVENDER));
        cards.add(metric("Total income", totals.income(), Symbol.INCOME, Ui.GREEN));
        cards.add(metric("Total expenses", totals.expenses(), Symbol.EXPENSE, Ui.RED));
        cards.add(metric("Total savings", totals.savings(), Symbol.SAVINGS, Ui.CYAN));
        return cards;
    }

    private static JPanel metric(String name, long amount, Symbol symbol, Color color) {
        JPanel card = Ui.card(new BorderLayout(6, 13), 15);
        JLabel title = Ui.label(name, 13, true, Ui.MUTED);
        title.setIcon(symbol.icon(color, 18));
        title.setIconTextGap(8);
        card.add(title, BorderLayout.NORTH);
        JLabel value = Ui.label(Money.format(amount), 23, true, Ui.TEXT);
        value.setToolTipText(value.getText());
        card.add(value, BorderLayout.CENTER);
        return card;
    }

    static JPanel chartCard(String title, String description, JComponent chart) {
        JPanel card = Ui.card(new BorderLayout(0, 10), 16);
        JPanel heading = Ui.column();
        Ui.stack(heading, Ui.label(title, 17, true, Ui.TEXT), 5);
        if (description != null) Ui.stack(heading, Ui.label(description, 12, false, Ui.MUTED), 0);
        card.add(heading, BorderLayout.NORTH);
        card.add(chart, BorderLayout.CENTER);
        return card;
    }

    private JPanel monthlySummary(Totals monthly, int count) {
        JPanel details = Ui.column();
        Ui.stack(details, labelValue("Income", Money.format(monthly.income()), Ui.GREEN), 10);
        Ui.stack(details, labelValue("Expenses", Money.format(monthly.expenses()), Ui.RED), 10);
        Ui.stack(details, labelValue("Net balance", Money.format(monthly.balance()), Ui.TEXT), 0);
        return chartCard("Monthly summary", count + (count == 1 ? " transaction this month" : " transactions this month"), details);
    }

    private JPanel budgetUsage(List<BudgetUsage> current) {
        JPanel details = Ui.column();
        if (current.isEmpty()) {
            Ui.stack(details, Ui.label("No spending limits set for this month.", 13, false, Ui.MUTED), 0);
        }
        for (BudgetUsage usage : current.stream().limit(3).toList()) {
            Color color = FinanceTables.budgetColor(usage.status());
            Ui.stack(details, labelValue(usage.budget().category(), FinanceTables.percent(usage.percent()), color), 5);
            Ui.stack(details, Ui.progress(usage.percent(), color), 9);
        }
        if (current.size() > 3) Ui.stack(details, Ui.button("View all budgets", false, () -> owner.showPage(MainFrame.Page.BUDGETS)), 0);
        return chartCard("Budget utilization", "Current month", details);
    }

    private JPanel recent(List<Transaction> transactions) {
        JPanel card = Ui.card(new BorderLayout(0, 10), 16);
        JPanel heading = Ui.transparent(new BorderLayout());
        heading.add(Ui.label("Recent transactions", 17, true, Ui.TEXT), BorderLayout.WEST);
        heading.add(Ui.button("View transactions", false, () -> owner.showPage(MainFrame.Page.TRANSACTIONS)), BorderLayout.EAST);
        card.add(heading, BorderLayout.NORTH);
        if (transactions.isEmpty()) {
            card.add(Ui.label("No transactions yet. Add one to start tracking your finances.", 13, false, Ui.MUTED));
        } else {
            FinanceTables.Transactions records = new FinanceTables.Transactions(true);
            records.set(transactions.stream().limit(5).toList());
            card.add(FinanceTables.tableScroll(records.table, 37 + Math.min(5, transactions.size()) * 40));
        }
        return card;
    }

    private JPanel alertCard() {
        JPanel messages = Ui.column();
        if (owner.alerts().isEmpty()) {
            Ui.stack(messages, Ui.label("No active alerts.", 13, false, Ui.MUTED), 0);
        }
        for (MainFrame.Alert alert : owner.alerts().stream().limit(5).toList()) {
            JButton button = Ui.button(alert.title(), false, () -> owner.showPage(alert.page()));
            button.setForeground(alert.color());
            button.setHorizontalAlignment(SwingConstants.LEFT);
            button.setToolTipText(alert.detail());
            Ui.stack(messages, button, 5);
        }
        return chartCard("Financial alerts", null, messages);
    }

    private static JPanel labelValue(String label, String value, Color color) {
        JPanel row = Ui.transparent(new BorderLayout(6, 0));
        row.add(Ui.label(label, 13, false, Ui.MUTED), BorderLayout.WEST);
        row.add(Ui.label(value, 13, true, color), BorderLayout.EAST);
        return row;
    }
}
