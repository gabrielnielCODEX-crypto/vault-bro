package com.vaultbro.ui;

import com.vaultbro.controller.FinanceController;
import com.vaultbro.model.*;
import com.vaultbro.util.Ui;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.util.LinkedHashSet;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

final class TransactionPanel extends JPanel implements MainFrame.View {
    private final MainFrame owner;
    private final FinanceController finance;
    private final JComboBox<String> type = new JComboBox<>(new String[]{"All types", "Income", "Expense"});
    private final JComboBox<String> category = new JComboBox<>();
    private final FinanceTables.Transactions records = new FinanceTables.Transactions(false);
    private final JLabel count = Ui.label("", 13, true, Ui.MUTED);
    private final JLabel empty = Ui.label("No transactions match these filters.", 14, false, Ui.MUTED);
    private final CardLayout recordCards = new CardLayout();
    private final JPanel tableBody = Ui.transparent(recordCards);
    private List<Transaction> source = List.of();
    private String query = "";
    private DateRange range = DateRange.ALL;

    TransactionPanel(MainFrame owner, FinanceController finance) {
        super(new BorderLayout(0, 17));
        this.owner = owner;
        this.finance = finance;
        setBorder(new EmptyBorder(24, 30, 24, 30));
        JButton add = Ui.button("Add transaction", true, () -> TransactionDialog.show(owner, finance, null));
        add.setIcon(Symbol.PLUS.icon(Color.WHITE, 17));
        JPanel top = Ui.column();
        Ui.stack(top, Ui.pageHeading("Transactions", "Track and manage your income and expenses.", add), 18);
        JPanel filters = Ui.card(new GridLayout(0, 1, 0, 8), 12);
        JPanel choices = Ui.transparent(new FlowLayout(FlowLayout.LEFT, 7, 0));
        choices.add(Ui.fieldLabel("Type", type));
        choices.add(type);
        choices.add(Ui.fieldLabel("Category", category));
        choices.add(category);
        filters.add(choices);
        filters.add(new DateFilter(value -> {
            range = value;
            Ui.run(this, this::refresh);
        }));
        Ui.stack(top, filters, 0);
        add(top, BorderLayout.NORTH);

        JPanel card = Ui.card(new BorderLayout(0, 9), 15);
        JPanel tableHead = Ui.transparent(new BorderLayout());
        tableHead.add(count, BorderLayout.WEST);
        JButton details = Ui.button("Details", false, () -> TransactionDialog.details(owner, selected()));
        JButton edit = Ui.button("Edit", false, () -> TransactionDialog.show(owner, finance, selected()));
        JButton delete = Ui.button("Delete", false, this::delete);
        delete.setForeground(Ui.RED);
        for (JButton button : new JButton[]{details, edit, delete}) button.setEnabled(false);
        records.table.getSelectionModel().addListSelectionListener(event -> {
            boolean enabled = records.table.getSelectedRow() >= 0;
            for (JButton button : new JButton[]{details, edit, delete}) button.setEnabled(enabled);
        });
        records.table.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent event) {
                if (event.getClickCount() == 2 && records.table.rowAtPoint(event.getPoint()) >= 0) details.doClick();
            }
        });
        tableHead.add(Ui.actions(details, edit, delete), BorderLayout.EAST);
        card.add(tableHead, BorderLayout.NORTH);
        tableBody.add(FinanceTables.tableScroll(records.table, 320), "table");
        JPanel blank = Ui.transparent(new GridBagLayout());
        blank.add(empty);
        tableBody.add(blank, "empty");
        card.add(tableBody);
        add(card);
        categories();
        type.addActionListener(event -> {
            categories();
            Ui.run(this, this::refresh);
        });
        category.addActionListener(event -> Ui.run(this, this::refresh));
    }

    @Override public void search(String text) {
        query = text;
        Ui.run(this, this::refresh);
    }

    @Override public void refresh() throws SQLException {
        source = finance.searchTransactions(query, selectedType(),
                category.getSelectedIndex() <= 0 ? null : (String) category.getSelectedItem(), range);
        records.set(source);
        count.setText(source.size() + (source.size() == 1 ? " transaction" : " transactions"));
        recordCards.show(tableBody, source.isEmpty() ? "empty" : "table");
    }

    private Transaction.Type selectedType() {
        return switch (type.getSelectedIndex()) {
            case 1 -> Transaction.Type.INCOME;
            case 2 -> Transaction.Type.EXPENSE;
            default -> null;
        };
    }

    private void categories() {
        var options = new LinkedHashSet<String>();
        options.add("All categories");
        if (selectedType() != Transaction.Type.EXPENSE) options.addAll(Categories.INCOME);
        if (selectedType() != Transaction.Type.INCOME) options.addAll(Categories.EXPENSES);
        category.setModel(new DefaultComboBoxModel<>(options.toArray(String[]::new)));
    }

    private Transaction selected() {
        return source.get(records.table.convertRowIndexToModel(records.table.getSelectedRow()));
    }

    private void delete() {
        Transaction record = selected();
        if (Ui.confirm(owner, "Delete Transaction", "Permanently delete transaction #" + record.getId() + "?")) {
            Ui.run(this, () -> {
                finance.deleteTransaction(record.getId());
                owner.dataChanged();
            });
        }
    }
}
