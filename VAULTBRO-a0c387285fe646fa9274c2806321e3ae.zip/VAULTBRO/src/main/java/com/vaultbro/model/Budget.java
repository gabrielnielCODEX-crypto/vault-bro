package com.vaultbro.model;

import java.time.YearMonth;

public record Budget(long id, String category, long monthlyLimit, YearMonth period) {
    public static final String OVERALL = "Overall";
}
