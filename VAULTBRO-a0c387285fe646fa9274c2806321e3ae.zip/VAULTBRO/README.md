# VAULTBRO

**VAULTBRO: A Java-Based Personal Expense Tracking and Budget Management System**

*Take Control. Stack Smarter.*

VAULTBRO is a Java Swing desktop application for recording income and expenses, setting monthly spending limits, tracking savings goals, and exporting financial reports in Philippine pesos (PHP). SQLite stores data locally. FlatLaf provides the dark theme, JFreeChart renders the charts, and BCrypt hashes account passwords.

## Run in Visual Studio Code

1. Install a **JDK 17 or later** and the **Extension Pack for Java** (`vscjava.vscode-java-pack`).
2. Open the `VAULTBRO` folder that contains `pom.xml` in VS Code.
3. Wait for VS Code to finish importing the Maven project and downloading dependencies.
4. In **Run and Debug**, choose **Launch VAULTBRO** and press **F5**. You can also open `src/main/java/com/vaultbro/ui/Main.java` and select **Run** above `main`.
5. Select **Create an account** to register, then sign in with your username or email.

## Build from a terminal

With JDK 17 or later and Maven 3.9 or later on your PATH, run from the project folder:

```sh
mvn clean package
java -jar target/vaultbro.jar
```

The runnable JAR bundles the application dependencies. The desktop application requires a graphical session. The first Maven build needs access to Maven Central.

## Data and calculations

- On first launch, SQLite creates `.vaultbro/vaultbro.db` in your operating system user home directory. Imported profile photos are stored in `.vaultbro/profile-images`.
- Each operation on financial records uses the signed-in account's ID. SQLite foreign keys enforce ownership relationships. The database and exported files are local files protected by your operating system's file permissions.
- To run with a different database, set the `vaultbro.db` system property. Choose a separate directory when testing so profiles stay with the test database.

  ```sh
  java -Dvaultbro.db=./test-data/vaultbro.db -jar target/vaultbro.jar
  ```

- SQLite tracks schema versions. An unrecognized database is preserved and copied to a uniquely named `.backup-…` file using SQLite's `VACUUM INTO`. Startup then reports the incompatible version and the backup path. To make a personal backup, close VAULTBRO and copy the entire `.vaultbro` directory.
- Money is stored as integer centavos. Balance is income minus expenses. Savings activity is recorded in a separate ledger and shown as contributions minus withdrawals.
- Category limits count that category's expenses for the selected calendar month. The overall limit counts all expenses for the month once. A budget is **Near Limit** at 80% through 100%, and **Over Budget** above 100%. The notification bell surfaces budget warnings, prioritizes the current month, and lists overdue savings goals.
- Goal progress uses cumulative savings. The suggested weekly and monthly amounts round partial periods up and round the recommended amount up to a centavo. If the deadline is today or has passed, the goal shows the outstanding amount due. Overfunded goals display the amount above target.
- Date and month filters use inclusive boundaries. Reports apply the date range to transactions and savings activity. Budget reports show whole months overlapping the range, and savings goal reports show current balances. All six exports carry a generation timestamp.
- Report files use UTF-8. CSV includes report metadata before the data header. When importing into a spreadsheet, start at the data header on row 3. Formula-like user text is prefixed with an apostrophe for safe spreadsheet import.

## Testing

Run the automated integration tests with:

```sh
mvn test
```

The suite uses temporary on-disk SQLite files. It checks account edits and password changes, persistence, cross-account access, transaction and budget changes, savings history, concurrent withdrawal protection, all six exports, and backup of an unrecognized schema.

Use a separate test database for a manual desktop check.

1. Register an account. Check duplicate and invalid signup details, an incorrect login, and sign-in with the registered email.
2. Add an income of **₱1,500.00** and a current-month grocery expense of **₱800.00**. Check that the dashboard balance is **₱700.00**. Search and sort the table, switch the type and date filters, then open the expense details.
3. Create a **₱1,000.00** overall budget and a **₱1,000.00** grocery budget for the current month. Each should show 80% and **Near Limit**. Edit the grocery expense to **₱1,001.00**. Both budgets should show **Over Budget**, and the overall amount spent should be **₱1,001.00**.
4. Create a **₱2,000.00** savings goal, contribute **₱1,000.00**, then withdraw **₱250.00**. The goal should show **₱750.00** saved, **₱1,250.00** remaining, and 37.5% progress. A withdrawal greater than **₱750.00** should fail. Check the history and the unchanged transaction balance.
5. In **Reports & Analytics**, select a date or month filter and export each of the six formats. Open the files and verify generation dates, amounts, and the report scope.
6. Update your profile and password. Log out, create a second account, and verify it has an empty dashboard. Restart VAULTBRO and sign in to the first account to check persistence.

## Code organization and OOP

| Package | Responsibilities |
| --- | --- |
| `model` | Encapsulated transaction classes and immutable account, budget, goal and ledger models |
| `database` | SQLite connections, constraints, schema initialization and backups |
| `dao` | Prepared statements and account-scoped persistence |
| `controller` | Authentication, session state, financial validation and coordination |
| `ui` | Swing windows, reusable forms, tables, navigation and charts |
| `service` | Financial summaries, profile images and report exports |
| `util` | Theme, shared Swing controls, password hashing and form validation |

`Income` and `Expense` inherit from the abstract `Transaction` class and override `getType()` and `getSignedAmount()`. Calculations process a `List<Transaction>` using the shared interface. The overloaded `FinanceController.searchTransactions` methods support simple search and combined filters. `FinanceController` is composed with DAO dependencies and delegates SQL operations to them.
