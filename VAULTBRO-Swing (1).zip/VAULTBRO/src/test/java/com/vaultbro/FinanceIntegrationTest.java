package com.vaultbro;

import com.vaultbro.controller.AuthService;
import com.vaultbro.controller.FinanceController;
import com.vaultbro.controller.SessionManager;
import com.vaultbro.dao.BudgetDAO;
import com.vaultbro.dao.GoalDAO;
import com.vaultbro.dao.TransactionDAO;
import com.vaultbro.dao.UserDAO;
import com.vaultbro.database.Database;
import com.vaultbro.model.*;
import com.vaultbro.service.FinancialCalculationService;
import com.vaultbro.service.ProfileImages;
import com.vaultbro.service.ReportExporter;
import java.awt.image.BufferedImage;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.concurrent.Callable;
import java.util.concurrent.Executors;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import static org.junit.jupiter.api.Assertions.*;

final class FinanceIntegrationTest {
    @TempDir Path directory;
    private Database database;
    private SessionManager session;
    private AuthService auth;
    private FinanceController finance;

    @BeforeEach void initialize() throws Exception {
        database = new Database(directory.resolve("test.db"));
        database.initialize();
        session = new SessionManager();
        auth = new AuthService(new UserDAO(database), session, new ProfileImages(directory));
        finance = createFinance(session);
        register("Avery", "avery");
        signIn("avery");
    }

    @Test void authenticatesUpdatesAccountAndPreservesDataAfterRestart() throws Exception {
        assertThrows(IllegalArgumentException.class, () -> register("Duplicate", "AVERY"));
        assertThrows(IllegalArgumentException.class, () -> auth.register("Duplicate", "different", "Avery@example.com",
                "Pass1234".toCharArray(), "Pass1234".toCharArray()));
        assertThrows(IllegalArgumentException.class, () -> auth.authenticate("unknown", "OldPass123".toCharArray()));
        assertThrows(IllegalArgumentException.class, () -> auth.changePassword(session.user().id(),
                "Incorrect123".toCharArray(), "NewPass456".toCharArray(), "NewPass456".toCharArray()));
        BufferedImage photo = new BufferedImage(30, 30, BufferedImage.TYPE_INT_ARGB);
        auth.updateProfile("Avery Santos", "avery.sun", "sun@example.com", photo, false);
        assertNotNull(new ProfileImages(directory).load(session.user().id(), session.user().profileImagePath()));
        long id = session.user().id();
        auth.changePassword(id, "OldPass123".toCharArray(), "NewPass456".toCharArray(), "NewPass456".toCharArray());
        assertTrue(new UserDAO(database).byId(id).passwordHash().startsWith("$2a$12$"));
        finance.saveTransaction(Transaction.Type.INCOME, 0, "Persistent income", "Salary", "25.50", "2026-10-03");
        auth.logout();
        assertThrows(IllegalStateException.class, () -> finance.searchTransactions(""));
        assertThrows(IllegalArgumentException.class, () -> auth.authenticate("avery.sun", "OldPass123".toCharArray()));
        database = new Database(directory.resolve("test.db"));
        database.initialize();
        var reopened = new AuthService(new UserDAO(database), session, new ProfileImages(directory));
        reopened.startSession(reopened.authenticate("SUN@example.com", "NewPass456".toCharArray()));
        assertEquals("Avery Santos", session.user().fullName());
        assertEquals(2550, createFinance(session).searchTransactions("").get(0).getAmount());
        String savedPhoto = session.user().profileImagePath();
        reopened.updateProfile("Avery Santos", "avery.sun", "sun@example.com", null, true);
        assertFalse(Files.exists(directory.resolve("profile-images").resolve(savedPhoto)));
    }

    @Test void tracksBudgetThresholdsAndEnforcesAccountOwnership() throws Exception {
        finance.saveBudget(0, Budget.OVERALL, "100", "2026-10");
        finance.saveBudget(0, "Groceries", "100", "2026-10");
        assertThrows(IllegalArgumentException.class, () -> finance.saveBudget(0, "Groceries", "85", "2026-10"));
        assertThrows(IllegalArgumentException.class, () -> finance.saveTransaction(Transaction.Type.EXPENSE, 0,
                "Invalid date", "Groceries", "100", "2026-02-29"));
        finance.saveTransaction(Transaction.Type.EXPENSE, 0, "Produce", "Groceries", "79.99", "2026-10-03");
        long transactionId = finance.searchTransactions("produce").get(0).getId();
        assertEquals(BudgetUsage.Status.ON_TRACK, finance.budgets().get(0).status());
        finance.saveTransaction(Transaction.Type.EXPENSE, transactionId, "Produce", "Groceries", "80", "2026-10-03");
        assertEquals(BudgetUsage.Status.NEAR_LIMIT, finance.budgets().get(0).status());
        finance.saveTransaction(Transaction.Type.EXPENSE, 0, "Fare", "Transport", "20", "2026-10-31");
        assertEquals(BudgetUsage.Status.NEAR_LIMIT, finance.budgets().get(0).status());
        finance.saveTransaction(Transaction.Type.EXPENSE, 0, "Bag fee", "Shopping", ".01", "2026-10-31");
        finance.saveTransaction(Transaction.Type.EXPENSE, 0, "Next month", "Groceries", "500", "2026-11-01");
        assertEquals(10001, finance.budgets().get(0).spent());
        assertEquals(BudgetUsage.Status.OVER_BUDGET, finance.budgets().get(0).status());
        assertEquals(8000, finance.budgets().get(1).spent());
        finance.saveGoal(0, "Vacation", "Travel", "100", "2027-01-01");
        long budgetId = finance.budgets().get(0).budget().id();
        long goalId = finance.goals().get(0).id();
        register("River", "river");
        signIn("river");
        assertTrue(finance.searchTransactions("").isEmpty());
        assertTrue(finance.budgets().isEmpty());
        assertTrue(finance.goals().isEmpty());
        assertThrows(IllegalArgumentException.class, () -> finance.deleteTransaction(transactionId));
        assertThrows(IllegalArgumentException.class, () -> finance.saveTransaction(Transaction.Type.EXPENSE, transactionId,
                "Unauthorized edit", "Groceries", "1", "2026-10-03"));
        assertThrows(IllegalArgumentException.class, () -> finance.deleteBudget(budgetId));
        assertThrows(IllegalArgumentException.class, () -> finance.saveBudget(budgetId, "Groceries", "50", "2026-10"));
        assertThrows(IllegalArgumentException.class, () -> finance.addGoalEntry(goalId,
                GoalEntry.Type.CONTRIBUTION, "10", "2026-10-03", ""));
        assertThrows(IllegalArgumentException.class, () -> finance.deleteGoal(goalId));
        assertThrows(IllegalArgumentException.class, () -> finance.saveGoal(goalId, "Changed", "Travel", "1", "2027-01-01"));
        assertTrue(finance.goalHistory(goalId).isEmpty());
        signIn("avery");
        assertEquals(3, finance.searchTransactions("", Transaction.Type.EXPENSE, null,
                DateRange.month(YearMonth.of(2026, 10))).size());
        finance.deleteTransaction(transactionId);
        assertEquals(2001, finance.budgets().get(0).spent());
        finance.saveBudget(budgetId, Budget.OVERALL, "200", "2026-10");
        assertEquals(20000, finance.budgets().get(0).budget().monthlyLimit());
        finance.deleteBudget(budgetId);
        assertEquals(1, finance.budgets().size());
    }

    @Test void savesExactBudgetDatesAndTracksTheWholeCalendarMonth() throws Exception {
        LocalDate leapDay = LocalDate.of(2028, 2, 29);
        finance.saveBudget(0, "Groceries", "100", leapDay);
        finance.saveTransaction(Transaction.Type.EXPENSE, 0, "Earlier purchase", "Groceries", "12", "2028-02-01");
        finance.saveTransaction(Transaction.Type.EXPENSE, 0, "Month end", "Groceries", "3", "2028-02-29");
        finance.saveTransaction(Transaction.Type.EXPENSE, 0, "Next month", "Groceries", "4", "2028-03-01");

        database = new Database(directory.resolve("test.db"));
        database.initialize();
        finance = createFinance(session);
        BudgetUsage february = finance.budgets().get(0);
        assertEquals(leapDay, february.budget().date());
        assertEquals(1500, february.spent());
        assertThrows(IllegalArgumentException.class,
                () -> finance.saveBudget(0, "Groceries", "75", leapDay.minusDays(1)));

        LocalDate newDate = LocalDate.of(2028, 3, 17);
        finance.saveBudget(february.budget().id(), "Groceries", "100", newDate);
        BudgetUsage march = finance.budgets().get(0);
        assertEquals(february.budget().id(), march.budget().id());
        assertEquals(newDate, march.budget().date());
        assertEquals(YearMonth.from(newDate), march.budget().period());
        assertEquals(400, march.spent());
    }

    @Test void migratesMonthOnlyBudgetsAndKeepsSubsequentDateEdits() throws Exception {
        // Recreate the version 1 budget schema in the temporary account's database.
        try (var connection = database.open(); var query = connection.createStatement()) {
            query.executeUpdate("DROP TABLE budget");
            query.executeUpdate("""
                    CREATE TABLE budget (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                        category TEXT NOT NULL COLLATE NOCASE,
                        monthly_limit INTEGER NOT NULL CHECK(monthly_limit BETWEEN 1 AND 99999999999),
                        month INTEGER NOT NULL CHECK(month BETWEEN 1 AND 12),
                        year INTEGER NOT NULL CHECK(year BETWEEN 1900 AND 9999),
                        UNIQUE(user_id, category, month, year)
                    ) STRICT
                    """);
            query.executeUpdate("CREATE INDEX budget_user_period ON budget(user_id, year DESC, month DESC)");
            try (var insert = connection.prepareStatement("""
                    INSERT INTO budget (id, user_id, category, monthly_limit, month, year)
                    VALUES (42, ?, 'Groceries', 12500, 4, 2027)
                    """)) {
                insert.setLong(1, session.user().id());
                insert.executeUpdate();
            }
            query.executeUpdate("PRAGMA user_version = 1");
        }

        database.initialize();
        Budget migrated = finance.budgets().get(0).budget();
        assertEquals(42, migrated.id());
        assertEquals("Groceries", migrated.category());
        assertEquals(12500, migrated.monthlyLimit());
        assertEquals(LocalDate.of(2027, 4, 1), migrated.date());
        LocalDate edited = LocalDate.of(2027, 4, 30);
        finance.saveBudget(migrated.id(), migrated.category(), "125", edited);
        database.initialize();
        assertEquals(edited, finance.budgets().get(0).budget().date());
    }

    @Test void recordsSavingsSeparatelyAndPreventsConcurrentOverdrafts() throws Exception {
        finance.saveTransaction(Transaction.Type.INCOME, 0, "Pay", "Salary", "500", "2026-10-01");
        finance.saveGoal(0, "Emergency savings", "Emergency Fund", "200", "2026-12-10");
        long goalId = finance.goals().get(0).id();
        finance.addGoalEntry(goalId, GoalEntry.Type.CONTRIBUTION, "100", "2026-10-10", "Transfer");
        Callable<Boolean> withdrawal = () -> {
            try {
                finance.addGoalEntry(goalId, GoalEntry.Type.WITHDRAWAL, "75", "2026-10-11", "");
                return true;
            } catch (IllegalArgumentException ignored) {
                return false;
            }
        };
        var pool = Executors.newFixedThreadPool(2);
        try {
            var results = pool.invokeAll(java.util.List.of(withdrawal, withdrawal));
            assertNotEquals(results.get(0).get(), results.get(1).get());
        } finally {
            pool.shutdownNow();
        }
        var report = new FinancialCalculationService(finance).report(DateRange.ALL);
        assertEquals(50000, report.totals().balance());
        assertEquals(2500, report.totals().savings());
        assertEquals(2500, report.months().get(0).savingsActivity());
        assertEquals(2, finance.goalHistory(goalId).size());
        finance.saveGoal(goalId, "Updated", "Emergency Fund", "40", "2026-10-18");
        SavingsGoal goal = finance.goals().get(0);
        assertEquals(1500, goal.remaining());
        assertEquals(62.5, goal.percent(), .0001);
        assertEquals(750, goal.weeklySavings(LocalDate.parse("2026-10-10")));
        assertEquals(1500, goal.monthlySavings(LocalDate.parse("2026-10-10")));
        assertEquals(1500, goal.weeklySavings(LocalDate.parse("2026-10-18")));
        assertEquals(SavingsGoal.Status.OVERDUE, goal.status(LocalDate.parse("2026-10-19")));
        finance.deleteGoal(goalId);
        try (var connection = database.open(); var query = connection.createStatement();
             var result = query.executeQuery("SELECT COUNT(*) FROM goal_entry")) {
            assertEquals(0, result.getInt(1));
        }
    }

    @Test void exportsAllFormatsWithUtf8AndEscaping() throws Exception {
        finance.saveTransaction(Transaction.Type.INCOME, 0, "Café, \"bonus\"\nSecond line", "Salary", "2450.50", "2026-10-10");
        finance.saveTransaction(Transaction.Type.INCOME, 0, "Outside date filter", "Salary", "50", "2026-11-01");
        finance.saveBudget(0, "Overall", "500", LocalDate.of(2026, 10, 23));
        finance.saveGoal(0, "Emergency", "Emergency Fund", "200", "2026-11-01");
        finance.addGoalEntry(finance.goals().get(0).id(), GoalEntry.Type.CONTRIBUTION, "10", "2026-10-10", "Personal transfer");
        register("River", "river");
        signIn("river");
        finance.saveTransaction(Transaction.Type.INCOME, 0, "Private user B", "Salary", "100.50", "2026-10-11");
        signIn("avery");
        var report = new FinancialCalculationService(finance).report(DateRange.month(YearMonth.of(2026, 10)));
        ReportExporter exporter = new ReportExporter();
        for (ReportExporter.Format format : ReportExporter.Format.values()) {
            Path file = directory.resolve(format.filename());
            exporter.export(file, format, report);
            String data = Files.readString(file);
            assertTrue(data.contains("Generated"));
            assertFalse(data.contains("Private user B"));
            assertFalse(data.contains("Outside date filter"));
            switch (format) {
                case TRANSACTIONS -> assertTrue(data.contains("\"Café, \"\"bonus\"\"\nSecond line\""));
                case SUMMARY_TXT -> assertTrue(data.contains("₱2,450.50"));
                case SUMMARY_CSV -> assertTrue(data.contains("2450.50"));
                case BUDGETS -> {
                    assertTrue(data.contains("Overall"));
                    assertTrue(data.contains("2026-10-23"));
                }
                case GOALS -> assertTrue(data.contains("Emergency"));
                case HISTORY -> assertTrue(data.contains("Personal transfer"));
            }
        }
        assertThrows(java.io.IOException.class, () -> exporter.export(directory.resolve("missing/no.csv"),
                ReportExporter.Format.TRANSACTIONS, report));
    }

    @Test void backsUpUnrecognizedDatabaseWithoutChangingOriginal() throws Exception {
        Database legacy = new Database(directory.resolve("legacy.db"));
        try (var connection = legacy.open(); var statement = connection.createStatement()) {
            statement.executeUpdate("CREATE TABLE old_records(note TEXT)");
            statement.executeUpdate("INSERT INTO old_records VALUES ('saved data')");
        }
        assertThrows(SQLException.class, legacy::initialize);
        Path backup;
        try (var files = Files.list(directory)) {
            backup = files.filter(path -> path.getFileName().toString().startsWith("legacy.db.backup-"))
                    .findFirst().orElseThrow();
        }
        for (Database data : new Database[]{legacy, new Database(backup)}) {
            try (var connection = data.open(); var statement = connection.createStatement();
                 var result = statement.executeQuery("SELECT note FROM old_records")) {
                assertEquals("saved data", result.getString(1));
            }
        }
    }

    private void register(String name, String username) throws Exception {
        auth.register(name, username, username + "@example.com", "OldPass123".toCharArray(), "OldPass123".toCharArray());
    }

    private void signIn(String username) throws Exception {
        auth.logout();
        auth.startSession(auth.authenticate(username, "OldPass123".toCharArray()));
    }

    private FinanceController createFinance(SessionManager active) {
        return new FinanceController(active, new TransactionDAO(database), new BudgetDAO(database), new GoalDAO(database));
    }
}
