package com.vaultbro.dao;

import com.vaultbro.database.Database;
import com.vaultbro.model.GoalEntry;
import com.vaultbro.model.SavingsGoal;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public final class GoalDAO {
    private static final String SAVED = """
            SELECT COALESCE(SUM(CASE WHEN e.entry_type = 'CONTRIBUTION' THEN e.amount ELSE -e.amount END), 0)
            FROM goal_entry e WHERE e.goal_id = g.id
            """;

    private final Database database;

    public GoalDAO(Database database) { this.database = database; }

    public List<SavingsGoal> find(long userId) throws SQLException {
        String sql = "SELECT g.*, (" + SAVED + ") AS saved FROM goal g WHERE g.user_id = ? ORDER BY g.target_date, g.id";
        try (var connection = database.open(); var query = connection.prepareStatement(sql)) {
            query.setLong(1, userId);
            try (var result = query.executeQuery()) {
                List<SavingsGoal> records = new ArrayList<>();
                while (result.next()) {
                    records.add(new SavingsGoal(result.getLong("id"), result.getString("goal_name"),
                            result.getString("category"), result.getLong("target_amount"),
                            LocalDate.parse(result.getString("target_date")), result.getLong("saved")));
                }
                return records;
            }
        }
    }

    public List<GoalEntry> history(long userId, Long goalId) throws SQLException {
        String sql = """
                SELECT e.*, g.goal_name FROM goal_entry e JOIN goal g ON e.goal_id = g.id
                WHERE g.user_id = ?
                """ + (goalId == null ? "" : " AND g.id = ?") + " ORDER BY e.entry_date DESC, e.id DESC";
        try (var connection = database.open(); var query = connection.prepareStatement(sql)) {
            query.setLong(1, userId);
            if (goalId != null) query.setLong(2, goalId);
            try (var result = query.executeQuery()) {
                List<GoalEntry> records = new ArrayList<>();
                while (result.next()) {
                    records.add(new GoalEntry(result.getLong("id"), result.getLong("goal_id"),
                            result.getString("goal_name"), GoalEntry.Type.valueOf(result.getString("entry_type")),
                            result.getLong("amount"), LocalDate.parse(result.getString("entry_date")),
                            result.getString("description")));
                }
                return records;
            }
        }
    }

    public void save(long userId, SavingsGoal goal) throws SQLException {
        String sql = goal.id() == 0
                ? "INSERT INTO goal(goal_name, category, target_amount, target_date, user_id) VALUES (?, ?, ?, ?, ?)"
                : "UPDATE goal SET goal_name = ?, category = ?, target_amount = ?, target_date = ? WHERE user_id = ? AND id = ?";
        try (var connection = database.open(); var query = connection.prepareStatement(sql)) {
            query.setString(1, goal.name());
            query.setString(2, goal.category());
            query.setLong(3, goal.targetAmount());
            query.setString(4, goal.targetDate().toString());
            query.setLong(5, userId);
            if (goal.id() != 0) query.setLong(6, goal.id());
            DaoErrors.found(query.executeUpdate());
        }
    }

    public void addEntry(long userId, long goalId, GoalEntry.Type type, long amount, LocalDate date,
                         String description) throws SQLException {
        // SQLite serializes writers. Checking the balance in the insert prevents concurrent overdrafts.
        String sql = """
                INSERT INTO goal_entry(goal_id, entry_type, amount, entry_date, description)
                SELECT g.id, ?, ?, ?, ? FROM goal g WHERE g.user_id = ? AND g.id = ?
                """ + (type == GoalEntry.Type.WITHDRAWAL ? " AND (?) <= (" + SAVED + ")" : "");
        try (var connection = database.open(); var query = connection.prepareStatement(sql)) {
            query.setString(1, type.name());
            query.setLong(2, amount);
            query.setString(3, date.toString());
            query.setString(4, description);
            query.setLong(5, userId);
            query.setLong(6, goalId);
            if (type == GoalEntry.Type.WITHDRAWAL) query.setLong(7, amount);
            if (query.executeUpdate() == 0) {
                throw new IllegalArgumentException("The goal is unavailable or the withdrawal exceeds the amount saved.");
            }
        }
    }

    public void delete(long userId, long id) throws SQLException {
        try (var connection = database.open();
             var query = connection.prepareStatement("DELETE FROM goal WHERE user_id = ? AND id = ?")) {
            query.setLong(1, userId);
            query.setLong(2, id);
            DaoErrors.found(query.executeUpdate());
        }
    }
}
