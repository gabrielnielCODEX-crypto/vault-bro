package com.vaultbro.dao;

import java.sql.SQLException;

final class DaoErrors {
    private DaoErrors() {}

    static void found(int count) {
        if (count == 0) throw new IllegalArgumentException("This record no longer exists or is unavailable to your account.");
    }

    static SQLException duplicate(SQLException exception, String message) {
        if (exception.getMessage().contains("SQLITE_CONSTRAINT_UNIQUE")) {
            throw new IllegalArgumentException(message);
        }
        return exception;
    }
}
