package com.vaultbro.dao;

import com.vaultbro.database.Database;
import com.vaultbro.model.DateRange;
import com.vaultbro.model.Transaction;
import com.vaultbro.model.TransactionFactory;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public final class TransactionDAO {
    private final Database database;

    public TransactionDAO(Database database) { this.database = database; }

    public List<Transaction> find(long userId, DateRange range) throws SQLException {
        try (var connection = database.open(); var query = connection.prepareStatement("""
                SELECT id, description, type, category, amount, transaction_date FROM transactions
                WHERE user_id = ? AND transaction_date BETWEEN ? AND ?
                ORDER BY transaction_date DESC, id DESC
                """)) {
            query.setLong(1, userId);
            query.setString(2, range.from() == null ? "1900-01-01" : range.from().toString());
            query.setString(3, range.to() == null ? "9999-12-31" : range.to().toString());
            try (var result = query.executeQuery()) {
                List<Transaction> records = new ArrayList<>();
                while (result.next()) {
                    records.add(TransactionFactory.create(Transaction.Type.valueOf(result.getString("type")),
                            result.getLong("id"), result.getString("description"), result.getString("category"),
                            result.getLong("amount"), LocalDate.parse(result.getString("transaction_date"))));
                }
                return records;
            }
        }
    }

    public void save(long userId, Transaction transaction) throws SQLException {
        String sql = transaction.getId() == 0
                ? "INSERT INTO transactions(description, type, category, amount, transaction_date, user_id) VALUES (?, ?, ?, ?, ?, ?)"
                : "UPDATE transactions SET description = ?, type = ?, category = ?, amount = ?, transaction_date = ? WHERE user_id = ? AND id = ?";
        try (var connection = database.open(); var query = connection.prepareStatement(sql)) {
            query.setString(1, transaction.getDescription());
            query.setString(2, transaction.getType().name());
            query.setString(3, transaction.getCategory());
            query.setLong(4, transaction.getAmount());
            query.setString(5, transaction.getDate().toString());
            query.setLong(6, userId);
            if (transaction.getId() != 0) query.setLong(7, transaction.getId());
            DaoErrors.found(query.executeUpdate());
        }
    }

    public void delete(long userId, long id) throws SQLException {
        try (var connection = database.open();
             var query = connection.prepareStatement("DELETE FROM transactions WHERE user_id = ? AND id = ?")) {
            query.setLong(1, userId);
            query.setLong(2, id);
            DaoErrors.found(query.executeUpdate());
        }
    }
}
