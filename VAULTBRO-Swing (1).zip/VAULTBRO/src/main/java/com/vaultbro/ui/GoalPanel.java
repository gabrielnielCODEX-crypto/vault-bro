package com.vaultbro.ui;

import com.vaultbro.controller.FinanceController;
import com.vaultbro.model.*;
import com.vaultbro.util.Ui;
import java.awt.*;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Locale;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

final class GoalPanel extends JPanel implements MainFrame.View {
    private final MainFrame owner;
    private final FinanceController finance;
    private final JPanel content = Ui.column();
    private final JLabel totalSavings = Ui.label("₱0.00", 24, true, Ui.CYAN);
    private final JLabel activeGoals = Ui.label("0", 24, true, Ui.LAVENDER);
    private final JLabel achievedGoals = Ui.label("0", 24, true, Ui.GREEN);
    private final JPanel featured = Ui.transparent(new BorderLayout());
    private final JComboBox<String> category = new JComboBox<>();
    private final JComboBox<String> status = new JComboBox<>(new String[]{"All statuses", "In Progress", "Achieved", "Overdue"});
    private final JLabel count = Ui.label("0 goals", 12, false, Ui.MUTED);
    private final DefaultTableModel goalsModel = Ui.tableModel(
            new String[]{"ID", "Goal", "Target", "Saved", "Progress", "Deadline", "Status"},
            new Class<?>[]{Long.class, String.class, Long.class, Long.class, Double.class, LocalDate.class, SavingsGoal.Status.class});
    private final JTable goalsTable = Ui.table(goalsModel);
    private final DefaultTableModel historyModel = Ui.tableModel(
            new String[]{"Date", "Type", "Amount", "Note"},
            new Class<?>[]{LocalDate.class, String.class, Long.class, String.class});
    private final JTable historyTable = Ui.table(historyModel);
    private final JLabel historyTitle = Ui.label("Goal history", 16, true, Ui.TEXT);
    private final JLabel historyEmpty = Ui.label("Select a goal to see its history.", 13, false, Ui.MUTED);
    private final JButton contribute = Ui.tintedButton("Contribute", Ui.GREEN, () -> entry(GoalEntry.Type.CONTRIBUTION));
    private final JButton withdraw = Ui.button("Withdraw", false, () -> entry(GoalEntry.Type.WITHDRAWAL));
    private final JButton edit = Ui.button("Edit goal", false, this::editGoal);
    private final JButton delete = Ui.tintedButton("Delete goal", Ui.RED, this::delete);
    private List<SavingsGoal> all = List.of();
    private List<SavingsGoal> visible = List.of();
    private String query = "";
    private boolean fillingTable;

    GoalPanel(MainFrame owner, FinanceController finance) {
        super(new BorderLayout());
        this.owner = owner;
        this.finance = finance;

        JPanel summary = Ui.transparent(new GridLayout(1, 3, 12, 0));
        summary.add(summaryCard("Total savings", totalSavings));
        summary.add(summaryCard("Active goals", activeGoals));
        summary.add(summaryCard("Achieved goals", achievedGoals));
        Ui.stack(content, summary, 13);
        content.add(featured);
        content.add(Box.createVerticalStrut(13));

        JPanel tools = Ui.card(new BorderLayout(10, 8), 12);
        JPanel buttons = Ui.transparent(new FlowLayout(FlowLayout.LEFT, 7, 0));
        JButton create = Ui.button("Add goal", true, () -> GoalDialog.edit(owner, finance, null));
        create.setIcon(Symbol.PLUS.icon(Color.WHITE, 15));
        for (JButton button : new JButton[]{create, contribute, withdraw, edit, delete}) buttons.add(button);
        tools.add(buttons, BorderLayout.NORTH);
        JPanel filters = Ui.transparent(new FlowLayout(FlowLayout.LEFT, 7, 0));
        category.addItem("All categories");
        Categories.GOALS.forEach(category::addItem);
        filters.add(category);
        filters.add(status);
        filters.add(count);
        tools.add(filters, BorderLayout.SOUTH);
        Ui.stack(content, tools, 13);

        goalsTable.getColumnModel().getColumn(0).setMaxWidth(52);
        goalsTable.getColumnModel().getColumn(1).setPreferredWidth(200);
        goalsTable.getColumnModel().getColumn(4).setPreferredWidth(140);
        goalsTable.getColumnModel().getColumn(6).setMinWidth(98);
        FinanceTables.money(goalsTable, 2, false);
        FinanceTables.money(goalsTable, 3, false);
        goalsTable.getColumnModel().getColumn(4).setCellRenderer(FinanceTables.progressRenderer(
                percent -> percent >= 100 ? Ui.GREEN : Ui.CYAN));
        goalsTable.getColumnModel().getColumn(6).setCellRenderer(
                FinanceTables.statusBadge(value -> FinanceTables.goalColor((SavingsGoal.Status) value)));
        JPanel records = Ui.card(new BorderLayout(), 11);
        records.add(FinanceTables.tableScroll(goalsTable, 187));
        Ui.stack(content, records, 13);

        FinanceTables.money(historyTable, 2, true);
        historyTable.getColumnModel().getColumn(3).setPreferredWidth(270);
        JPanel history = Ui.card(new BorderLayout(0, 8), 13);
        history.add(historyTitle, BorderLayout.NORTH);
        history.add(FinanceTables.tableScroll(historyTable, 160));
        history.add(historyEmpty, BorderLayout.SOUTH);
        Ui.stack(content, history, 0);

        showSelectionActions(false);
        category.addActionListener(event -> Ui.run(this, this::filter));
        status.addActionListener(event -> Ui.run(this, this::filter));
        goalsTable.getSelectionModel().addListSelectionListener(event -> {
            if (!fillingTable && !event.getValueIsAdjusting()) Ui.run(this, this::showSelection);
        });
        add(Ui.page(content));
    }

    @Override public void refresh() throws SQLException {
        all = finance.goals();
        LocalDate today = LocalDate.now();
        long achieved = all.stream().filter(goal -> goal.status(today) == SavingsGoal.Status.ACHIEVED).count();
        totalSavings.setText(Money.format(all.stream().mapToLong(SavingsGoal::savedAmount).sum()));
        activeGoals.setText(Long.toString(all.size() - achieved));
        achievedGoals.setText(Long.toString(achieved));
        filter();
    }

    @Override public void search(String text) {
        query = text.strip().toLowerCase(Locale.ROOT);
        Ui.run(this, this::filter);
    }

    private void filter() throws SQLException {
        SavingsGoal previous = selectedGoal();
        LocalDate today = LocalDate.now();
        visible = all.stream()
                .filter(goal -> category.getSelectedIndex() == 0 || goal.category().equals(category.getSelectedItem()))
                .filter(goal -> status.getSelectedIndex() == 0 || goal.status(today).toString().equals(status.getSelectedItem()))
                .filter(goal -> (goal.name() + " " + goal.category()).toLowerCase(Locale.ROOT).contains(query))
                .toList();

        fillingTable = true;
        try {
            goalsModel.setRowCount(0);
            int selectedModelRow = 0;
            for (int row = 0; row < visible.size(); row++) {
                SavingsGoal goal = visible.get(row);
                goalsModel.addRow(new Object[]{goal.id(), goal.name(), goal.targetAmount(), goal.savedAmount(),
                        goal.percent(), goal.targetDate(), goal.status(today)});
                if (previous != null && previous.id() == goal.id()) selectedModelRow = row;
            }
            if (!visible.isEmpty()) {
                int viewRow = goalsTable.convertRowIndexToView(selectedModelRow);
                goalsTable.setRowSelectionInterval(viewRow, viewRow);
            }
        } finally {
            fillingTable = false;
        }
        count.setText(visible.size() + (visible.size() == 1 ? " goal" : " goals"));
        showSelection();
    }

    private void showSelection() throws SQLException {
        SavingsGoal goal = selectedGoal();
        showSelectionActions(goal != null);
        featured.removeAll();
        if (goal == null) {
            JPanel empty = Ui.card(new BorderLayout(), 17);
            empty.add(Ui.label(visible.isEmpty() ? "No savings goals match these filters."
                    : "Select a goal to see its progress.", 13, false, Ui.MUTED));
            featured.add(empty);
        } else {
            featured.add(goalCard(goal, LocalDate.now()));
        }
        featured.setAlignmentX(Component.LEFT_ALIGNMENT);
        featured.setMaximumSize(new Dimension(Short.MAX_VALUE, featured.getPreferredSize().height));

        historyModel.setRowCount(0);
        historyTitle.setText(goal == null ? "Goal history" : "Goal history · " + goal.name());
        List<GoalEntry> entries = goal == null ? List.of() : finance.goalHistory(goal.id());
        historyEmpty.setText(goal == null ? "Select a goal to see its history." : "No contributions or withdrawals yet.");
        historyEmpty.setVisible(entries.isEmpty());
        for (GoalEntry entry : entries) {
            historyModel.addRow(new Object[]{entry.date(), entry.type().toString(), entry.signedAmount(), entry.description()});
        }
        content.revalidate();
        content.repaint();
    }

    private void showSelectionActions(boolean enabled) {
        for (JButton action : new JButton[]{contribute, withdraw, edit, delete}) action.setEnabled(enabled);
    }

    private static JPanel summaryCard(String title, JLabel value) {
        JPanel card = Ui.card(new BorderLayout(0, 8), 15);
        card.add(Ui.label(title, 13, true, Ui.MUTED), BorderLayout.NORTH);
        card.add(value);
        return card;
    }

    private static JPanel goalCard(SavingsGoal goal, LocalDate today) {
        SavingsGoal.Status state = goal.status(today);
        JPanel card = Ui.card(new BorderLayout(0, 13), 17, Ui.tint(Ui.ACCENT, .06), Ui.tint(Ui.ACCENT, .86));
        JPanel heading = Ui.transparent(new BorderLayout(12, 0));
        JPanel name = Ui.column();
        Ui.stack(name, Ui.label("Selected goal  ·  " + goal.category(), 12, true, Ui.MUTED), 4);
        JLabel title = Ui.label(goal.name(), 22, true, Ui.TEXT);
        title.setToolTipText(goal.name());
        Ui.stack(name, title, 0);
        heading.add(name);
        JPanel badge = Ui.transparent(new GridBagLayout());
        badge.add(Ui.badge(state.toString(), FinanceTables.goalColor(state)));
        heading.add(badge, BorderLayout.EAST);
        card.add(heading, BorderLayout.NORTH);

        JPanel amounts = Ui.transparent(new GridLayout(1, 6, 9, 0));
        amounts.add(detail("Saved", Money.format(goal.savedAmount()), Ui.CYAN));
        amounts.add(detail("Target", Money.format(goal.targetAmount()), Ui.TEXT));
        amounts.add(detail(goal.remaining() < 0 ? "Above target" : "Remaining",
                Money.format(Math.abs(goal.remaining())), Ui.TEXT));
        amounts.add(detail("Deadline", goal.targetDate().toString(), Ui.TEXT));
        amounts.add(detail("Needed / month", Money.format(goal.monthlySavings(today)), Ui.TEXT));
        amounts.add(detail("Needed / week", Money.format(goal.weeklySavings(today)), Ui.TEXT));
        card.add(amounts);

        JPanel progress = Ui.transparent(new BorderLayout(10, 0));
        JPanel track = Ui.transparent(new GridBagLayout());
        GridBagConstraints stretch = new GridBagConstraints();
        stretch.fill = GridBagConstraints.HORIZONTAL;
        stretch.weightx = 1;
        track.add(Ui.progress(goal.percent(), state == SavingsGoal.Status.ACHIEVED ? Ui.GREEN : Ui.ACCENT), stretch);
        progress.add(track);
        progress.add(Ui.label(FinanceTables.percent(goal.percent()), 13, true, Ui.TEXT), BorderLayout.EAST);
        card.add(progress, BorderLayout.SOUTH);
        return card;
    }

    private static JPanel detail(String name, String value, Color color) {
        JPanel column = Ui.column();
        Ui.stack(column, Ui.label(name, 11, false, Ui.MUTED), 4);
        JLabel label = Ui.label(value, 13, true, color);
        label.setToolTipText(value);
        Ui.stack(column, label, 0);
        return column;
    }

    private SavingsGoal selectedGoal() {
        int row = goalsTable.getSelectedRow();
        return row < 0 ? null : visible.get(goalsTable.convertRowIndexToModel(row));
    }

    private void entry(GoalEntry.Type type) {
        SavingsGoal goal = selectedGoal();
        if (goal != null) GoalDialog.entry(owner, finance, goal, type);
    }

    private void editGoal() {
        SavingsGoal goal = selectedGoal();
        if (goal != null) GoalDialog.edit(owner, finance, goal);
    }

    private void delete() {
        SavingsGoal goal = selectedGoal();
        if (goal != null && Ui.confirm(owner, "Delete Savings Goal", "Delete this goal and its contribution and withdrawal history?")) {
            Ui.run(this, () -> {
                finance.deleteGoal(goal.id());
                owner.dataChanged();
            });
        }
    }
}
