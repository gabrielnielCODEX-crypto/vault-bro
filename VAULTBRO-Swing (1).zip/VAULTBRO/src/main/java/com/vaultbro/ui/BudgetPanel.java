package com.vaultbro.ui;

import com.vaultbro.controller.FinanceController;
import com.vaultbro.model.*;
import com.vaultbro.util.Ui;
import com.vaultbro.util.ValidationUtil;
import java.awt.*;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

final class BudgetPanel extends JPanel implements MainFrame.View {
    private final MainFrame owner;
    private final FinanceController finance;
    private final DefaultTableModel model = FinanceTables.budgetModel();
    private final JTable table = FinanceTables.budgetTable(model);
    private final JLabel count = Ui.label("", 13, true, Ui.MUTED);
    private final JPanel alerts = Ui.transparent(new BorderLayout());
    private final JComboBox<String> category = new JComboBox<>();
    private final JComboBox<String> status = new JComboBox<>(new String[]{"All statuses", "On Track", "Near Limit", "Over Budget"});
    private final JTextField month = Ui.field(8, "YYYY-MM");
    private final CardLayout listLayout = new CardLayout();
    private final JPanel list = Ui.transparent(listLayout);
    private List<BudgetUsage> all = List.of();
    private List<BudgetUsage> visible = List.of();
    private YearMonth period;
    private String search = "";

    BudgetPanel(MainFrame owner, FinanceController finance) {
        super(new BorderLayout(0, 17));
        this.owner = owner;
        this.finance = finance;
        setBorder(new EmptyBorder(18, 27, 22, 27));
        JButton add = Ui.button("Create budget", true, () -> edit(null));
        add.setIcon(Symbol.PLUS.icon(Color.WHITE, 15));
        JButton details = Ui.button("Details", false, () -> details(selected()));
        JButton edit = Ui.button("Edit budget", false, () -> edit(selected().budget()));
        JButton delete = Ui.tintedButton("Delete budget", Ui.RED, this::delete);
        JButton[] selectionActions = {details, edit, delete};
        for (JButton button : selectionActions) button.setEnabled(false);
        table.getSelectionModel().addListSelectionListener(event -> {
            for (JButton button : selectionActions) button.setEnabled(table.getSelectedRow() >= 0);
        });

        JPanel top = Ui.column();
        top.add(alerts);
        JPanel tools = Ui.card(new BorderLayout(0, 9), 12);
        JPanel actions = Ui.transparent(new FlowLayout(FlowLayout.LEFT, 7, 0));
        for (JButton button : new JButton[]{add, details, edit, delete}) actions.add(button);
        tools.add(actions, BorderLayout.NORTH);
        JPanel filters = Ui.transparent(new FlowLayout(FlowLayout.LEFT, 7, 0));
        category.addItem("All categories");
        FinanceController.budgetCategories().forEach(category::addItem);
        month.getAccessibleContext().setAccessibleName("Budget month");
        filters.add(category);
        filters.add(status);
        filters.add(Ui.fieldLabel("Month", month));
        filters.add(month);
        filters.add(Ui.button("Apply", false, this::filterMonth));
        filters.add(Ui.button("Clear month", false, () -> {
            month.setText("");
            filterMonth();
        }));
        month.addActionListener(event -> filterMonth());
        category.addActionListener(event -> filter());
        status.addActionListener(event -> filter());
        tools.add(filters, BorderLayout.SOUTH);
        Ui.stack(top, tools, 0);
        add(top, BorderLayout.NORTH);

        JPanel card = Ui.card(new BorderLayout(0, 9), 12);
        card.add(count, BorderLayout.SOUTH);
        list.add(FinanceTables.tableScroll(table, 340), "table");
        JPanel blank = Ui.transparent(new GridBagLayout());
        blank.add(Ui.label("No budgets match these filters.", 14, false, Ui.MUTED));
        list.add(blank, "empty");
        card.add(list);
        add(card);
    }

    @Override public void refresh() throws SQLException {
        all = finance.budgets();
        updateAlerts();
        filter();
    }

    @Override public void search(String text) {
        search = text.strip().toLowerCase(Locale.ROOT);
        filter();
    }

    private void updateAlerts() {
        YearMonth currentMonth = YearMonth.now();
        List<BudgetUsage> warnings = all.stream()
                .filter(usage -> usage.budget().period().equals(currentMonth))
                .filter(usage -> usage.status() != BudgetUsage.Status.ON_TRACK)
                .sorted(Comparator.comparingDouble(BudgetUsage::percent).reversed())
                .toList();
        alerts.removeAll();
        if (!warnings.isEmpty()) {
            BudgetUsage first = warnings.get(0);
            Color tone = FinanceTables.budgetColor(first.status());
            JPanel banner = Ui.card(new BorderLayout(12, 0), 12, Ui.tint(tone, .09), Ui.tint(tone, .48));
            JPanel copy = Ui.column();
            Ui.stack(copy, Ui.label(warnings.size() + (warnings.size() == 1 ? " budget alert" : " budget alerts")
                    + " this month", 14, true, tone), 5);
            String summary = first.budget().category() + " · " + first.status() + " · " + Money.format(first.spent())
                    + " of " + Money.format(first.budget().monthlyLimit()) + " used";
            JLabel detail = Ui.label(summary, 12, false, Ui.TEXT);
            detail.setToolTipText(summary);
            Ui.stack(copy, detail, 0);
            banner.add(copy);
            banner.add(Ui.tintedButton("View alerts", tone, owner::showAlerts), BorderLayout.EAST);
            alerts.add(banner);
        }
        alerts.setBorder(new EmptyBorder(0, 0, warnings.isEmpty() ? 0 : 13, 0));
        alerts.setAlignmentX(Component.LEFT_ALIGNMENT);
        alerts.setMaximumSize(new Dimension(Short.MAX_VALUE, alerts.getPreferredSize().height));
        alerts.setVisible(!warnings.isEmpty());
        revalidate();
        repaint();
    }

    private void filterMonth() {
        Ui.run(this, () -> {
            period = month.getText().isBlank() ? null : ValidationUtil.month(month.getText());
            filter();
        });
    }

    private void filter() {
        visible = all.stream()
                .filter(item -> period == null || item.budget().period().equals(period))
                .filter(item -> category.getSelectedIndex() == 0 || item.budget().category().equals(category.getSelectedItem()))
                .filter(item -> status.getSelectedIndex() == 0 || item.status().toString().equals(status.getSelectedItem()))
                .filter(item -> (item.budget().category() + " " + item.budget().date() + " " + item.status())
                        .toLowerCase(Locale.ROOT).contains(search))
                .toList();
        FinanceTables.budgetRows(model, visible);
        count.setText(visible.size() + (visible.size() == 1 ? " budget" : " budgets"));
        listLayout.show(list, visible.isEmpty() ? "empty" : "table");
    }

    private BudgetUsage selected() { return visible.get(table.convertRowIndexToModel(table.getSelectedRow())); }

    private void edit(Budget budget) {
        JPanel form = Ui.column();
        JComboBox<String> choice = new JComboBox<>(FinanceController.budgetCategories().toArray(String[]::new));
        JTextField limit = Ui.field(22, "0.00");
        JTextField date = Ui.field(22, "YYYY-MM-DD");
        if (budget != null) {
            choice.setSelectedItem(budget.category());
            limit.setText(Money.decimal(budget.monthlyLimit()));
            date.setText(budget.date().toString());
        } else {
            LocalDate today = LocalDate.now();
            LocalDate initialDate = period == null || period.equals(YearMonth.from(today)) ? today : period.atDay(1);
            date.setText(initialDate.toString());
        }
        Ui.fieldRow(form, "Category", choice);
        Ui.fieldRow(form, "Monthly limit (₱)", limit);
        Ui.fieldRow(form, "Budget date (YYYY-MM-DD)", date);
        Ui.formSubmit(owner, budget == null ? "Create Budget" : "Edit Budget", "Save budget", form, () -> {
            finance.saveBudget(budget == null ? 0 : budget.id(), (String) choice.getSelectedItem(),
                    limit.getText(), ValidationUtil.date(date.getText(), "Budget date"));
            owner.dataChanged();
        });
    }

    private void delete() {
        Budget budget = selected().budget();
        if (Ui.confirm(owner, "Delete Budget", "Delete the " + budget.category() + " budget for " + budget.period() + "?")) {
            Ui.run(this, () -> {
                finance.deleteBudget(budget.id());
                owner.dataChanged();
            });
        }
    }

    private void details(BudgetUsage usage) {
        Budget budget = usage.budget();
        JPanel panel = Ui.column();
        Color color = FinanceTables.budgetColor(usage.status());
        Ui.stack(panel, Ui.label(budget.category() + " · " + budget.date(), 20, true, Ui.TEXT), 12);
        Ui.stack(panel, Ui.label(usage.status() + " · " + FinanceTables.percent(usage.percent()), 14, true, color), 10);
        Ui.stack(panel, Ui.progress(usage.percent(), color), 13);
        Ui.stack(panel, Ui.label("Monthly limit  " + Money.format(budget.monthlyLimit()), 14, false, Ui.TEXT), 6);
        Ui.stack(panel, Ui.label("Amount spent  " + Money.format(usage.spent()), 14, false, Ui.TEXT), 6);
        Ui.stack(panel, Ui.label("Remaining  " + Money.format(usage.remaining()), 14, false, Ui.TEXT), 0);
        JOptionPane.showMessageDialog(owner, panel, "Budget #" + budget.id(), JOptionPane.PLAIN_MESSAGE);
    }
}
