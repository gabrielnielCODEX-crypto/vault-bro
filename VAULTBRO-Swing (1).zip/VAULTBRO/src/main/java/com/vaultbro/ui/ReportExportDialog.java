package com.vaultbro.ui;

import com.vaultbro.service.ReportExporter.Format;
import com.vaultbro.util.Ui;
import java.awt.Component;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;

final class ReportExportDialog {
    @FunctionalInterface
    interface Export {
        void to(Path destination) throws IOException;
    }

    private ReportExportDialog() {}

    static void show(Component owner, JButton button, Format format, Export export) {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Save " + format);
        chooser.setFileFilter(new FileNameExtensionFilter(format.toString(), format.extension()));
        chooser.setSelectedFile(new File(format.filename()));
        if (chooser.showSaveDialog(owner) != JFileChooser.APPROVE_OPTION) return;

        Path selected = chooser.getSelectedFile().toPath();
        String extension = "." + format.extension();
        String name = selected.getFileName().toString();
        Path destination = name.toLowerCase(Locale.ROOT).endsWith(extension)
                ? selected : selected.resolveSibling(name + extension);
        if (Files.exists(destination)
                && !Ui.confirm(owner, "Replace File", "Replace the existing file " + destination.getFileName() + "?")) {
            return;
        }
        Ui.background(owner, button, () -> {
            export.to(destination);
            return destination;
        }, path -> JOptionPane.showMessageDialog(owner, "Report saved to " + path.toAbsolutePath()));
    }
}
