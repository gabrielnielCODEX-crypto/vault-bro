package com.vaultbro.ui;

import com.vaultbro.controller.FinanceController;
import com.vaultbro.model.*;
import com.vaultbro.util.Ui;
import java.time.LocalDate;
import javax.swing.*;

final class GoalDialog {
    private GoalDialog() {}

    static void edit(MainFrame owner, FinanceController finance, SavingsGoal goal) {
        JPanel form = Ui.column();
        JTextField name = Ui.field(22, "e.g. Emergency fund");
        JComboBox<String> category = new JComboBox<>(Categories.GOALS.toArray(String[]::new));
        JTextField amount = Ui.field(22, "0.00");
        JTextField date = Ui.field(22, "YYYY-MM-DD");
        if (goal != null) {
            name.setText(goal.name());
            category.setSelectedItem(goal.category());
            amount.setText(Money.decimal(goal.targetAmount()));
            date.setText(goal.targetDate().toString());
        } else {
            category.setSelectedIndex(-1);
            date.setText(LocalDate.now().plusMonths(6).toString());
        }
        Ui.fieldRow(form, "Goal name", name);
        Ui.fieldRow(form, "Category", category);
        Ui.fieldRow(form, "Target amount (₱)", amount);
        Ui.fieldRow(form, "Target date (YYYY-MM-DD)", date);
        Ui.formSubmit(owner, goal == null ? "Create Savings Goal" : "Edit Savings Goal", "Save goal", form, () -> {
            finance.saveGoal(goal == null ? 0 : goal.id(), name.getText(), (String) category.getSelectedItem(),
                    amount.getText(), date.getText());
            owner.dataChanged();
        });
    }

    static void entry(MainFrame owner, FinanceController finance, SavingsGoal goal, GoalEntry.Type type) {
        JPanel form = Ui.column();
        JTextField amount = Ui.field(22, "0.00");
        JTextField date = Ui.field(22, "YYYY-MM-DD");
        JTextArea notes = FinanceTables.notes("", 3);
        date.setText(LocalDate.now().toString());
        Ui.stack(form, Ui.label("Available savings  " + Money.format(goal.savedAmount()), 15, true, Ui.LAVENDER), 14);
        Ui.fieldRow(form, "Amount (₱)", amount);
        Ui.fieldRow(form, "Date (YYYY-MM-DD)", date);
        Ui.stack(form, Ui.fieldLabel("Description (optional)", notes), 7);
        Ui.stack(form, new JScrollPane(notes), 13);
        Ui.formSubmit(owner, type == GoalEntry.Type.CONTRIBUTION ? "Add Contribution" : "Record Withdrawal",
                "Save " + type.toString().toLowerCase(java.util.Locale.ROOT), form, () -> {
                    finance.addGoalEntry(goal.id(), type, amount.getText(), date.getText(), notes.getText());
                    owner.dataChanged();
                });
    }
}
