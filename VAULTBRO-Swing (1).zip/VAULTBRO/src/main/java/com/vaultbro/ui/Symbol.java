package com.vaultbro.ui;

import java.awt.*;
import java.awt.geom.*;
import javax.swing.Icon;

enum Symbol {
    LOGO, DASHBOARD, TRANSACTIONS, BUDGETS, GOALS, REPORTS, SETTINGS, LOGOUT, BELL, SEARCH,
    WALLET, INCOME, EXPENSE, SAVINGS, PLUS, CALENDAR, EXPORT;

    Icon icon(Color color, int size) {
        return new Icon() {
            @Override public int getIconWidth() { return size; }
            @Override public int getIconHeight() { return size; }
            @Override public void paintIcon(Component component, Graphics graphics, int x, int y) {
                Graphics2D draw = (Graphics2D) graphics.create();
                draw.translate(x, y);
                draw.scale(size / 24.0, size / 24.0);
                draw.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                draw.setColor(color);
                draw.setStroke(new BasicStroke(1.65f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                paint(draw);
                draw.dispose();
            }
        };
    }

    private void paint(Graphics2D draw) {
        switch (this) {
            case LOGO -> {
                draw.draw(new RoundRectangle2D.Double(3, 3, 18, 18, 5, 5));
                path(draw, 7, 9, 12, 16, 17, 9);
                path(draw, 9.5, 7, 12, 10, 14.5, 7);
            }
            case DASHBOARD -> {
                draw.draw(new RoundRectangle2D.Double(3, 3, 7, 7, 2, 2));
                draw.draw(new RoundRectangle2D.Double(14, 3, 7, 7, 2, 2));
                draw.draw(new RoundRectangle2D.Double(3, 14, 7, 7, 2, 2));
                draw.draw(new RoundRectangle2D.Double(14, 14, 7, 7, 2, 2));
            }
            case TRANSACTIONS -> {
                path(draw, 3, 8, 20, 8, 16, 4);
                path(draw, 20, 16, 3, 16, 7, 20);
            }
            case BUDGETS -> {
                draw.draw(new RoundRectangle2D.Double(5, 3, 14, 18, 3, 3));
                path(draw, 8, 15, 8, 17);
                path(draw, 12, 12, 12, 17);
                path(draw, 16, 8, 16, 17);
            }
            case GOALS -> {
                draw.draw(new Ellipse2D.Double(3, 3, 18, 18));
                draw.draw(new Ellipse2D.Double(7, 7, 10, 10));
                draw.fill(new Ellipse2D.Double(10.6, 10.6, 2.8, 2.8));
            }
            case REPORTS -> {
                path(draw, 5, 3, 5, 19, 21, 19);
                path(draw, 8, 14, 12, 10, 15, 12, 20, 6);
            }
            case SETTINGS -> {
                draw.draw(new Ellipse2D.Double(6, 6, 12, 12));
                draw.draw(new Ellipse2D.Double(9.5, 9.5, 5, 5));
                for (int i = 0; i < 8; i++) {
                    double angle = i * Math.PI / 4;
                    path(draw, 12 + Math.cos(angle) * 6, 12 + Math.sin(angle) * 6,
                            12 + Math.cos(angle) * 9, 12 + Math.sin(angle) * 9);
                }
            }
            case LOGOUT -> {
                path(draw, 11, 4, 4, 4, 4, 20, 11, 20);
                path(draw, 9, 12, 21, 12, 17, 8);
                path(draw, 21, 12, 17, 16);
            }
            case BELL -> {
                Path2D bell = new Path2D.Double();
                bell.moveTo(4, 17);
                bell.curveTo(7, 13, 6, 11, 7, 8);
                bell.curveTo(9, 3, 15, 3, 17, 8);
                bell.curveTo(18, 11, 17, 13, 20, 17);
                bell.closePath();
                draw.draw(bell);
                path(draw, 10, 20, 14, 20);
            }
            case SEARCH -> {
                draw.draw(new Ellipse2D.Double(4, 4, 12, 12));
                path(draw, 14, 14, 20, 20);
            }
            case WALLET -> {
                draw.draw(new RoundRectangle2D.Double(3, 6, 18, 14, 4, 4));
                path(draw, 5, 6, 16, 3, 19, 6);
                path(draw, 21, 11, 15, 11, 15, 15, 21, 15);
            }
            case INCOME -> {
                path(draw, 18, 6, 6, 18, 6, 10);
                path(draw, 6, 18, 14, 18);
            }
            case EXPENSE -> {
                path(draw, 6, 18, 18, 6, 18, 14);
                path(draw, 18, 6, 10, 6);
            }
            case SAVINGS -> {
                path(draw, 12, 3, 15, 8, 21, 9, 17, 14, 18, 20, 12, 17, 6, 20, 7, 14, 3, 9, 9, 8, 12, 3);
            }
            case PLUS -> {
                path(draw, 12, 5, 12, 19);
                path(draw, 5, 12, 19, 12);
            }
            case CALENDAR -> {
                draw.draw(new RoundRectangle2D.Double(4, 5, 16, 15, 3, 3));
                path(draw, 4, 10, 20, 10);
                path(draw, 8, 3, 8, 7);
                path(draw, 16, 3, 16, 7);
            }
            case EXPORT -> {
                path(draw, 12, 3, 12, 15, 8, 11);
                path(draw, 12, 15, 16, 11);
                path(draw, 4, 15, 4, 20, 20, 20, 20, 15);
            }
        }
    }

    private static void path(Graphics2D draw, double... coordinates) {
        Path2D path = new Path2D.Double();
        path.moveTo(coordinates[0], coordinates[1]);
        for (int i = 2; i < coordinates.length; i += 2) path.lineTo(coordinates[i], coordinates[i + 1]);
        draw.draw(path);
    }
}
