package com.vaultbro.ui;

import com.vaultbro.util.Ui;
import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.awt.geom.RoundRectangle2D;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

final class AuthLayout {
    private AuthLayout() {}

    static void install(JFrame frame, JPanel form) {
        JPanel layout = new JPanel(new GridLayout(1, 2));
        JPanel brand = new Brand();
        brand.setLayout(new BorderLayout());
        brand.setBorder(new EmptyBorder(34, 36, 34, 36));
        brand.add(wordmark(23), BorderLayout.NORTH);
        JPanel caption = Ui.column();
        caption.add(Ui.label("Take Control.", 35, true, Ui.TEXT));
        caption.add(Ui.label("Stack Smarter.", 35, true, Ui.LAVENDER));
        caption.add(Box.createVerticalStrut(13));
        caption.add(Ui.label("Personal expense tracking and budgeting", 14, false, Ui.MUTED));
        brand.add(caption, BorderLayout.SOUTH);
        layout.add(brand);
        JPanel right = new JPanel(new GridBagLayout());
        right.setBorder(new EmptyBorder(27, 34, 27, 34));
        GridBagConstraints placement = new GridBagConstraints();
        placement.weightx = 1;
        placement.fill = GridBagConstraints.HORIZONTAL;
        right.add(form, placement);
        JScrollPane scroll = Ui.scroll(right);
        scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        layout.add(scroll);
        frame.setContentPane(layout);
        frame.setSize(920, 670);
        frame.setMinimumSize(new Dimension(760, 560));
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }

    static JLabel wordmark(int size) {
        JLabel mark = Ui.label("VAULTBRO", size, true, Ui.TEXT);
        mark.setIcon(Symbol.LOGO.icon(Ui.LAVENDER, size + 10));
        mark.setIconTextGap(10);
        return mark;
    }

    private static final class Brand extends JPanel {
        @Override protected void paintComponent(Graphics graphics) {
            Graphics2D draw = (Graphics2D) graphics.create();
            int width = getWidth();
            int height = getHeight();
            draw.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            draw.setPaint(new GradientPaint(0, 0, Ui.color(0x211743), width, height, Ui.color(0x151524)));
            draw.fillRect(0, 0, width, height);
            int cx = width / 2;
            int cy = height * 46 / 100;
            int radius = Math.min(width, height) * 37 / 100;
            draw.setPaint(new RadialGradientPaint(cx, cy, radius, new float[]{0, 1},
                    new Color[]{Ui.color(0x45317A), new Color(50, 27, 89, 0)}));
            draw.fillOval(cx - radius, cy - radius, radius * 2, radius * 2);
            draw.setStroke(new BasicStroke(1));
            for (int ring = 1; ring <= 3; ring++) {
                double extent = radius * (.36 + .21 * ring);
                draw.setColor(new Color(176, 147, 253, 40));
                draw.draw(new Ellipse2D.Double(cx - extent, cy - extent, extent * 2, extent * 2));
            }
            draw.setColor(Ui.color(0x8366DD));
            draw.fillOval(cx + radius * 2 / 3, cy - radius * 2 / 3, 7, 7);
            draw.setColor(Ui.CYAN);
            draw.fillOval(cx - radius * 2 / 3, cy + radius / 2, 5, 5);
            int size = radius * 70 / 100;
            draw.setPaint(new GradientPaint(cx, cy - size, Ui.color(0x6B4BCD), cx, cy + size, Ui.color(0x281D4B)));
            draw.fill(new RoundRectangle2D.Double(cx - size / 2.0, cy - size / 2.0, size, size, 30, 30));
            draw.setColor(Ui.LAVENDER);
            draw.draw(new RoundRectangle2D.Double(cx - size / 2.0, cy - size / 2.0, size, size, 30, 30));
            int icon = size * 61 / 100;
            Symbol.LOGO.icon(Ui.TEXT, icon).paintIcon(this, draw, cx - icon / 2, cy - icon / 2);
            draw.dispose();
        }
    }
}
