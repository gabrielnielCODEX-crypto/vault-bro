package com.vaultbro.ui;

import com.vaultbro.model.*;
import com.vaultbro.service.FinancialCalculationService;
import com.vaultbro.service.FinancialCalculationService.Totals;
import com.vaultbro.util.Ui;
import java.awt.*;
import java.sql.SQLException;
import java.time.YearMonth;
import java.util.List;
import javax.swing.*;

final class DashboardPanel extends JPanel implements MainFrame.View {
    private final MainFrame owner;
    private final FinancialCalculationService calculations;
    private final JPanel content = Ui.column();

    DashboardPanel(MainFrame owner, FinancialCalculationService calculations) {
        super(new BorderLayout());
        this.owner = owner;
        this.calculations = calculations;
        add(Ui.page(content));
    }

    @Override public void refresh() throws SQLException {
        YearMonth month = YearMonth.now();
        var report = calculations.report(DateRange.ALL);
        List<Transaction> monthlyTransactions = report.transactions().stream()
                .filter(transaction -> YearMonth.from(transaction.getDate()).equals(month)).toList();
        var monthly = FinancialCalculationService.totals(monthlyTransactions, report.goals());
        var history = FinancialCalculationService.trailingMonths(report.months(), month, 6);
        content.removeAll();
        Ui.stack(content, stats(report.totals()), 16);

        JPanel visual = Ui.transparent(new GridLayout(1, 2, 15, 0));
        visual.add(chartCard("Expense distribution", "Current month",
                FinanceCharts.distribution(FinancialCalculationService.expenseCategories(monthlyTransactions))));
        visual.add(chartCard("Income vs expenses", "Last 6 months", FinanceCharts.cashFlow(history)));
        Ui.stack(content, visual, 16);
        JPanel analytics = Ui.transparent(new GridLayout(1, 2, 15, 0));
        analytics.add(chartCard("Monthly expense trend", "Last 6 months", FinanceCharts.trend(history)));
        long remaining = report.goals().stream().mapToLong(goal -> Math.max(0, goal.remaining())).sum();
        long towardTargets = report.goals().stream().mapToLong(goal -> Math.min(goal.savedAmount(), goal.targetAmount())).sum();
        String savingsScope = report.goals().isEmpty() ? "Across all savings goals"
                : FinanceTables.percent(100.0 * towardTargets / (towardTargets + remaining)) + " of goal targets saved";
        analytics.add(chartCard("Savings goals progress", savingsScope,
                FinanceCharts.saved(towardTargets, remaining, !report.goals().isEmpty())));
        Ui.stack(content, analytics, 16);

        JPanel recentAndBudgets = Ui.transparent(new GridLayout(1, 2, 15, 0));
        recentAndBudgets.add(recent(report.transactions()));
        recentAndBudgets.add(budgetUsage(report.budgets().stream().filter(usage -> usage.budget().period().equals(month)).toList()));
        Ui.stack(content, recentAndBudgets, 16);
        JPanel summaryAndAlerts = Ui.transparent(new GridLayout(1, 2, 15, 0));
        summaryAndAlerts.add(monthlySummary(monthly, monthlyTransactions.size()));
        summaryAndAlerts.add(alertCard());
        Ui.stack(content, summaryAndAlerts, 0);
        content.revalidate();
        content.repaint();
    }

    static JPanel stats(Totals totals) {
        JPanel cards = Ui.transparent(new GridLayout(1, 4, 13, 0));
        cards.add(metric("Total income", totals.income(), Symbol.INCOME, Ui.GREEN));
        cards.add(metric("Total expenses", totals.expenses(), Symbol.EXPENSE, Ui.RED));
        cards.add(metric("Remaining balance", totals.balance(), Symbol.WALLET, Ui.LAVENDER));
        cards.add(metric("Total savings", totals.savings(), Symbol.SAVINGS, Ui.CYAN));
        return cards;
    }

    private static JPanel metric(String name, long amount, Symbol symbol, Color color) {
        JPanel card = Ui.card(new BorderLayout(0, 7), 15);
        JLabel title = Ui.label(name, 13, true, Ui.MUTED);
        title.setIcon(symbol.icon(color, 18));
        title.setIconTextGap(8);
        card.add(title, BorderLayout.NORTH);
        JLabel value = Ui.label(Money.format(amount), 25, true, color);
        value.setToolTipText(value.getText());
        card.add(value, BorderLayout.CENTER);
        JPanel accent = Ui.transparent(new FlowLayout(FlowLayout.LEFT, 0, 3));
        JPanel rule = new JPanel();
        rule.setBackground(color);
        rule.setPreferredSize(new Dimension(32, 3));
        accent.add(rule);
        card.add(accent, BorderLayout.SOUTH);
        return card;
    }

    static JPanel chartCard(String title, String description, JComponent chart) {
        JPanel card = Ui.card(new BorderLayout(0, 10), 16);
        JPanel heading = Ui.column();
        Ui.stack(heading, Ui.label(title, 17, true, Ui.TEXT), 5);
        if (description != null) Ui.stack(heading, Ui.label(description, 12, false, Ui.MUTED), 0);
        card.add(heading, BorderLayout.NORTH);
        card.add(chart, BorderLayout.CENTER);
        return card;
    }

    private JPanel monthlySummary(Totals monthly, int count) {
        JPanel details = Ui.column();
        Ui.stack(details, labelValue("Income", Money.format(monthly.income()), Ui.GREEN), 10);
        Ui.stack(details, labelValue("Expenses", Money.format(monthly.expenses()), Ui.RED), 10);
        Ui.stack(details, labelValue("Net balance", Money.format(monthly.balance()), Ui.TEXT), 0);
        return chartCard("Monthly summary", count + (count == 1 ? " transaction this month" : " transactions this month"), details);
    }

    private JPanel budgetUsage(List<BudgetUsage> current) {
        JPanel card = Ui.card(new BorderLayout(0, 10), 14);
        JPanel heading = Ui.transparent(new BorderLayout(6, 0));
        heading.add(Ui.label("Budget overview", 17, true, Ui.TEXT), BorderLayout.WEST);
        heading.add(Ui.button("Manage budgets", false, () -> owner.showPage(MainFrame.Page.BUDGETS)), BorderLayout.EAST);
        card.add(heading, BorderLayout.NORTH);
        if (current.isEmpty()) {
            card.add(Ui.label("No spending limits set for this month.", 13, false, Ui.MUTED));
            return card;
        }

        var model = Ui.tableModel(new String[]{"Category", "Spent / limit", "Used", "Status"},
                new Class<?>[]{String.class, String.class, Double.class, BudgetUsage.Status.class});
        JTable table = Ui.table(model);
        table.getColumnModel().getColumn(1).setPreferredWidth(145);
        table.getColumnModel().getColumn(2).setMinWidth(56);
        table.getColumnModel().getColumn(2).setCellRenderer(FinanceTables.progressRenderer(
                value -> value > 100 ? Ui.RED : value >= 80 ? Ui.AMBER : Ui.GREEN));
        table.getColumnModel().getColumn(3).setMinWidth(94);
        table.getColumnModel().getColumn(3).setCellRenderer(
                FinanceTables.statusBadge(value -> FinanceTables.budgetColor((BudgetUsage.Status) value)));
        for (BudgetUsage usage : current) {
            Budget budget = usage.budget();
            model.addRow(new Object[]{budget.category(), Money.format(usage.spent()) + " / "
                    + Money.format(budget.monthlyLimit()), usage.percent(), usage.status()});
        }
        card.add(FinanceTables.tableScroll(table, 36 + Math.min(5, current.size()) * table.getRowHeight()));
        return card;
    }

    private JPanel recent(List<Transaction> transactions) {
        JPanel card = Ui.card(new BorderLayout(0, 10), 16);
        JPanel heading = Ui.transparent(new BorderLayout());
        heading.add(Ui.label("Recent transactions", 17, true, Ui.TEXT), BorderLayout.WEST);
        heading.add(Ui.button("View transactions", false, () -> owner.showPage(MainFrame.Page.TRANSACTIONS)), BorderLayout.EAST);
        card.add(heading, BorderLayout.NORTH);
        if (transactions.isEmpty()) {
            card.add(Ui.label("No transactions yet. Add one to start tracking your finances.", 13, false, Ui.MUTED));
        } else {
            FinanceTables.Transactions records = new FinanceTables.Transactions(true);
            records.set(transactions.stream().limit(5).toList());
            card.add(FinanceTables.tableScroll(records.table, 36 + Math.min(5, transactions.size()) * records.table.getRowHeight()));
        }
        return card;
    }

    private JPanel alertCard() {
        JPanel messages = Ui.column();
        if (owner.alerts().isEmpty()) {
            Ui.stack(messages, Ui.label("No active alerts.", 13, false, Ui.MUTED), 0);
        }
        for (MainFrame.Alert alert : owner.alerts().stream().limit(5).toList()) {
            JButton button = Ui.button(alert.title(), false, () -> owner.showPage(alert.page()));
            button.setForeground(alert.color());
            button.setHorizontalAlignment(SwingConstants.LEFT);
            button.setToolTipText(alert.detail());
            Ui.stack(messages, button, 5);
        }
        return chartCard("Financial alerts", null, messages);
    }

    private static JPanel labelValue(String label, String value, Color color) {
        JPanel row = Ui.transparent(new BorderLayout(6, 0));
        row.add(Ui.label(label, 13, false, Ui.MUTED), BorderLayout.WEST);
        row.add(Ui.label(value, 13, true, color), BorderLayout.EAST);
        return row;
    }
}
