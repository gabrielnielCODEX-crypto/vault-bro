package com.vaultbro.ui;

import com.vaultbro.controller.AuthService;
import com.vaultbro.util.Ui;
import java.util.Arrays;
import javax.swing.*;

final class RegisterFrame extends JFrame {
    RegisterFrame(AuthService auth, Runnable onBack) {
        super("VAULTBRO · Create Account");
        JPanel form = Ui.column();
        JTextField name = Ui.field(24, "Your full name");
        JTextField username = Ui.field(24, "Choose a username");
        JTextField email = Ui.field(24, "you@example.com");
        JPasswordField password = Ui.password(24, "8+ characters, letters and numbers");
        JPasswordField confirmation = Ui.password(24, "Retype your password");
        Ui.stack(form, Ui.label("Create your account", 30, true, Ui.TEXT), 7);
        Ui.stack(form, Ui.label("Keep your finances organized in one place.", 14, false, Ui.MUTED), 17);
        Ui.fieldRow(form, "Full name", name);
        Ui.fieldRow(form, "Username", username);
        Ui.fieldRow(form, "Email address", email);
        Ui.fieldRow(form, "Password", password);
        Ui.fieldRow(form, "Confirm password", confirmation);
        Runnable back = () -> {
            onBack.run();
            dispose();
        };
        JButton submit = Ui.button("Create account", true, null);
        JButton returnButton = Ui.button("Back to sign in", false, back);
        submit.addActionListener(event -> {
            String fullName = name.getText();
            String handle = username.getText();
            String address = email.getText();
            char[] secret = password.getPassword();
            char[] confirm = confirmation.getPassword();
            password.setText("");
            confirmation.setText("");
            Ui.background(this, submit, () -> {
                try {
                    auth.register(fullName, handle, address, secret, confirm);
                    return true;
                } finally {
                    Arrays.fill(secret, '\0');
                    Arrays.fill(confirm, '\0');
                }
            }, ignored -> {
                JOptionPane.showMessageDialog(this, "Account created. You can now sign in.");
                back.run();
            });
        });
        submit.addPropertyChangeListener("enabled", event -> returnButton.setEnabled(submit.isEnabled()));
        Ui.stack(form, submit, 9);
        Ui.stack(form, returnButton, 0);
        AuthLayout.install(this, form);
        getRootPane().setDefaultButton(submit);
    }
}
