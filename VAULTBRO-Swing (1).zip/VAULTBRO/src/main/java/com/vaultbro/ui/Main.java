package com.vaultbro.ui;

import com.vaultbro.controller.AuthService;
import com.vaultbro.controller.FinanceController;
import com.vaultbro.controller.SessionManager;
import com.vaultbro.dao.BudgetDAO;
import com.vaultbro.dao.GoalDAO;
import com.vaultbro.dao.TransactionDAO;
import com.vaultbro.dao.UserDAO;
import com.vaultbro.database.Database;
import com.vaultbro.service.FinancialCalculationService;
import com.vaultbro.service.ProfileImages;
import com.vaultbro.util.Ui;
import java.nio.file.Path;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

public final class Main {
    private final SessionManager session = new SessionManager();
    private final AuthService auth;
    private final FinanceController finance;
    private final FinancialCalculationService calculations;
    private final ProfileImages images;

    private Main(Database database) {
        images = new ProfileImages(database.directory());
        auth = new AuthService(new UserDAO(database), session, images);
        finance = new FinanceController(session, new TransactionDAO(database), new BudgetDAO(database), new GoalDAO(database));
        calculations = new FinancialCalculationService(finance);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Ui.setup();
            try {
                String defaultPath = Path.of(System.getProperty("user.home"), ".vaultbro", "vaultbro.db").toString();
                Database database = new Database(Path.of(System.getProperty("vaultbro.db", defaultPath)));
                database.initialize();
                new Main(database).showLogin();
            } catch (Exception exception) {
                System.getLogger(Main.class.getName()).log(System.Logger.Level.ERROR, "Startup failed.", exception);
                JOptionPane.showMessageDialog(null, "VAULTBRO could not open its database.\n" + exception.getMessage(),
                        "VAULTBRO", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private void showLogin() {
        new LoginFrame(auth, user -> {
            auth.startSession(user);
            new MainFrame(session, auth, finance, calculations, images, this::showLogin).setVisible(true);
        }).setVisible(true);
    }
}
