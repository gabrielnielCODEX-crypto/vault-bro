package com.vaultbro.controller;

import com.vaultbro.model.User;

public final class SessionManager {
    private volatile User current;

    void set(User user) { current = user; }
    public void clear() { current = null; }

    public User user() {
        User user = current;
        if (user == null) throw new IllegalStateException("Sign in to access your account.");
        return user;
    }
}
