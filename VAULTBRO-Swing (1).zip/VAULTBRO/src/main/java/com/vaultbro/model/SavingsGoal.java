package com.vaultbro.model;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public record SavingsGoal(long id, String name, String category, long targetAmount,
                          LocalDate targetDate, long savedAmount) {
    public enum Status {
        IN_PROGRESS("In Progress"), ACHIEVED("Achieved"), OVERDUE("Overdue");
        private final String label;
        Status(String label) { this.label = label; }
        @Override public String toString() { return label; }
    }

    public long remaining() { return targetAmount - savedAmount; }
    public double percent() { return 100.0 * savedAmount / targetAmount; }

    public Status status(LocalDate today) {
        if (remaining() <= 0) return Status.ACHIEVED;
        return targetDate.isBefore(today) ? Status.OVERDUE : Status.IN_PROGRESS;
    }

    public long monthlySavings(LocalDate today) {
        if (!targetDate.isAfter(today)) return Math.max(0, remaining());
        long months = ChronoUnit.MONTHS.between(today, targetDate);
        if (today.plusMonths(months).isBefore(targetDate)) months++;
        return ceilingShare(remaining(), months);
    }

    public long weeklySavings(LocalDate today) {
        long days = ChronoUnit.DAYS.between(today, targetDate);
        return ceilingShare(remaining(), Math.max(1, (days + 6) / 7));
    }

    private static long ceilingShare(long amount, long periods) {
        if (amount <= 0) return 0;
        return amount / periods + (amount % periods == 0 ? 0 : 1);
    }
}
