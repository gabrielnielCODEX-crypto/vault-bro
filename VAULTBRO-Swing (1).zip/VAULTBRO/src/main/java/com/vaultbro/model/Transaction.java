package com.vaultbro.model;

import java.time.LocalDate;

public abstract class Transaction {
    public enum Type {
        INCOME("Income"), EXPENSE("Expense");
        private final String label;
        Type(String label) { this.label = label; }
        @Override public String toString() { return label; }
    }

    private final long id;
    private final String description;
    private final String category;
    private final long amount;
    private final LocalDate date;

    protected Transaction(long id, String description, String category, long amount, LocalDate date) {
        this.id = id;
        this.description = description;
        this.category = category;
        this.amount = amount;
        this.date = date;
    }

    public long getId() { return id; }
    public String getDescription() { return description; }
    public String getCategory() { return category; }
    public long getAmount() { return amount; }
    public LocalDate getDate() { return date; }
    public abstract Type getType();
    public abstract long getSignedAmount();
}
