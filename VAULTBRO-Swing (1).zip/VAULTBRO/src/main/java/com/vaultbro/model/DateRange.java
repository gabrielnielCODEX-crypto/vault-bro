package com.vaultbro.model;

import java.time.LocalDate;
import java.time.YearMonth;

public record DateRange(LocalDate from, LocalDate to) {
    public static final DateRange ALL = new DateRange(null, null);

    public DateRange {
        if (from != null && to != null && from.isAfter(to)) {
            throw new IllegalArgumentException("The start date must come before or equal the end date.");
        }
    }

    public static DateRange month(YearMonth month) {
        return new DateRange(month.atDay(1), month.atEndOfMonth());
    }

    public boolean includes(LocalDate date) {
        return (from == null || !date.isBefore(from)) && (to == null || !date.isAfter(to));
    }

    public boolean overlaps(YearMonth month) {
        return (from == null || !month.atEndOfMonth().isBefore(from))
                && (to == null || !month.atDay(1).isAfter(to));
    }

    @Override public String toString() {
        return (from == null ? "Any start date" : from) + " to " + (to == null ? "Any end date" : to);
    }
}
