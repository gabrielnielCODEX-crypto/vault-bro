package com.vaultbro.model;

import java.time.LocalDate;

public final class Expense extends Transaction {
    Expense(long id, String description, String category, long amount, LocalDate date) {
        super(id, description, category, amount, date);
    }

    @Override public Type getType() { return Type.EXPENSE; }
    @Override public long getSignedAmount() { return -getAmount(); }
}
