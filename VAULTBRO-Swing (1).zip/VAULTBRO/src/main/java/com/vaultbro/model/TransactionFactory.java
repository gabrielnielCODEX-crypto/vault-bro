package com.vaultbro.model;

import java.time.LocalDate;

public final class TransactionFactory {
    private TransactionFactory() {}

    public static Transaction create(Transaction.Type type, long id, String description,
                                     String category, long amount, LocalDate date) {
        return switch (type) {
            case INCOME -> new Income(id, description, category, amount, date);
            case EXPENSE -> new Expense(id, description, category, amount, date);
        };
    }
}
