package com.vaultbro.model;

import java.time.LocalDate;

public record GoalEntry(long id, long goalId, String goalName, Type type,
                        long amount, LocalDate date, String description) {
    public enum Type {
        CONTRIBUTION("Contribution"), WITHDRAWAL("Withdrawal");
        private final String label;
        Type(String label) { this.label = label; }
        @Override public String toString() { return label; }
    }

    public long signedAmount() { return type == Type.CONTRIBUTION ? amount : -amount; }
}
