package com.vaultbro.model;

import java.time.LocalDate;
import java.time.YearMonth;

public record Budget(long id, String category, long monthlyLimit, LocalDate date) {
    public static final String OVERALL = "Overall";

    public Budget(long id, String category, long monthlyLimit, YearMonth period) {
        this(id, category, monthlyLimit, period.atDay(1));
    }

    public YearMonth period() { return YearMonth.from(date); }
}
