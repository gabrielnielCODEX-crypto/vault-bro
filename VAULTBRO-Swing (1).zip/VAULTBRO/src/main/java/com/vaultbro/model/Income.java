package com.vaultbro.model;

import java.time.LocalDate;

public final class Income extends Transaction {
    Income(long id, String description, String category, long amount, LocalDate date) {
        super(id, description, category, amount, date);
    }

    @Override public Type getType() { return Type.INCOME; }
    @Override public long getSignedAmount() { return getAmount(); }
}
