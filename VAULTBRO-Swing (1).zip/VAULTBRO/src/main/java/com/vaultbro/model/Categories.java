package com.vaultbro.model;

import java.util.List;

public final class Categories {
    public static final List<String> EXPENSES = List.of("Food & Dining", "Groceries", "Transport",
            "Housing", "Utilities", "Health", "Education", "Shopping", "Entertainment",
            "Travel", "Subscriptions", "Family", "Other");
    public static final List<String> INCOME = List.of("Salary", "Freelance", "Business", "Allowance",
            "Gifts", "Interest", "Other");
    public static final List<String> GOALS = List.of("Emergency Fund", "Travel", "Education", "Home",
            "Technology", "Vehicle", "Investment", "Personal", "Other");

    private Categories() {}
}
