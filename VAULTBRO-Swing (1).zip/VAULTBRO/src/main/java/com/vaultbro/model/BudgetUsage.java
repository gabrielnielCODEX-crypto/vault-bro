package com.vaultbro.model;


public record BudgetUsage(Budget budget, long spent) {
    public enum Status {
        ON_TRACK("On Track"), NEAR_LIMIT("Near Limit"), OVER_BUDGET("Over Budget");
        private final String label;
        Status(String label) { this.label = label; }
        @Override public String toString() { return label; }
    }

    public long remaining() { return budget.monthlyLimit() - spent; }
    public double percent() { return 100.0 * spent / budget.monthlyLimit(); }

    public Status status() {
        if (spent > budget.monthlyLimit()) return Status.OVER_BUDGET;
        // Compare cents exactly at the warning boundary.
        long warningThreshold = (budget.monthlyLimit() * 4 + 4) / 5;
        return spent >= warningThreshold ? Status.NEAR_LIMIT : Status.ON_TRACK;
    }
}
