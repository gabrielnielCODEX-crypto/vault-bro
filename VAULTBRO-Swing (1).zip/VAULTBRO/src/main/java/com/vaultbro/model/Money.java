package com.vaultbro.model;

import java.math.BigDecimal;
import java.util.Locale;

public final class Money {
    public static final long MAX_AMOUNT = 99_999_999_999L;

    private Money() {}

    public static long parsePositive(String value) {
        String input = value.strip();
        if (!input.matches("(?:[0-9]+(?:\\.[0-9]{1,2})?|\\.[0-9]{1,2})") || input.length() > 18) {
            throw new IllegalArgumentException("Enter a positive amount with up to two decimal places, such as 1250.50.");
        }
        BigDecimal amount = new BigDecimal(input).movePointRight(2);
        if (amount.signum() <= 0 || amount.compareTo(BigDecimal.valueOf(MAX_AMOUNT)) > 0) {
            throw new IllegalArgumentException("Enter an amount from ₱0.01 to ₱999,999,999.99.");
        }
        return amount.longValueExact();
    }

    public static String format(long cents) {
        BigDecimal amount = BigDecimal.valueOf(cents, 2);
        return (amount.signum() < 0 ? "-₱" : "₱") + String.format(Locale.US, "%,.2f", amount.abs());
    }

    public static String decimal(long cents) {
        return BigDecimal.valueOf(cents, 2).toPlainString();
    }
}
