package com.vaultbro.model;

public record User(long id, String fullName, String username, String email, String profileImagePath) {}
