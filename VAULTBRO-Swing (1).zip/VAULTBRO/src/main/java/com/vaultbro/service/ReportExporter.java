package com.vaultbro.service;

import com.vaultbro.model.*;
import com.vaultbro.service.FinancialCalculationService.Report;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Locale;

public final class ReportExporter {
    public enum Format {
        SUMMARY_TXT("Financial Summary (TXT)", "financial-summary", "txt"),
        SUMMARY_CSV("Financial Summary (CSV)", "financial-summary", "csv"),
        TRANSACTIONS("Transaction Report (CSV)", "transactions", "csv"),
        BUDGETS("Budget Report (CSV)", "budgets", "csv"),
        GOALS("Savings Goals Report (CSV)", "savings-goals", "csv"),
        HISTORY("Savings History (CSV)", "savings-history", "csv");

        private final String label;
        private final String stem;
        private final String extension;
        Format(String label, String stem, String extension) {
            this.label = label;
            this.stem = stem;
            this.extension = extension;
        }
        public String extension() { return extension; }
        public String filename() { return "vaultbro-" + stem + "." + extension; }
        @Override public String toString() { return label; }
    }

    public void export(Path destination, Format format, Report report) throws IOException {
        save(destination, (writer, generated) -> {
            if (format == Format.SUMMARY_TXT) writeText(writer, report, generated);
            else writeCsv(writer, format, report, generated.toString());
        });
    }

    public void exportTransactions(Path destination, DateRange range, List<Transaction> transactions) throws IOException {
        save(destination, (writer, generated) -> {
            csvHeader(writer, Format.TRANSACTIONS, range, generated.toString());
            writeTransactions(writer, transactions);
        });
    }

    @FunctionalInterface
    private interface ReportWriter {
        void write(BufferedWriter writer, ZonedDateTime generated) throws IOException;
    }

    private static void save(Path destination, ReportWriter reportWriter) throws IOException {
        Path target = destination.toAbsolutePath();
        Path temp = Files.createTempFile(target.getParent(), ".vaultbro-", ".tmp");
        try {
            try (var writer = Files.newBufferedWriter(temp, StandardCharsets.UTF_8)) {
                reportWriter.write(writer, ZonedDateTime.now().withNano(0));
            }
            try {
                Files.move(temp, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
            } catch (AtomicMoveNotSupportedException exception) {
                Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING);
            }
        } finally {
            Files.deleteIfExists(temp);
        }
    }

    private static void writeText(BufferedWriter writer, Report report, ZonedDateTime generated) throws IOException {
        var totals = report.totals();
        writer.write("""
                VAULTBRO | Financial Summary
                Generated: %s
                Period: %s

                Income: %s
                Expenses: %s
                Balance: %s
                Current savings: %s

                Monthly activity
                """.formatted(generated, report.range(), Money.format(totals.income()),
                Money.format(totals.expenses()), Money.format(totals.balance()), Money.format(totals.savings())));
        for (var month : report.months()) {
            writer.write("%s  Income %s  Expenses %s  Balance %s  Savings activity %s%n".formatted(
                    month.month(), Money.format(month.income()), Money.format(month.expenses()),
                    Money.format(month.balance()), Money.format(month.savingsActivity())));
        }
        writer.write("\nExpenses by category\n");
        for (var category : report.categories().entrySet()) {
            writer.write(category.getKey() + ": " + Money.format(category.getValue()) + "\n");
        }
    }

    private static void writeCsv(BufferedWriter out, Format format, Report report, String generated) throws IOException {
        csvHeader(out, format, report.range(), generated);
        switch (format) {
            case SUMMARY_CSV -> {
                var totals = report.totals();
                row(out, "Period", "Income", "Expenses", "Balance", "Savings (current total or monthly net activity)");
                row(out, "Summary", Money.decimal(totals.income()), Money.decimal(totals.expenses()),
                        Money.decimal(totals.balance()), Money.decimal(totals.savings()));
                for (var month : report.months()) {
                    row(out, month.month(), Money.decimal(month.income()), Money.decimal(month.expenses()),
                            Money.decimal(month.balance()), Money.decimal(month.savingsActivity()));
                }
            }
            case TRANSACTIONS -> writeTransactions(out, report.transactions());
            case BUDGETS -> {
                row(out, "ID", "Category", "Month", "Limit", "Spent", "Remaining", "Usage %", "Status", "Budget Date");
                for (var usage : report.budgets()) {
                    var budget = usage.budget();
                    row(out, budget.id(), budget.category(), budget.period(), Money.decimal(budget.monthlyLimit()),
                            Money.decimal(usage.spent()), Money.decimal(usage.remaining()), percentage(usage.percent()), usage.status(),
                            budget.date());
                }
            }
            case GOALS -> {
                row(out, "ID", "Name", "Category", "Target", "Saved", "Remaining", "Target Date", "Progress %",
                        "Status", "Required per Month", "Required per Week");
                LocalDate today = LocalDate.now();
                for (var goal : report.goals()) {
                    row(out, goal.id(), safeText(goal.name()), goal.category(), Money.decimal(goal.targetAmount()),
                            Money.decimal(goal.savedAmount()), Money.decimal(goal.remaining()), goal.targetDate(),
                            percentage(goal.percent()), goal.status(today), Money.decimal(goal.monthlySavings(today)),
                            Money.decimal(goal.weeklySavings(today)));
                }
            }
            case HISTORY -> {
                row(out, "ID", "Goal ID", "Goal", "Type", "Amount", "Date", "Description");
                for (var entry : report.history()) {
                    row(out, entry.id(), entry.goalId(), safeText(entry.goalName()), entry.type(),
                            Money.decimal(entry.amount()), entry.date(), safeText(entry.description()));
                }
            }
            case SUMMARY_TXT -> throw new IllegalArgumentException("Select a CSV export format.");
        }
    }

    private static void csvHeader(BufferedWriter out, Format format, DateRange range, String generated)
            throws IOException {
        row(out, "Report", format, "Generated", generated, "Currency", "PHP");
        row(out, "From", range.from(), "To", range.to());
    }

    private static void writeTransactions(BufferedWriter out, List<Transaction> transactions) throws IOException {
        row(out, "ID", "Description", "Type", "Category", "Amount", "Date");
        for (Transaction transaction : transactions) {
            row(out, transaction.getId(), safeText(transaction.getDescription()), transaction.getType(),
                    transaction.getCategory(), Money.decimal(transaction.getAmount()), transaction.getDate());
        }
    }

    private static String percentage(double value) { return String.format(Locale.ROOT, "%.2f", value); }

    private static String safeText(String value) {
        String trimmed = value.stripLeading();
        if (!trimmed.isEmpty() && "=+-@".indexOf(trimmed.charAt(0)) >= 0) return "'" + value;
        return value;
    }

    private static void row(BufferedWriter out, Object... cells) throws IOException {
        for (int index = 0; index < cells.length; index++) {
            if (index > 0) out.write(',');
            String text = cells[index] == null ? "" : cells[index].toString();
            if (text.indexOf(',') >= 0 || text.indexOf('"') >= 0 || text.indexOf('\n') >= 0 || text.indexOf('\r') >= 0) {
                out.write('"' + text.replace("\"", "\"\"") + '"');
            } else {
                out.write(text);
            }
        }
        out.write("\r\n");
    }
}
