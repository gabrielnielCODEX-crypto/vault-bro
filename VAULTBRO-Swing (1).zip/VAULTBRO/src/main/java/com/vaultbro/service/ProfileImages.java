package com.vaultbro.service;

import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.UUID;
import javax.imageio.ImageIO;

public final class ProfileImages {
    private final Path directory;

    public ProfileImages(Path dataDirectory) {
        directory = dataDirectory.resolve("profile-images");
    }

    public BufferedImage preview(Path source) throws IOException {
        if (!Files.isRegularFile(source) || Files.size(source) > 10_000_000) {
            throw new IllegalArgumentException("Choose a PNG or JPEG image under 10 MB.");
        }
        try (var stream = ImageIO.createImageInputStream(source.toFile())) {
            var readers = ImageIO.getImageReaders(stream);
            if (!readers.hasNext()) throw new IllegalArgumentException("Choose a PNG or JPEG image.");
            var reader = readers.next();
            try {
                String format = reader.getFormatName();
                if (!format.equalsIgnoreCase("PNG") && !format.equalsIgnoreCase("JPEG")) {
                    throw new IllegalArgumentException("Choose a PNG or JPEG image.");
                }
                reader.setInput(stream);
                int width = reader.getWidth(0);
                int height = reader.getHeight(0);
                if ((long) width * height > 24_000_000) {
                    throw new IllegalArgumentException("Choose an image with fewer than 24 million pixels.");
                }
                BufferedImage sourceImage = reader.read(0);
                int side = Math.min(width, height);
                int x = (width - side) / 2;
                int y = (height - side) / 2;
                BufferedImage thumbnail = new BufferedImage(256, 256, BufferedImage.TYPE_INT_ARGB);
                Graphics2D graphics = thumbnail.createGraphics();
                graphics.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
                graphics.drawImage(sourceImage, 0, 0, 256, 256, x, y, x + side, y + side, null);
                graphics.dispose();
                return thumbnail;
            } finally {
                reader.dispose();
            }
        }
    }

    public String save(long userId, BufferedImage image) throws IOException {
        Files.createDirectories(directory);
        String name = userId + "-" + UUID.randomUUID() + ".png";
        Path path = directory.resolve(name);
        try {
            if (!ImageIO.write(image, "PNG", path.toFile())) throw new IOException("PNG writer unavailable.");
            return name;
        } catch (IOException exception) {
            remove(userId, name);
            throw exception;
        }
    }

    public BufferedImage load(long userId, String name) {
        if (!belongsTo(userId, name)) return null;
        try {
            return ImageIO.read(directory.resolve(name).toFile());
        } catch (IOException exception) {
            return null;
        }
    }

    public void remove(long userId, String name) {
        if (!belongsTo(userId, name)) return;
        try {
            Files.deleteIfExists(directory.resolve(name));
        } catch (IOException exception) {
            System.getLogger(getClass().getName()).log(System.Logger.Level.WARNING,
                    "Could not remove an unused profile image.", exception);
        }
    }

    private static boolean belongsTo(long userId, String name) {
        return name != null && name.matches(userId + "-[a-f0-9-]{36}\\.png");
    }
}
