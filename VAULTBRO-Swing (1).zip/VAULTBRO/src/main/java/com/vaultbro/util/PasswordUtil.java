package com.vaultbro.util;

import java.nio.CharBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import org.mindrot.jbcrypt.BCrypt;

public final class PasswordUtil {
    private static final int COST = 12;

    private PasswordUtil() {}

    public static String hash(char[] password, char[] confirmation) {
        if (!Arrays.equals(password, confirmation)) throw new IllegalArgumentException("The passwords do not match.");
        if (password.length < 8 || !validLength(password)
                || !CharBuffer.wrap(password).chars().anyMatch(Character::isLetter)
                || !CharBuffer.wrap(password).chars().anyMatch(Character::isDigit)) {
            throw new IllegalArgumentException("Use at least 8 characters, including a letter and a number, and at most 72 UTF-8 bytes.");
        }
        return BCrypt.hashpw(new String(password), BCrypt.gensalt(COST));
    }

    public static boolean verify(char[] password, String hash) {
        return validLength(password) && BCrypt.checkpw(new String(password), hash);
    }

    private static boolean validLength(char[] password) {
        var bytes = StandardCharsets.UTF_8.encode(CharBuffer.wrap(password));
        int length = bytes.remaining();
        if (bytes.hasArray()) Arrays.fill(bytes.array(), (byte) 0);
        return length <= 72;
    }
}
