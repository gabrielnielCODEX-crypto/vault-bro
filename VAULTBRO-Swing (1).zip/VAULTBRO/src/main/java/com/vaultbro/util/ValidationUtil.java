package com.vaultbro.util;

import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Locale;

public final class ValidationUtil {
    public static final int MIN_YEAR = 1900;
    public static final int MAX_YEAR = 9999;

    private ValidationUtil() {}

    public static String required(String value, String label, int max) {
        String text = optional(value, label, max);
        if (text.isEmpty()) throw new IllegalArgumentException(label + " is required.");
        return text;
    }

    public static String optional(String value, String label, int max) {
        String text = value == null ? "" : value.strip();
        if (text.length() > max) throw new IllegalArgumentException(label + " must be " + max + " characters or fewer.");
        return text;
    }

    public static String username(String value) {
        String name = required(value, "Username", 30);
        if (!name.matches("[A-Za-z0-9_.-]{3,30}")) {
            throw new IllegalArgumentException("Use 3–30 letters, digits, periods, underscores, or hyphens for your username.");
        }
        return name;
    }

    public static String email(String value) {
        String email = required(value, "Email address", 254).toLowerCase(Locale.ROOT);
        String[] address = email.split("@", -1);
        if (address.length != 2 || !validEmailLocal(address[0])
                || !address[1].matches("(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?")) {
            throw new IllegalArgumentException("Enter a valid email address.");
        }
        return email;
    }

    private static boolean validEmailLocal(String local) {
        return local.matches("[a-z0-9.!#$%&'*+/=?^_`{|}~-]{1,64}")
                && !local.startsWith(".") && !local.endsWith(".") && !local.contains("..");
    }

    public static LocalDate date(String value, String label) {
        try {
            return date(LocalDate.parse(value.strip()), label);
        } catch (DateTimeParseException exception) {
            throw new IllegalArgumentException(label + " must be a valid date in YYYY-MM-DD format.");
        }
    }

    public static LocalDate date(LocalDate value, String label) {
        if (value == null || value.getYear() < MIN_YEAR || value.getYear() > MAX_YEAR) {
            throw new IllegalArgumentException(label + " must be between 1900 and 9999.");
        }
        return value;
    }

    public static YearMonth month(String value) {
        try {
            YearMonth month = YearMonth.parse(value.strip());
            date(month.atDay(1), "Month");
            return month;
        } catch (DateTimeParseException exception) {
            throw new IllegalArgumentException("Enter a valid month in YYYY-MM format.");
        }
    }

    public static void category(String category, List<String> allowed) {
        if (category == null || !allowed.contains(category)) {
            throw new IllegalArgumentException("Select a valid category.");
        }
    }
}
