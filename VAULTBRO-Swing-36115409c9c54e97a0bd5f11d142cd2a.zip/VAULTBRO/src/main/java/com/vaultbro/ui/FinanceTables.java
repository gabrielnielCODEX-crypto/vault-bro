package com.vaultbro.ui;

import com.vaultbro.model.*;
import com.vaultbro.util.Ui;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.time.LocalDate;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

final class FinanceTables {
    private FinanceTables() {}

    static final class Transactions {
        final DefaultTableModel model;
        final JTable table;
        final boolean compact;

        Transactions(boolean compact) {
            this.compact = compact;
            String[] columns = compact
                    ? new String[]{"Date", "Description", "Category", "Amount"}
                    : new String[]{"ID", "Date", "Description", "Category", "Type", "Amount"};
            Class<?>[] types = compact
                    ? new Class<?>[]{LocalDate.class, String.class, String.class, Long.class}
                    : new Class<?>[]{Long.class, LocalDate.class, String.class, String.class, String.class, Long.class};
            model = Ui.tableModel(columns, types);
            table = Ui.table(model);
            if (!compact) {
                table.getColumnModel().getColumn(0).setMaxWidth(59);
                table.getColumnModel().getColumn(2).setPreferredWidth(270);
            } else {
                table.getColumnModel().getColumn(1).setPreferredWidth(170);
            }
            amount(table, columns.length - 1, true, true);
        }

        void set(List<Transaction> transactions) {
            model.setRowCount(0);
            for (Transaction record : transactions) {
                String description = record.getDescription().replaceAll("\\h*\\R\\h*", " ");
                if (compact) {
                    model.addRow(new Object[]{record.getDate(), description, record.getCategory(), record.getSignedAmount()});
                } else {
                    model.addRow(new Object[]{record.getId(), record.getDate(), description, record.getCategory(),
                            record.getType().toString(), record.getSignedAmount()});
                }
            }
        }
    }

    static void money(JTable table, int column, boolean signed) {
        amount(table, column, signed, false);
    }

    private static void amount(JTable table, int column, boolean signed, boolean showPlus) {
        table.getColumnModel().getColumn(column).setCellRenderer(new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable source, Object value,
                    boolean selected, boolean focus, int row, int viewColumn) {
                long cents = value instanceof Number number ? number.longValue() : 0;
                super.getTableCellRendererComponent(source, (showPlus && cents > 0 ? "+" : "") + Money.format(cents),
                        selected, focus, row, viewColumn);
                setHorizontalAlignment(SwingConstants.RIGHT);
                setBorder(new EmptyBorder(0, 8, 0, 10));
                if (signed) setForeground(cents < 0 ? Ui.RED : Ui.GREEN);
                return this;
            }
        });
    }

    static Color budgetColor(BudgetUsage.Status status) {
        return switch (status) {
            case ON_TRACK -> Ui.GREEN;
            case NEAR_LIMIT -> Ui.AMBER;
            case OVER_BUDGET -> Ui.RED;
        };
    }

    static Color goalColor(SavingsGoal.Status status) {
        return switch (status) {
            case IN_PROGRESS -> Ui.CYAN;
            case ACHIEVED -> Ui.GREEN;
            case OVERDUE -> Ui.RED;
        };
    }

    static TableCellRenderer progressRenderer(java.util.function.DoubleFunction<Color> colorFor) {
        return (table, value, selected, focus, row, column) -> {
            double percent = (double) value;
            Color color = colorFor.apply(percent);
            JPanel panel = new JPanel(new java.awt.BorderLayout(7, 0));
            panel.setBackground(selected ? table.getSelectionBackground() : table.getBackground());
            panel.setBorder(new EmptyBorder(0, 8, 0, 8));
            JPanel bar = Ui.transparent(new java.awt.GridBagLayout());
            JProgressBar progress = Ui.progress(percent, color);
            progress.setPreferredSize(new Dimension(35, 7));
            java.awt.GridBagConstraints fill = new java.awt.GridBagConstraints();
            fill.weightx = 1;
            fill.fill = java.awt.GridBagConstraints.HORIZONTAL;
            bar.add(progress, fill);
            panel.add(bar);
            panel.add(Ui.label(percent(percent), 11, true, color), java.awt.BorderLayout.EAST);
            return panel;
        };
    }

    static TableCellRenderer statusBadge(java.util.function.Function<Object, Color> colorFor) {
        return (table, value, selected, focus, row, column) -> {
            JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 2, 6));
            panel.setBackground(selected ? table.getSelectionBackground() : table.getBackground());
            panel.add(Ui.badge(value.toString(), colorFor.apply(value)));
            return panel;
        };
    }

    static String percent(double value) {
        return String.format(java.util.Locale.ROOT, "%.1f%%", value);
    }

    static JScrollPane tableScroll(JTable table, int height) {
        JScrollPane scroll = Ui.scroll(table);
        scroll.setPreferredSize(new Dimension(350, height));
        scroll.getViewport().setBackground(Ui.CARD);
        return scroll;
    }

    static JTable budgetTable(DefaultTableModel model) {
        JTable table = Ui.table(model);
        table.getColumnModel().getColumn(0).setMaxWidth(65);
        table.getColumnModel().getColumn(1).setPreferredWidth(150);
        for (int column = 3; column <= 5; column++) money(table, column, column == 5);
        table.getColumnModel().getColumn(6).setPreferredWidth(125);
        table.getColumnModel().getColumn(6).setCellRenderer(progressRenderer(value ->
                value > 100 ? Ui.RED : value >= 80 ? Ui.AMBER : Ui.GREEN));
        table.getColumnModel().getColumn(7).setMinWidth(100);
        table.getColumnModel().getColumn(7).setCellRenderer(statusBadge(value -> budgetColor((BudgetUsage.Status) value)));
        return table;
    }

    static DefaultTableModel budgetModel() {
        return Ui.tableModel(new String[]{"ID", "Category", "Month", "Limit", "Spent", "Remaining", "Usage", "Status"},
                new Class<?>[]{Long.class, String.class, java.time.YearMonth.class, Long.class, Long.class, Long.class,
                        Double.class, BudgetUsage.Status.class});
    }

    static void budgetRows(DefaultTableModel model, List<BudgetUsage> budgets) {
        model.setRowCount(0);
        for (BudgetUsage usage : budgets) {
            Budget budget = usage.budget();
            model.addRow(new Object[]{budget.id(), budget.category(), budget.period(), budget.monthlyLimit(),
                    usage.spent(), usage.remaining(), usage.percent(), usage.status()});
        }
    }

    static JTextArea notes(String value, int rows) {
        JTextArea area = new JTextArea(value, rows, 24);
        area.putClientProperty("html.disable", true);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setMargin(new java.awt.Insets(6, 8, 6, 8));
        return area;
    }
}
