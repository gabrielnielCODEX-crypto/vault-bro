package com.vaultbro.dao;

import com.vaultbro.database.Database;
import com.vaultbro.model.Budget;
import com.vaultbro.model.BudgetUsage;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.List;

public final class BudgetDAO {
    private final Database database;

    public BudgetDAO(Database database) { this.database = database; }

    public List<BudgetUsage> find(long userId) throws SQLException {
        // Monthly usage comes directly from expenses, independent of other budget records.
        try (var connection = database.open(); var query = connection.prepareStatement("""
                SELECT b.*, COALESCE((SELECT SUM(t.amount) FROM transactions t
                    WHERE t.user_id = b.user_id AND t.type = 'EXPENSE'
                    AND t.transaction_date >= printf('%04d-%02d-01', b.year, b.month)
                    AND t.transaction_date <= printf('%04d-%02d-31', b.year, b.month)
                    AND (b.category = 'Overall' OR b.category = t.category)), 0) AS spent
                FROM budget b WHERE b.user_id = ?
                ORDER BY b.year DESC, b.month DESC, (b.category = 'Overall') DESC, b.category
                """)) {
            query.setLong(1, userId);
            try (var result = query.executeQuery()) {
                List<BudgetUsage> records = new ArrayList<>();
                while (result.next()) {
                    String date = result.getString("budget_date");
                    Budget budget = new Budget(result.getLong("id"), result.getString("category"),
                            result.getLong("monthly_limit"), YearMonth.of(result.getInt("year"), result.getInt("month")),
                            date == null ? null : LocalDate.parse(date));
                    records.add(new BudgetUsage(budget, result.getLong("spent")));
                }
                return records;
            }
        }
    }

    public void save(long userId, Budget budget) throws SQLException {
        String sql = budget.id() == 0
                ? "INSERT INTO budget(category, monthly_limit, month, year, budget_date, user_id) VALUES (?, ?, ?, ?, ?, ?)"
                : """
                  UPDATE budget SET category = ?1, monthly_limit = ?2, month = ?3, year = ?4,
                      budget_date = COALESCE(?5, CASE WHEN month = ?3 AND year = ?4 THEN budget_date END)
                  WHERE user_id = ?6 AND id = ?7
                  """;
        try (var connection = database.open(); var query = connection.prepareStatement(sql)) {
            query.setString(1, budget.category());
            query.setLong(2, budget.monthlyLimit());
            query.setInt(3, budget.period().getMonthValue());
            query.setInt(4, budget.period().getYear());
            query.setString(5, budget.date() == null ? null : budget.date().toString());
            query.setLong(6, userId);
            if (budget.id() != 0) query.setLong(7, budget.id());
            DaoErrors.found(query.executeUpdate());
        } catch (SQLException exception) {
            throw DaoErrors.duplicate(exception, "You already have a budget for this category and month.");
        }
    }

    public void delete(long userId, long id) throws SQLException {
        try (var connection = database.open();
             var query = connection.prepareStatement("DELETE FROM budget WHERE user_id = ? AND id = ?")) {
            query.setLong(1, userId);
            query.setLong(2, id);
            DaoErrors.found(query.executeUpdate());
        }
    }
}
