package com.vaultbro.util;

import com.formdev.flatlaf.FlatDarkLaf;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.sql.SQLException;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.function.Consumer;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

public final class Ui {
    public static final Color BACKGROUND = color(0x10121B);
    public static final Color SIDEBAR = color(0x141620);
    public static final Color CARD = color(0x1B1E2B);
    public static final Color CONTROL = color(0x272B3C);
    public static final Color BORDER = color(0x353A4E);
    public static final Color TEXT = color(0xF1F0FA);
    public static final Color MUTED = color(0xA5ABC5);
    public static final Color ACCENT = color(0x7945E3);
    public static final Color LAVENDER = color(0xB59AFF);
    public static final Color GREEN = color(0x54DBA8);
    public static final Color RED = color(0xFF8B9C);
    public static final Color AMBER = color(0xF4BA73);
    public static final Color CYAN = color(0x55D0E1);

    @FunctionalInterface public interface Action { void run() throws Exception; }
    private Ui() {}

    public static Color color(int rgb) { return new Color(rgb); }

    public static void setup() {
        FlatDarkLaf.setup();
        UIManager.put("defaultFont", UIManager.getFont("Label.font").deriveFont(Font.PLAIN, 14f));
        UIManager.put("Panel.background", BACKGROUND);
        UIManager.put("Label.foreground", TEXT);
        UIManager.put("TextField.background", CONTROL);
        UIManager.put("TextField.foreground", TEXT);
        UIManager.put("TextArea.background", CONTROL);
        UIManager.put("TextArea.foreground", TEXT);
        UIManager.put("PasswordField.background", CONTROL);
        UIManager.put("PasswordField.showRevealButton", true);
        UIManager.put("Component.arc", 12);
        UIManager.put("TextComponent.arc", 10);
        UIManager.put("Component.borderColor", BORDER);
        UIManager.put("Component.focusColor", LAVENDER);
        UIManager.put("Component.focusWidth", 2);
        UIManager.put("Button.arc", 12);
        UIManager.put("Button.background", CONTROL);
        UIManager.put("Button.foreground", TEXT);
        UIManager.put("Button.borderColor", BORDER);
        UIManager.put("Button.disabledBackground", color(0x202233));
        UIManager.put("Button.disabledText", color(0x747A94));
        UIManager.put("Button.disabledBorderColor", BORDER);
        UIManager.put("Button.hoverBackground", color(0x30334C));
        UIManager.put("ComboBox.background", CONTROL);
        UIManager.put("ComboBox.buttonBackground", CONTROL);
        UIManager.put("ComboBox.buttonArrowColor", MUTED);
        UIManager.put("ComboBox.foreground", TEXT);
        UIManager.put("TextField.selectionBackground", color(0x514177));
        UIManager.put("TextField.selectionForeground", TEXT);
        UIManager.put("Separator.foreground", BORDER);
        UIManager.put("ScrollPane.background", BACKGROUND);
        UIManager.put("Viewport.background", BACKGROUND);
        UIManager.put("ScrollBar.track", BACKGROUND);
        UIManager.put("ScrollBar.thumb", BORDER);
        UIManager.put("ScrollBar.hoverThumbColor", CONTROL.brighter());
        UIManager.put("Table.background", CARD);
        UIManager.put("Table.foreground", TEXT);
        UIManager.put("Table.alternateRowColor", color(0x202332));
        UIManager.put("Table.selectionBackground", color(0x3B2D64));
        UIManager.put("Table.selectionForeground", TEXT);
        UIManager.put("Table.selectionInactiveBackground", color(0x332749));
        UIManager.put("Table.selectionInactiveForeground", TEXT);
        UIManager.put("TableHeader.background", color(0x252939));
        UIManager.put("TableHeader.foreground", TEXT);
        UIManager.put("TabbedPane.background", BACKGROUND);
        UIManager.put("TabbedPane.foreground", MUTED);
        UIManager.put("TabbedPane.selectedBackground", CONTROL);
        UIManager.put("TabbedPane.selectedForeground", TEXT);
        UIManager.put("TabbedPane.hoverColor", CONTROL);
        UIManager.put("TabbedPane.underlineColor", LAVENDER);
        UIManager.put("TabbedPane.inactiveUnderlineColor", LAVENDER);
        UIManager.put("TabbedPane.contentAreaColor", BORDER);
        UIManager.put("ProgressBar.background", CONTROL);
        UIManager.put("ProgressBar.foreground", ACCENT);
        UIManager.put("ProgressBar.arc", 12);
        UIManager.put("OptionPane.background", CARD);
        UIManager.put("PopupMenu.background", CARD);
        UIManager.put("List.background", CARD);
        UIManager.put("ToolTip.background", CONTROL);
    }

    public static JLabel label(String text, int size, boolean bold, Color color) {
        JLabel label = new JLabel(text);
        label.setFont(label.getFont().deriveFont(bold ? Font.BOLD : Font.PLAIN, (float) size));
        label.setForeground(color);
        label.putClientProperty("html.disable", true);
        return label;
    }

    public static JPanel transparent(LayoutManager layout) {
        JPanel panel = new JPanel(layout);
        panel.setOpaque(false);
        return panel;
    }

    public static JPanel column() {
        JPanel panel = transparent(null);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setAlignmentX(Component.LEFT_ALIGNMENT);
        return panel;
    }

    public static JPanel card(LayoutManager layout, int padding) {
        return card(layout, padding, CARD, BORDER);
    }

    public static JPanel card(LayoutManager layout, int padding, Color background, Color outline) {
        return card(layout, padding, background, background, outline);
    }

    public static JPanel card(LayoutManager layout, int padding, Color start, Color end, Color outline) {
        JPanel panel = new JPanel(layout) {
            @Override protected void paintComponent(Graphics graphics) {
                Graphics2D draw = (Graphics2D) graphics.create();
                draw.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                draw.setPaint(start.equals(end) ? start : new GradientPaint(0, 0, start, getWidth(), getHeight(), end));
                draw.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 20, 20);
                draw.setColor(outline);
                draw.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 20, 20);
                draw.dispose();
            }
        };
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(padding, padding, padding, padding));
        panel.setAlignmentX(Component.LEFT_ALIGNMENT);
        return panel;
    }

    public static void stack(JPanel column, JComponent component, int gap) {
        component.setAlignmentX(Component.LEFT_ALIGNMENT);
        // Allow wide cards to grow horizontally while keeping their preferred height.
        component.setMaximumSize(new Dimension(Short.MAX_VALUE, component.getPreferredSize().height));
        column.add(component);
        if (gap > 0) column.add(Box.createVerticalStrut(gap));
    }

    public static JButton button(String text, boolean primary, Runnable action) {
        JButton button = new JButton(text);
        button.putClientProperty("html.disable", true);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setMargin(new Insets(9, 14, 9, 14));
        button.setFont(button.getFont().deriveFont(Font.BOLD, 13f));
        if (primary) {
            button.setBackground(ACCENT);
            button.setForeground(Color.WHITE);
            button.putClientProperty("FlatLaf.style",
                    "hoverBackground: #8969f2; pressedBackground: #6647ce; borderColor: #967cf1; focusedBorderColor: #b59aff");
        }
        if (action != null) button.addActionListener(event -> action.run());
        return button;
    }

    public static JButton tintedButton(String text, Color accent, Runnable action) {
        JButton button = button(text, false, action);
        button.setBackground(tint(accent, .13));
        button.setForeground(accent);
        button.putClientProperty("FlatLaf.style", "borderColor: " + hex(tint(accent, .38))
                + "; hoverBackground: " + hex(tint(accent, .23)));
        return button;
    }

    public static JButton textButton(String text, Runnable action) {
        JButton button = button(text, false, action);
        button.putClientProperty("JButton.buttonType", "toolBarButton");
        button.setForeground(LAVENDER);
        button.setMargin(new Insets(4, 8, 4, 8));
        return button;
    }

    public static JLabel badge(String text, Color color) {
        JLabel label = new JLabel(text) {
            @Override protected void paintComponent(Graphics graphics) {
                Graphics2D draw = (Graphics2D) graphics.create();
                draw.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                draw.setColor(getBackground());
                draw.fillRoundRect(0, 0, getWidth(), getHeight(), getHeight(), getHeight());
                draw.dispose();
                super.paintComponent(graphics);
            }
        };
        label.putClientProperty("html.disable", true);
        label.setForeground(color);
        label.setBackground(tint(color, .16));
        label.setFont(label.getFont().deriveFont(Font.BOLD, 11f));
        label.setBorder(new EmptyBorder(4, 9, 4, 9));
        return label;
    }

    public static Color tint(Color accent, double strength) {
        return new Color(
                (int) (CARD.getRed() + (accent.getRed() - CARD.getRed()) * strength),
                (int) (CARD.getGreen() + (accent.getGreen() - CARD.getGreen()) * strength),
                (int) (CARD.getBlue() + (accent.getBlue() - CARD.getBlue()) * strength));
    }

    private static String hex(Color color) {
        return String.format(java.util.Locale.ROOT, "#%06x", color.getRGB() & 0xFFFFFF);
    }

    public static JTextField field(int columns, String placeholder) {
        JTextField field = new JTextField(columns);
        field.putClientProperty("JTextField.placeholderText", placeholder);
        return field;
    }

    public static JPasswordField password(int columns, String placeholder) {
        JPasswordField field = new JPasswordField(columns);
        field.putClientProperty("JTextField.placeholderText", placeholder);
        return field;
    }

    public static void changed(JTextField field, Runnable change) {
        field.getDocument().addDocumentListener(new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent event) { change.run(); }
            @Override public void removeUpdate(DocumentEvent event) { change.run(); }
            @Override public void changedUpdate(DocumentEvent event) { change.run(); }
        });
    }

    public static JLabel fieldLabel(String text, JComponent field) {
        JLabel label = label(text, 13, true, TEXT);
        label.setLabelFor(field);
        field.getAccessibleContext().setAccessibleName(text);
        return label;
    }

    public static void fieldRow(JPanel column, String name, JComponent field) {
        if (field instanceof JTextField || field instanceof JComboBox<?>) {
            field.setPreferredSize(new Dimension(Math.max(125, field.getPreferredSize().width), 39));
        }
        stack(column, fieldLabel(name, field), 7);
        stack(column, field, 13);
    }

    public static JPanel actions(JButton... buttons) {
        JPanel panel = transparent(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        for (JButton button : buttons) panel.add(button);
        return panel;
    }

    public static JScrollPane scroll(JComponent content) {
        JScrollPane scroll = new JScrollPane(content);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.getVerticalScrollBar().setUnitIncrement(20);
        scroll.getViewport().setBackground(BACKGROUND);
        return scroll;
    }

    public static JScrollPane page(JPanel content) {
        content.setBorder(new EmptyBorder(20, 26, 24, 26));
        JScrollPane scroll = scroll(new PageBody(content));
        scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        return scroll;
    }

    private static final class PageBody extends JPanel implements Scrollable {
        PageBody(JPanel content) {
            super(new BorderLayout());
            add(content, BorderLayout.NORTH);
        }
        @Override public Dimension getPreferredScrollableViewportSize() { return getPreferredSize(); }
        @Override public boolean getScrollableTracksViewportWidth() { return true; }
        @Override public boolean getScrollableTracksViewportHeight() { return false; }
        @Override public int getScrollableUnitIncrement(Rectangle visible, int axis, int direction) { return 20; }
        @Override public int getScrollableBlockIncrement(Rectangle visible, int axis, int direction) {
            return Math.max(20, visible.height - 20);
        }
    }

    public static javax.swing.table.DefaultTableModel tableModel(String[] columns, Class<?>[] types) {
        return new DefaultTableModel(columns, 0) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
            @Override public Class<?> getColumnClass(int column) { return types[column]; }
        };
    }

    public static JTable table(DefaultTableModel model) {
        JTable table = new JTable(model) {
            @Override public boolean getScrollableTracksViewportWidth() {
                if (getParent() instanceof JViewport viewport) {
                    return viewport.getWidth() >= getMinimumSize().width;
                }
                return super.getScrollableTracksViewportWidth();
            }
        };
        table.setRowHeight(40);
        table.setShowHorizontalLines(true);
        table.setShowVerticalLines(false);
        table.setGridColor(BORDER);
        table.setIntercellSpacing(new Dimension(0, 1));
        table.setAutoCreateRowSorter(true);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getTableHeader().setReorderingAllowed(false);
        table.getTableHeader().setFont(table.getFont().deriveFont(Font.BOLD, 12f));
        table.getTableHeader().setPreferredSize(new Dimension(0, 36));
        table.setFillsViewportHeight(true);
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable source, Object value,
                    boolean selected, boolean focus, int row, int column) {
                super.getTableCellRendererComponent(source, value, selected, focus, row, column);
                putClientProperty("html.disable", true);
                setBorder(new EmptyBorder(0, 10, 0, 10));
                setToolTipText(getText());
                return this;
            }
        });
        return table;
    }

    public static JProgressBar progress(double percent, Color color) {
        JProgressBar bar = new JProgressBar(0, 100);
        bar.setValue((int) Math.round(Math.min(100, Math.max(0, percent))));
        bar.setForeground(color);
        bar.setPreferredSize(new Dimension(130, 8));
        return bar;
    }

    public static Icon avatar(String name, BufferedImage picture, int size) {
        return new Icon() {
            @Override public int getIconWidth() { return size; }
            @Override public int getIconHeight() { return size; }
            @Override public void paintIcon(Component component, Graphics graphics, int x, int y) {
                Graphics2D draw = (Graphics2D) graphics.create(x, y, size, size);
                draw.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                draw.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
                if (picture != null) {
                    BufferedImage avatar = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
                    Graphics2D mask = avatar.createGraphics();
                    mask.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    mask.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
                    mask.fillOval(0, 0, size, size);
                    mask.setComposite(AlphaComposite.SrcIn);
                    mask.drawImage(picture, 0, 0, size, size, null);
                    mask.dispose();
                    draw.drawImage(avatar, 0, 0, null);
                } else {
                    draw.setColor(color(0x362A57));
                    draw.fillOval(0, 0, size, size);
                    draw.setColor(LAVENDER);
                    draw.setFont(component.getFont().deriveFont(Font.BOLD, size * .38f));
                    String clean = name.strip();
                    String initials = clean.isEmpty() ? "?" : clean.substring(0, clean.offsetByCodePoints(0, 1)).toUpperCase(java.util.Locale.ROOT);
                    FontMetrics metrics = draw.getFontMetrics();
                    draw.drawString(initials, (size - metrics.stringWidth(initials)) / 2,
                            (size - metrics.getHeight()) / 2 + metrics.getAscent());
                }
                draw.dispose();
            }
        };
    }

    public static void run(Component parent, Action action) {
        try {
            action.run();
        } catch (Exception exception) {
            error(parent, exception);
        }
    }

    public static <T> void background(Component parent, JButton button, Callable<T> work, Consumer<T> success) {
        button.setEnabled(false);
        new SwingWorker<T, Void>() {
            @Override protected T doInBackground() throws Exception { return work.call(); }
            @Override protected void done() {
                button.setEnabled(true);
                if (!parent.isDisplayable()) return;
                try {
                    success.accept(get());
                } catch (ExecutionException exception) {
                    error(parent, exception.getCause());
                } catch (InterruptedException exception) {
                    Thread.currentThread().interrupt();
                } catch (RuntimeException exception) {
                    error(parent, exception);
                }
            }
        }.execute();
    }

    public static void error(Component parent, Throwable exception) {
        String message;
        if (exception instanceof IllegalArgumentException || exception instanceof IllegalStateException) {
            message = exception.getMessage();
        } else {
            System.getLogger(Ui.class.getName()).log(System.Logger.Level.ERROR, "VAULTBRO operation failed.", exception);
            if (exception instanceof SQLException) message = "The database operation failed. Try again.";
            else if (exception instanceof IOException) message = "The file could not be read or saved. Check its location and permissions.";
            else message = "Something went wrong. Try again.";
        }
        JOptionPane.showMessageDialog(parent, message, "VAULTBRO", JOptionPane.ERROR_MESSAGE);
    }

    public static boolean confirm(Component parent, String title, String message) {
        return JOptionPane.showConfirmDialog(parent, message, title,
                JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE) == JOptionPane.YES_OPTION;
    }

    public static void formSubmit(Window owner, String title, String submitText, JPanel form, Action action) {
        JDialog dialog = new JDialog(owner, title, Dialog.ModalityType.APPLICATION_MODAL);
        dialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        FormPane content = new FormPane(form, submitText, action, dialog::dispose);
        dialog.setContentPane(content);
        dialog.getRootPane().setDefaultButton(content.submit);
        dialog.getRootPane().registerKeyboardAction(event -> dialog.dispose(),
                KeyStroke.getKeyStroke("ESCAPE"), JComponent.WHEN_IN_FOCUSED_WINDOW);
        dialog.pack();
        Rectangle screen = usableBounds(dialog);
        dialog.setMinimumSize(new Dimension(Math.min(390, screen.width), Math.min(200, screen.height)));
        dialog.setSize(Math.min(screen.width, Math.max(430, dialog.getWidth())), Math.min(screen.height, dialog.getHeight()));
        dialog.setLocationRelativeTo(owner);
        dialog.setVisible(true);
    }

    private static Rectangle usableBounds(Window window) {
        GraphicsConfiguration screen = window.getGraphicsConfiguration();
        Rectangle bounds = screen.getBounds();
        Insets insets = Toolkit.getDefaultToolkit().getScreenInsets(screen);
        return new Rectangle(bounds.x + insets.left, bounds.y + insets.top,
                bounds.width - insets.left - insets.right, bounds.height - insets.top - insets.bottom);
    }

    static final class FormPane extends JPanel {
        final JButton submit;

        FormPane(JPanel form, String submitText, Action action, Runnable close) {
            super(new BorderLayout());
            form.setBorder(new EmptyBorder(22, 24, 20, 24));
            JScrollPane body = scroll(new PageBody(form));
            body.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
            add(body);
            JTextArea feedback = new JTextArea(2, 25);
            feedback.setLineWrap(true);
            feedback.setWrapStyleWord(true);
            feedback.setEditable(false);
            feedback.setOpaque(false);
            feedback.setForeground(RED);
            feedback.setFont(UIManager.getFont("Label.font").deriveFont(13f));
            feedback.getAccessibleContext().setAccessibleName("Form error");
            feedback.setVisible(false);
            submit = button(submitText, true, () -> {
                try {
                    action.run();
                    close.run();
                } catch (IllegalArgumentException validation) {
                    feedback.setText(validation.getMessage());
                    feedback.setVisible(true);
                    revalidate();
                    Window window = SwingUtilities.getWindowAncestor(this);
                    if (window != null) {
                        Rectangle screen = usableBounds(window);
                        int height = Math.min(screen.height, Math.max(window.getHeight(), window.getPreferredSize().height));
                        int y = Math.max(screen.y, Math.min(window.getY(), screen.y + screen.height - height));
                        window.setBounds(window.getX(), y, window.getWidth(), height);
                    }
                    repaint();
                } catch (Exception failure) {
                    error(this, failure);
                }
            });
            JPanel footer = new JPanel(new BorderLayout(0, 8));
            footer.setBackground(CARD);
            footer.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, BORDER),
                    new EmptyBorder(12, 16, 12, 16)));
            footer.add(feedback, BorderLayout.NORTH);
            footer.add(actions(button("Cancel", false, close), submit));
            add(footer, BorderLayout.SOUTH);
        }
    }
}
