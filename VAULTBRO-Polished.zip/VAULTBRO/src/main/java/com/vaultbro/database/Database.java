package com.vaultbro.database;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.PosixFilePermissions;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.UUID;
import org.sqlite.SQLiteConfig;

public final class Database {
    private static final int SCHEMA_VERSION = 2;
    private static final int APPLICATION_ID = 0x564C5442; // VLTB

    private static final List<String> SCHEMA = List.of(
        """
        CREATE TABLE users (
            id INTEGER PRIMARY KEY,
            full_name TEXT NOT NULL CHECK(length(trim(full_name)) > 0),
            username TEXT NOT NULL COLLATE NOCASE UNIQUE,
            email TEXT NOT NULL COLLATE NOCASE UNIQUE,
            password_hash TEXT NOT NULL,
            profile_image_path TEXT,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) STRICT
        """,
        """
        CREATE TABLE transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            description TEXT NOT NULL CHECK(length(trim(description)) > 0),
            type TEXT NOT NULL CHECK(type IN ('INCOME', 'EXPENSE')),
            category TEXT NOT NULL CHECK(length(trim(category)) > 0),
            amount INTEGER NOT NULL CHECK(amount BETWEEN 1 AND 99999999999),
            transaction_date TEXT NOT NULL
        ) STRICT
        """,
        """
        CREATE TABLE budget (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            category TEXT NOT NULL COLLATE NOCASE,
            monthly_limit INTEGER NOT NULL CHECK(monthly_limit BETWEEN 1 AND 99999999999),
            month INTEGER NOT NULL CHECK(month BETWEEN 1 AND 12),
            year INTEGER NOT NULL CHECK(year BETWEEN 1900 AND 9999),
            UNIQUE(user_id, category, month, year)
        ) STRICT
        """,
        """
        CREATE TABLE goal (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            goal_name TEXT NOT NULL CHECK(length(trim(goal_name)) > 0),
            category TEXT NOT NULL CHECK(length(trim(category)) > 0),
            target_amount INTEGER NOT NULL CHECK(target_amount BETWEEN 1 AND 99999999999),
            target_date TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) STRICT
        """,
        """
        CREATE TABLE goal_entry (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            goal_id INTEGER NOT NULL REFERENCES goal(id) ON DELETE CASCADE,
            entry_type TEXT NOT NULL CHECK(entry_type IN ('CONTRIBUTION', 'WITHDRAWAL')),
            amount INTEGER NOT NULL CHECK(amount BETWEEN 1 AND 99999999999),
            entry_date TEXT NOT NULL,
            description TEXT NOT NULL DEFAULT ''
        ) STRICT
        """,
        "CREATE INDEX transaction_user_date ON transactions(user_id, transaction_date DESC, id DESC)",
        "CREATE INDEX budget_user_period ON budget(user_id, year DESC, month DESC)",
        "CREATE INDEX goal_user ON goal(user_id, id)",
        "CREATE INDEX entry_goal_date ON goal_entry(goal_id, entry_date DESC, id DESC)"
    );

    private final Path path;

    public Database(Path path) {
        this.path = path.toAbsolutePath().normalize();
    }

    public Path directory() { return path.getParent(); }

    public Connection open() throws SQLException {
        SQLiteConfig config = new SQLiteConfig();
        config.enforceForeignKeys(true);
        config.setBusyTimeout(5000);
        config.setTransactionMode(SQLiteConfig.TransactionMode.IMMEDIATE);
        return config.createConnection("jdbc:sqlite:" + path);
    }

    public void initialize() throws IOException, SQLException {
        if (path.getFileSystem().supportedFileAttributeViews().contains("posix")) {
            Files.createDirectories(directory(),
                    PosixFilePermissions.asFileAttribute(PosixFilePermissions.fromString("rwx------")));
        } else {
            Files.createDirectories(directory());
        }
        try (Connection connection = open(); Statement statement = connection.createStatement()) {
            connection.setAutoCommit(false);
            int version;
            try (var result = statement.executeQuery("PRAGMA user_version")) {
                version = result.getInt(1);
            }
            int applicationId;
            try (var result = statement.executeQuery("PRAGMA application_id")) {
                applicationId = result.getInt(1);
            }
            if (applicationId == APPLICATION_ID && version == SCHEMA_VERSION) {
                connection.commit();
                return;
            }
            boolean empty;
            try (var result = statement.executeQuery(
                    "SELECT 1 FROM sqlite_schema WHERE name NOT LIKE 'sqlite_%' LIMIT 1")) {
                empty = !result.next();
            }
            if (applicationId == 0 && version == 0 && empty) {
                for (String sql : SCHEMA) statement.executeUpdate(sql);
                statement.executeUpdate("PRAGMA application_id = " + APPLICATION_ID);
            } else if (applicationId != APPLICATION_ID || version != 1) {
                // VACUUM INTO creates a consistent backup even if the original uses WAL.
                connection.setAutoCommit(true);
                Path backup = directory().resolve(path.getFileName() + ".backup-" + UUID.randomUUID());
                try (var copy = connection.prepareStatement("VACUUM INTO ?")) {
                    copy.setString(1, backup.toString());
                    copy.execute();
                }
                throw new SQLException("Database schema version " + version + " is unsupported. Original data was preserved. Backup: " + backup);
            }
            // Version 1 recorded only the month. Leave its exact day unknown until the user chooses one.
            statement.executeUpdate("""
                    ALTER TABLE budget ADD COLUMN budget_date TEXT CHECK (
                        budget_date IS NULL OR (date(budget_date, '+0 days') IS budget_date
                        AND substr(budget_date, 1, 7) = printf('%04d-%02d', year, month)))
                    """);
            statement.executeUpdate("PRAGMA user_version = " + SCHEMA_VERSION);
            connection.commit();
        }
    }
}
