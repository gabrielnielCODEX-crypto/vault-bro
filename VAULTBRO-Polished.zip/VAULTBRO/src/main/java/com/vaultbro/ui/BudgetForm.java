package com.vaultbro.ui;

import com.vaultbro.controller.FinanceController;
import com.vaultbro.model.Budget;
import com.vaultbro.model.Money;
import com.vaultbro.util.Ui;
import com.vaultbro.util.ValidationUtil;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import javax.swing.*;

final class BudgetForm extends JPanel {
    private static final DateTimeFormatter MONTH = DateTimeFormatter.ofPattern("MMMM uuuu", Locale.ENGLISH);
    private final Budget original;
    private final JComboBox<String> category = new JComboBox<>(FinanceController.budgetCategories().toArray(String[]::new));
    private final JTextField limit = Ui.field(22, "0.00");
    private final JTextField date;
    private final JLabel coverage = Ui.label("", 12, false, Ui.MUTED);

    BudgetForm(Budget original, YearMonth filterMonth) {
        this.original = original;
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setOpaque(false);
        LocalDate today = LocalDate.now();
        YearMonth month = filterMonth == null ? YearMonth.from(today) : filterMonth;
        LocalDate initial = month.equals(YearMonth.from(today)) ? today : month.atDay(1);
        if (original != null) {
            category.setSelectedItem(original.category());
            limit.setText(Money.decimal(original.monthlyLimit()));
            month = original.period();
            initial = original.date();
        }
        Ui.fieldRow(this, "Category", category);
        Ui.fieldRow(this, "Monthly limit (₱)", limit);
        date = CalendarPicker.addField(this, "Budget date", initial, month);
        updateCoverage();
        Ui.stack(this, coverage, 0);
        Ui.changed(date, this::updateCoverage);
    }

    private boolean keepRecordedMonth() {
        return original != null && original.date() == null && date.getText().isBlank();
    }

    private void updateCoverage() {
        if (keepRecordedMonth()) {
            coverage.setText("Saved for " + original.period().format(MONTH) + ". You can add a day.");
            return;
        }
        try {
            LocalDate selected = ValidationUtil.date(date.getText(), "Budget date");
            coverage.setText("This limit covers all of " + selected.format(MONTH) + ".");
        } catch (IllegalArgumentException incompleteDate) {
            coverage.setText("Choose a day or enter YYYY-MM-DD.");
        }
    }

    void save(FinanceController finance) throws SQLException {
        String selected = (String) category.getSelectedItem();
        if (keepRecordedMonth()) {
            finance.saveBudget(original.id(), selected, limit.getText(), original.period().toString());
        } else {
            finance.saveBudget(original == null ? 0 : original.id(), selected, limit.getText(),
                    ValidationUtil.date(date.getText(), "Budget date"));
        }
    }
}
