package com.vaultbro.ui;

import com.vaultbro.util.Ui;
import com.vaultbro.util.ValidationUtil;
import java.awt.*;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.time.temporal.WeekFields;
import java.util.Locale;
import java.util.function.Consumer;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

final class CalendarPicker extends JPanel {
    private final JLabel heading = Ui.label("", 15, true, Ui.TEXT);
    private final JPanel days = Ui.transparent(new GridLayout(6, 7, 3, 3));
    private final LocalDate selected;
    private final Consumer<LocalDate> choose;
    private final Locale locale = Locale.getDefault(Locale.Category.FORMAT);
    private final DayOfWeek firstDay = WeekFields.of(locale).getFirstDayOfWeek();
    private YearMonth month;
    private final JButton previous = Ui.button("‹", false, () -> showMonth(month.minusMonths(1)));
    private final JButton next = Ui.button("›", false, () -> showMonth(month.plusMonths(1)));

    CalendarPicker(YearMonth initialMonth, LocalDate selected, Consumer<LocalDate> choose) {
        super(new BorderLayout(0, 8));
        this.selected = selected;
        this.choose = choose;
        setBorder(new EmptyBorder(12, 12, 12, 12));
        JPanel navigation = Ui.transparent(new BorderLayout(8, 0));
        heading.setHorizontalAlignment(SwingConstants.CENTER);
        previous.setToolTipText("Previous month");
        previous.getAccessibleContext().setAccessibleName("Previous month");
        next.setToolTipText("Next month");
        next.getAccessibleContext().setAccessibleName("Next month");
        navigation.add(previous, BorderLayout.WEST);
        navigation.add(heading, BorderLayout.CENTER);
        navigation.add(next, BorderLayout.EAST);
        add(navigation, BorderLayout.NORTH);

        JPanel weekdays = Ui.transparent(new GridLayout(1, 7, 3, 0));
        for (int i = 0; i < 7; i++) {
            JLabel label = Ui.label(firstDay.plus(i).getDisplayName(TextStyle.SHORT, locale), 12, true, Ui.MUTED);
            label.setHorizontalAlignment(SwingConstants.CENTER);
            weekdays.add(label);
        }
        JPanel grid = Ui.transparent(new BorderLayout(0, 4));
        grid.add(weekdays, BorderLayout.NORTH);
        grid.add(days, BorderLayout.CENTER);
        add(grid, BorderLayout.CENTER);
        showMonth(initialMonth);
    }

    private void showMonth(YearMonth value) {
        month = value;
        heading.setText(month.format(DateTimeFormatter.ofPattern("MMMM uuuu", locale)));
        previous.setEnabled(!month.equals(YearMonth.of(ValidationUtil.MIN_YEAR, 1)));
        next.setEnabled(!month.equals(YearMonth.of(ValidationUtil.MAX_YEAR, 12)));
        days.removeAll();
        int offset = Math.floorMod(month.atDay(1).getDayOfWeek().getValue() - firstDay.getValue(), 7);
        for (int cell = 0; cell < 42; cell++) {
            int day = cell - offset + 1;
            if (day < 1 || day > month.lengthOfMonth()) {
                days.add(new JLabel());
            } else {
                LocalDate date = month.atDay(day);
                JButton button = Ui.button(Integer.toString(day), date.equals(selected), () -> choose.accept(date));
                button.putClientProperty("JComponent.minimumWidth", 0);
                button.setMargin(new Insets(5, 7, 5, 7));
                button.getAccessibleContext().setAccessibleName(date.toString());
                days.add(button);
            }
        }
        days.revalidate();
        days.repaint();
    }

    static JTextField addField(JPanel form, String name, LocalDate value) {
        return addField(form, name, value, YearMonth.from(value));
    }

    static JTextField addField(JPanel form, String name, LocalDate value, YearMonth fallbackMonth) {
        JTextField field = Ui.field(15, "YYYY-MM-DD");
        if (value != null) field.setText(value.toString());
        field.getAccessibleContext().setAccessibleName(name);
        field.setToolTipText("YYYY-MM-DD");
        JButton open = Ui.button("Calendar", false, () -> show(field, fallbackMonth, name));
        open.setIcon(Symbol.CALENDAR.icon(Ui.LAVENDER, 16));
        open.getAccessibleContext().setAccessibleName("Choose " + name.toLowerCase(Locale.ROOT));
        JPanel row = Ui.transparent(new BorderLayout(8, 0));
        row.add(field);
        row.add(open, BorderLayout.EAST);
        Ui.stack(form, Ui.fieldLabel(name, field), 7);
        Ui.stack(form, row, 12);
        return field;
    }

    private static void show(JTextField field, YearMonth fallbackMonth, String name) {
        LocalDate selected = null;
        try {
            selected = ValidationUtil.date(field.getText(), name);
        } catch (IllegalArgumentException ignored) {
            // An empty or partially typed date can still be completed using the calendar.
        }
        JDialog dialog = new JDialog(SwingUtilities.getWindowAncestor(field), "Choose " + name.toLowerCase(Locale.ROOT),
                Dialog.ModalityType.DOCUMENT_MODAL);
        dialog.setContentPane(new CalendarPicker(selected == null ? fallbackMonth : YearMonth.from(selected),
                selected, date -> {
                    field.setText(date.toString());
                    dialog.dispose();
                }));
        dialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        dialog.getRootPane().registerKeyboardAction(event -> dialog.dispose(),
                KeyStroke.getKeyStroke("ESCAPE"), JComponent.WHEN_IN_FOCUSED_WINDOW);
        dialog.setResizable(false);
        dialog.pack();
        dialog.setLocationRelativeTo(field);
        dialog.setVisible(true);
    }
}
