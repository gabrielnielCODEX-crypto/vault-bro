package com.vaultbro.ui;

import com.vaultbro.model.*;
import com.vaultbro.service.FinancialCalculationService;
import com.vaultbro.service.FinancialCalculationService.Totals;
import com.vaultbro.util.Ui;
import java.awt.*;
import java.sql.SQLException;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;
import java.util.function.Supplier;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

final class DashboardPanel extends JPanel implements MainFrame.View {
    private static final DateTimeFormatter ACTIVITY_DATE = DateTimeFormatter.ofPattern("MMM d, uuuu", Locale.ENGLISH);
    private final FinancialCalculationService calculations;
    private final Consumer<MainFrame.Page> navigate;
    private final Consumer<Transaction.Type> addTransaction;
    private final Supplier<List<MainFrame.Alert>> alerts;
    private final JPanel content = Ui.column();

    DashboardPanel(FinancialCalculationService calculations, Consumer<MainFrame.Page> navigate,
                   Consumer<Transaction.Type> addTransaction, Supplier<List<MainFrame.Alert>> alerts) {
        super(new BorderLayout());
        this.calculations = calculations;
        this.navigate = navigate;
        this.addTransaction = addTransaction;
        this.alerts = alerts;
        add(Ui.page(content));
    }

    @Override public void refresh() throws SQLException {
        YearMonth month = YearMonth.now();
        var report = calculations.report(DateRange.ALL);
        List<Transaction> monthlyTransactions = report.transactions().stream()
                .filter(transaction -> YearMonth.from(transaction.getDate()).equals(month)).toList();
        var monthly = FinancialCalculationService.totals(monthlyTransactions, report.goals());
        var history = FinancialCalculationService.trailingMonths(report.months(), month, 6);
        List<BudgetUsage> current = report.budgets().stream()
                .filter(usage -> usage.budget().period().equals(month)).toList();

        content.removeAll();
        Ui.stack(content, balanceOverview(report.totals()), 16);
        Ui.stack(content, pair(recent(report.transactions()), budgetUsage(current, month)), 16);
        Ui.stack(content, pair(
                chartCard("Income vs expenses", "Last 6 months", FinanceCharts.cashFlow(history)),
                chartCard("Expense distribution", "This month",
                        FinanceCharts.distribution(FinancialCalculationService.expenseCategories(monthlyTransactions)))), 16);

        long remaining = report.goals().stream().mapToLong(goal -> Math.max(0, goal.remaining())).sum();
        long towardTargets = report.goals().stream().mapToLong(goal -> Math.min(goal.savedAmount(), goal.targetAmount())).sum();
        String savingsScope = report.goals().isEmpty() ? null
                : FinanceTables.percent(100.0 * towardTargets / (towardTargets + remaining)) + " of goal targets saved";
        Ui.stack(content, pair(chartCard("Monthly expense trend", "Last 6 months", FinanceCharts.trend(history)),
                chartCard("Savings goals progress", savingsScope,
                        FinanceCharts.saved(towardTargets, remaining, !report.goals().isEmpty()))), 16);
        Ui.stack(content, pair(monthlySummary(monthly, monthlyTransactions.size()), alertCard()), 0);
        content.revalidate();
        content.repaint();
    }

    private static JPanel pair(JComponent first, JComponent second) {
        JPanel row = Ui.transparent(new GridLayout(1, 2, 14, 0));
        row.add(first);
        row.add(second);
        return row;
    }

    private JPanel balanceOverview(Totals totals) {
        JPanel card = Ui.card(new BorderLayout(0, 18), 20, Ui.color(0x332846), Ui.color(0x202234), Ui.color(0x514465));
        JPanel header = Ui.transparent(new BorderLayout(16, 0));
        JPanel balance = Ui.column();
        JLabel title = Ui.label("Remaining balance  ·  All time", 13, true, Ui.TEXT);
        title.setIcon(Symbol.WALLET.icon(Ui.LAVENDER, 18));
        title.setIconTextGap(8);
        Ui.stack(balance, title, 7);
        JLabel amount = Ui.label(Money.format(totals.balance()), 34, true, totals.balance() < 0 ? Ui.RED : Ui.TEXT);
        amount.setToolTipText(amount.getText());
        Ui.stack(balance, amount, 0);
        header.add(balance);
        JButton income = Ui.button("Add income", false, () -> addTransaction.accept(Transaction.Type.INCOME));
        income.setIcon(Symbol.INCOME.icon(Ui.GREEN, 16));
        JButton expense = Ui.button("Add expense", true, () -> addTransaction.accept(Transaction.Type.EXPENSE));
        expense.setIcon(Symbol.PLUS.icon(Color.WHITE, 15));
        JPanel actions = Ui.transparent(new GridBagLayout());
        actions.add(Ui.actions(income, expense));
        header.add(actions, BorderLayout.EAST);
        card.add(header, BorderLayout.NORTH);

        JPanel figures = Ui.transparent(new GridLayout(1, 3, 14, 0));
        figures.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1, 0, 0, 0, Ui.color(0x4C435B)), new EmptyBorder(13, 0, 0, 0)));
        figures.add(metric("Total income", totals.income(), Symbol.INCOME, Ui.GREEN));
        figures.add(metric("Total expenses", totals.expenses(), Symbol.EXPENSE, Ui.RED));
        figures.add(metric("Total savings", totals.savings(), Symbol.SAVINGS, Ui.CYAN));
        card.add(figures);
        return card;
    }

    static JPanel stats(Totals totals) {
        JPanel cards = Ui.transparent(new GridLayout(1, 4, 12, 0));
        cards.add(metricCard("Remaining balance", totals.balance(), Symbol.WALLET, Ui.LAVENDER));
        cards.add(metricCard("Total income", totals.income(), Symbol.INCOME, Ui.GREEN));
        cards.add(metricCard("Total expenses", totals.expenses(), Symbol.EXPENSE, Ui.RED));
        cards.add(metricCard("Total savings", totals.savings(), Symbol.SAVINGS, Ui.CYAN));
        return cards;
    }

    private static JPanel metricCard(String name, long amount, Symbol icon, Color color) {
        JPanel card = Ui.card(new BorderLayout(), 14);
        card.add(metric(name, amount, icon, color));
        return card;
    }

    private static JPanel metric(String name, long amount, Symbol symbol, Color color) {
        JPanel column = Ui.column();
        JLabel title = Ui.label(name, 12, false, Ui.MUTED);
        title.setIcon(symbol.icon(color, 15));
        title.setIconTextGap(6);
        Ui.stack(column, title, 4);
        JLabel value = Ui.label(Money.format(amount), 20, true, Ui.TEXT);
        value.setToolTipText(value.getText());
        Ui.stack(column, value, 0);
        return column;
    }

    static JPanel chartCard(String title, String description, JComponent chart) {
        chart.getAccessibleContext().setAccessibleName(title);
        JPanel card = Ui.card(new BorderLayout(0, 10), 16);
        JPanel heading = Ui.column();
        Ui.stack(heading, Ui.label(title, 17, true, Ui.TEXT), description == null ? 0 : 4);
        if (description != null) Ui.stack(heading, Ui.label(description, 12, false, Ui.MUTED), 0);
        card.add(heading, BorderLayout.NORTH);
        card.add(chart);
        return card;
    }

    private JPanel listCard(String title, MainFrame.Page page, JComponent rows) {
        JPanel card = Ui.card(new BorderLayout(0, 10), 16);
        JPanel header = Ui.transparent(new BorderLayout(6, 0));
        header.add(Ui.label(title, 17, true, Ui.TEXT));
        JButton view = Ui.textButton("View all", () -> navigate.accept(page));
        view.getAccessibleContext().setAccessibleName("View all " + page.label.toLowerCase(Locale.ROOT));
        header.add(view, BorderLayout.EAST);
        card.add(header, BorderLayout.NORTH);
        JPanel body = Ui.transparent(new BorderLayout());
        body.add(rows, BorderLayout.NORTH);
        card.add(body);
        return card;
    }

    private JPanel recent(List<Transaction> transactions) {
        JPanel rows = Ui.column();
        for (Transaction record : transactions.stream().limit(5).toList()) {
            boolean income = record.getType() == Transaction.Type.INCOME;
            Color color = income ? Ui.GREEN : Ui.RED;
            JPanel row = Ui.transparent(new BorderLayout(10, 0));
            JLabel icon = new JLabel((income ? Symbol.INCOME : Symbol.EXPENSE).icon(color, 18));
            row.add(icon, BorderLayout.WEST);
            JPanel copy = Ui.column();
            JLabel name = Ui.label(FinanceTables.description(record), 13, true, Ui.TEXT);
            name.setToolTipText(name.getText());
            Ui.stack(copy, name, 3);
            Ui.stack(copy, Ui.label(record.getCategory() + "  ·  " + record.getDate().format(ACTIVITY_DATE),
                    12, false, Ui.MUTED), 0);
            row.add(copy);
            String value = (income ? "+" : "") + Money.format(record.getSignedAmount());
            row.add(Ui.label(value, 14, true, color), BorderLayout.EAST);
            addListRow(rows, row);
        }
        if (transactions.isEmpty()) addEmptyRow(rows, "No transactions yet", "Use Add income or Add expense to record your first entry.");
        return listCard("Recent transactions", MainFrame.Page.TRANSACTIONS, rows);
    }

    private JPanel budgetUsage(List<BudgetUsage> current, YearMonth month) {
        JPanel rows = Ui.column();
        for (BudgetUsage usage : current) {
            Budget budget = usage.budget();
            Color color = FinanceTables.budgetColor(usage.status());
            JPanel row = Ui.column();
            Ui.stack(row, labelValue(budget.category(), usage.status().toString(), color), 6);
            Ui.stack(row, Ui.progress(usage.percent(), color), 5);
            Ui.stack(row, labelValue(Money.format(usage.spent()) + " of " + Money.format(budget.monthlyLimit()),
                    FinanceTables.percent(usage.percent()), Ui.TEXT), 0);
            addListRow(rows, row);
        }
        if (current.isEmpty()) addEmptyRow(rows, "No budgets this month", "Create a budget to track spending against a limit.");
        String title = month.format(DateTimeFormatter.ofPattern("MMMM", Locale.ENGLISH)) + " budgets";
        if (current.size() > 3) {
            JScrollPane scroll = Ui.scroll(rows);
            scroll.setOpaque(false);
            scroll.getViewport().setOpaque(false);
            scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
            int height = 0;
            for (int i = 0; i < 3; i++) height += rows.getComponent(i).getPreferredSize().height;
            scroll.setPreferredSize(new Dimension(240, height));
            return listCard(title, MainFrame.Page.BUDGETS, scroll);
        }
        return listCard(title, MainFrame.Page.BUDGETS, rows);
    }

    private static void addListRow(JPanel rows, JPanel row) {
        int top = rows.getComponentCount() == 0 ? 0 : 1;
        row.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createMatteBorder(top, 0, 0, 0, Ui.BORDER),
                new EmptyBorder(8, 0, 8, 0)));
        Ui.stack(rows, row, 0);
    }

    private static void addEmptyRow(JPanel rows, String title, String detail) {
        Ui.stack(rows, Ui.label(title, 14, true, Ui.TEXT), 5);
        JTextArea message = new JTextArea(detail);
        message.setEditable(false);
        message.setFocusable(false);
        message.setOpaque(false);
        message.setLineWrap(true);
        message.setWrapStyleWord(true);
        message.setRows(2);
        message.setFont(UIManager.getFont("Label.font").deriveFont(13f));
        message.setForeground(Ui.MUTED);
        Ui.stack(rows, message, 0);
    }

    private JPanel monthlySummary(Totals monthly, int count) {
        JPanel details = Ui.column();
        Ui.stack(details, labelValue("Income", Money.format(monthly.income()), Ui.GREEN), 10);
        Ui.stack(details, labelValue("Expenses", Money.format(monthly.expenses()), Ui.RED), 10);
        Ui.stack(details, labelValue("Net balance", Money.format(monthly.balance()), Ui.TEXT), 0);
        return chartCard("Monthly summary", count + (count == 1 ? " transaction this month" : " transactions this month"), details);
    }

    private JPanel alertCard() {
        JPanel messages = Ui.column();
        List<MainFrame.Alert> active = alerts.get();
        if (active.isEmpty()) Ui.stack(messages, Ui.label("No active alerts.", 13, false, Ui.MUTED), 0);
        for (MainFrame.Alert alert : active.stream().limit(5).toList()) {
            JButton button = Ui.textButton(alert.title(), () -> navigate.accept(alert.page()));
            button.setForeground(alert.color());
            button.setHorizontalAlignment(SwingConstants.LEFT);
            button.setToolTipText(alert.detail());
            Ui.stack(messages, button, 5);
        }
        return chartCard("Financial alerts", null, messages);
    }

    private static JPanel labelValue(String label, String value, Color color) {
        JPanel row = Ui.transparent(new BorderLayout(6, 0));
        row.add(Ui.label(label, 13, false, Ui.MUTED));
        row.add(Ui.label(value, 13, true, color), BorderLayout.EAST);
        return row;
    }
}
