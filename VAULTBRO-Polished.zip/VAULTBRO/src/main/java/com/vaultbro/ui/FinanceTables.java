package com.vaultbro.ui;

import com.vaultbro.model.*;
import com.vaultbro.util.Ui;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

final class FinanceTables {
    private FinanceTables() {}

    static void bindRowActions(JTable table, JButton details, JButton edit, JButton delete) {
        JButton[] actions = {details, edit, delete};
        for (JButton action : actions) action.setEnabled(false);
        table.getSelectionModel().addListSelectionListener(event -> {
            boolean selected = table.getSelectedRow() >= 0;
            for (JButton action : actions) action.setEnabled(selected);
        });
        table.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent event) {
                if (SwingUtilities.isLeftMouseButton(event) && event.getClickCount() == 2
                        && table.rowAtPoint(event.getPoint()) >= 0) details.doClick(0);
            }
        });
        table.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(KeyStroke.getKeyStroke("ENTER"), "openDetails");
        table.getActionMap().put("openDetails", new AbstractAction() {
            @Override public void actionPerformed(ActionEvent event) {
                if (details.isEnabled()) details.doClick(0);
            }
        });
        details.setToolTipText("Open the selected row (Enter or double-click)");
    }

    static final class Transactions {
        final DefaultTableModel model;
        final JTable table;

        Transactions() {
            String[] columns = {"ID", "Date", "Description", "Category", "Type", "Amount"};
            Class<?>[] types = {Long.class, LocalDate.class, String.class, String.class, String.class, Long.class};
            model = Ui.tableModel(columns, types);
            table = Ui.table(model);
            table.getColumnModel().getColumn(0).setMaxWidth(59);
            table.getColumnModel().getColumn(1).setMinWidth(102);
            table.getColumnModel().getColumn(2).setPreferredWidth(270);
            sizeCategoryColumn(table, 3);
            table.getColumnModel().getColumn(4).setMinWidth(table.getFontMetrics(table.getFont()).stringWidth("Expense") + 22);
            amount(table, columns.length - 1, true, true);
        }

        void set(List<Transaction> transactions) {
            model.setRowCount(0);
            for (Transaction record : transactions) {
                model.addRow(new Object[]{record.getId(), record.getDate(), description(record), record.getCategory(),
                        record.getType().toString(), record.getSignedAmount()});
            }
        }
    }

    static String description(Transaction record) {
        return record.getDescription().replaceAll("\\h*\\R\\h*", " ");
    }

    static void money(JTable table, int column, boolean signed) {
        amount(table, column, signed, false);
    }

    private static void amount(JTable table, int column, boolean signed, boolean showPlus) {
        var amountColumn = table.getColumnModel().getColumn(column);
        var metrics = table.getFontMetrics(table.getFont());
        amountColumn.setMinWidth(metrics.stringWidth(signed ? "+₱99,999.99" : "₱99,999.99") + 20);
        amountColumn.setPreferredWidth(metrics.stringWidth(signed ? "+₱999,999,999.99" : "₱999,999,999.99") + 20);
        amountColumn.setCellRenderer(new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable source, Object value,
                    boolean selected, boolean focus, int row, int viewColumn) {
                long cents = value instanceof Number number ? number.longValue() : 0;
                super.getTableCellRendererComponent(source, (showPlus && cents > 0 ? "+" : "") + Money.format(cents),
                        selected, focus, row, viewColumn);
                setHorizontalAlignment(SwingConstants.RIGHT);
                setToolTipText(getText());
                setBorder(new EmptyBorder(0, 8, 0, 10));
                if (signed) setForeground(cents < 0 ? Ui.RED : Ui.GREEN);
                return this;
            }
        });
    }

    static Color budgetColor(BudgetUsage.Status status) {
        return switch (status) {
            case ON_TRACK -> Ui.GREEN;
            case NEAR_LIMIT -> Ui.AMBER;
            case OVER_BUDGET -> Ui.RED;
        };
    }

    static Color goalColor(SavingsGoal.Status status) {
        return switch (status) {
            case IN_PROGRESS -> Ui.CYAN;
            case ACHIEVED -> Ui.GREEN;
            case OVERDUE -> Ui.RED;
        };
    }

    static TableCellRenderer progressRenderer(java.util.function.DoubleFunction<Color> colorFor) {
        JPanel panel = new JPanel(new java.awt.BorderLayout(6, 0));
        panel.setBorder(new EmptyBorder(0, 8, 0, 8));
        JPanel track = Ui.transparent(new java.awt.GridBagLayout());
        JProgressBar bar = Ui.progress(0, Ui.ACCENT);
        bar.setPreferredSize(new Dimension(35, 7));
        java.awt.GridBagConstraints fill = new java.awt.GridBagConstraints();
        fill.weightx = 1;
        fill.fill = java.awt.GridBagConstraints.HORIZONTAL;
        track.add(bar, fill);
        JLabel valueLabel = Ui.label("", 11, true, Ui.TEXT);
        panel.add(track);
        panel.add(valueLabel, java.awt.BorderLayout.EAST);
        return (table, value, selected, focus, row, column) -> {
            double percent = (double) value;
            Color color = colorFor.apply(percent);
            panel.setBackground(rowBackground(table, selected, row));
            bar.setForeground(color);
            bar.setValue((int) Math.round(Math.max(0, Math.min(100, percent))));
            String text = percent(percent);
            valueLabel.setText(text);
            valueLabel.setForeground(color);
            panel.getAccessibleContext().setAccessibleName(text);
            return panel;
        };
    }

    static TableCellRenderer statusBadge(java.util.function.Function<Object, Color> colorFor) {
        JPanel panel = new JPanel(new java.awt.GridBagLayout());
        JLabel badge = Ui.badge("", Ui.MUTED);
        panel.add(badge);
        return (table, value, selected, focus, row, column) -> {
            Color color = colorFor.apply(value);
            panel.setBackground(rowBackground(table, selected, row));
            badge.setText(value.toString());
            badge.setForeground(color);
            badge.setBackground(Ui.tint(color, .16));
            panel.getAccessibleContext().setAccessibleName(value.toString());
            return panel;
        };
    }

    private static Color rowBackground(JTable table, boolean selected, int row) {
        if (selected) return table.getSelectionBackground();
        Color alternate = UIManager.getColor("Table.alternateRowColor");
        return (row % 2 == 1 && alternate != null) ? alternate : table.getBackground();
    }

    static String percent(double value) {
        return String.format(java.util.Locale.ROOT, "%.1f%%", value);
    }

    static JScrollPane tableScroll(JTable table, int height) {
        JScrollPane scroll = Ui.scroll(table);
        scroll.setColumnHeaderView(table.getTableHeader());
        scroll.setPreferredSize(new Dimension(350, height));
        scroll.getViewport().setBackground(Ui.CARD);
        return scroll;
    }

    static JTable budgetTable(DefaultTableModel model) {
        JTable table = Ui.table(model);
        table.getColumnModel().getColumn(0).setMaxWidth(48);
        sizeCategoryColumn(table, 1);
        table.getColumnModel().getColumn(2).setMinWidth(108);
        for (int column = 3; column <= 5; column++) money(table, column, column == 5);
        table.getColumnModel().getColumn(6).setMinWidth(90);
        table.getColumnModel().getColumn(6).setPreferredWidth(125);
        table.getColumnModel().getColumn(6).setCellRenderer(progressRenderer(value ->
                value > 100 ? Ui.RED : value >= 80 ? Ui.AMBER : Ui.GREEN));
        table.getColumnModel().getColumn(7).setMinWidth(100);
        table.getColumnModel().getColumn(7).setCellRenderer(statusBadge(value -> budgetColor((BudgetUsage.Status) value)));
        return table;
    }

    private static void sizeCategoryColumn(JTable table, int column) {
        var metrics = table.getFontMetrics(table.getFont());
        int textWidth = Categories.EXPENSES.stream().mapToInt(metrics::stringWidth).max().orElse(80);
        var category = table.getColumnModel().getColumn(column);
        category.setMinWidth(textWidth + 20);
        category.setPreferredWidth(Math.max(140, textWidth + 20));
    }

    static DefaultTableModel budgetModel() {
        return Ui.tableModel(new String[]{"ID", "Category", "Budget date", "Limit", "Spent", "Remaining", "Usage", "Status"},
                new Class<?>[]{Long.class, String.class, String.class, Long.class, Long.class, Long.class,
                        Double.class, BudgetUsage.Status.class});
    }

    static void budgetRows(DefaultTableModel model, List<BudgetUsage> budgets) {
        model.setRowCount(0);
        for (BudgetUsage usage : budgets) {
            Budget budget = usage.budget();
            model.addRow(new Object[]{budget.id(), budget.category(), budget.dateLabel(), budget.monthlyLimit(),
                    usage.spent(), usage.remaining(), usage.percent(), usage.status()});
        }
    }

    static JTextArea notes(String value, int rows) {
        JTextArea area = new JTextArea(value, rows, 24);
        area.putClientProperty("html.disable", true);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setMargin(new java.awt.Insets(6, 8, 6, 8));
        return area;
    }
}
