package com.vaultbro.ui;

import com.vaultbro.controller.AuthService;
import com.vaultbro.model.User;
import com.vaultbro.util.Ui;
import java.util.Arrays;
import java.util.function.Consumer;
import javax.swing.*;

final class LoginFrame extends JFrame {
    LoginFrame(AuthService auth, Consumer<User> onLogin) {
        super("VAULTBRO · Sign In");
        JPanel form = Ui.column();
        JTextField login = Ui.field(24, "Username or email");
        JPasswordField password = Ui.password(24, "Your password");
        Ui.stack(form, Ui.label("Sign in", 32, true, Ui.TEXT), 24);
        Ui.fieldRow(form, "Username or email", login);
        Ui.fieldRow(form, "Password", password);
        JButton submit = Ui.button("Sign in", true, null);
        JButton register = Ui.button("Create an account", false, () -> {
            var screen = new RegisterFrame(auth, () -> {
                var back = new LoginFrame(auth, onLogin);
                back.setVisible(true);
            });
            screen.setVisible(true);
            dispose();
        });
        submit.addActionListener(event -> {
            String identifier = login.getText();
            char[] secret = password.getPassword();
            password.setText("");
            Ui.background(this, submit, () -> {
                try {
                    return auth.authenticate(identifier, secret);
                } finally {
                    Arrays.fill(secret, '\0');
                }
            }, user -> {
                onLogin.accept(user);
                dispose();
            });
        });
        submit.addPropertyChangeListener("enabled", event -> {
            register.setEnabled(submit.isEnabled());
            submit.setText(submit.isEnabled() ? "Sign in" : "Signing in…");
        });
        Ui.stack(form, submit, 13);
        Ui.stack(form, register, 0);
        AuthLayout.install(this, form);
        getRootPane().setDefaultButton(submit);
    }
}
