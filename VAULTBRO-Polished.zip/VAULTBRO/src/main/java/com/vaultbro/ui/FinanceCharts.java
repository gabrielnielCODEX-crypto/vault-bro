package com.vaultbro.ui;

import com.vaultbro.model.BudgetUsage;
import com.vaultbro.service.FinancialCalculationService.MonthSummary;
import com.vaultbro.util.Ui;
import java.awt.*;
import java.text.DecimalFormat;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.swing.*;
import org.jfree.chart.*;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.plot.RingPlot;
import org.jfree.chart.plot.ValueMarker;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.chart.renderer.category.StandardBarPainter;
import org.jfree.chart.ui.RectangleEdge;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;

final class FinanceCharts {
    private static final Color[] PALETTE = {Ui.color(0x9562F2), Ui.CYAN, Ui.GREEN, Ui.AMBER, Ui.RED,
            Ui.color(0x7286EF), Ui.color(0xE29DE9), Ui.color(0x4BA7AD)};

    private static final Color SPENDING = Ui.RED;
    private static final DateTimeFormatter MONTH_LABEL = DateTimeFormatter.ofPattern("MMM yy", Locale.ENGLISH);
    private static final int CHART_HEIGHT = 201;

    private FinanceCharts() {}

    static JComponent cashFlow(List<MonthSummary> months) {
        if (months.stream().noneMatch(month -> month.income() > 0 || month.expenses() > 0)) {
            return empty("No income or expenses for this period.");
        }
        DefaultCategoryDataset data = new DefaultCategoryDataset();
        for (MonthSummary month : months) {
            String label = month.month().format(MONTH_LABEL);
            data.addValue(month.income() / 100.0, "Income", label);
            data.addValue(month.expenses() / 100.0, "Expenses", label);
        }
        JFreeChart chart = ChartFactory.createBarChart(null, null, null, data,
                PlotOrientation.VERTICAL, true, true, false);
        CategoryPlot plot = prepare(chart);
        BarRenderer renderer = (BarRenderer) plot.getRenderer();
        renderer.setSeriesPaint(0, Ui.GREEN);
        renderer.setSeriesPaint(1, SPENDING);
        renderer.setBarPainter(new StandardBarPainter());
        renderer.setShadowVisible(false);
        renderer.setMaximumBarWidth(.06);
        renderer.setItemMargin(.12);
        return panel(chart, CHART_HEIGHT);
    }

    static JComponent trend(List<MonthSummary> months) {
        if (months.stream().noneMatch(month -> month.expenses() > 0)) {
            return empty("No expenses for this period.");
        }
        DefaultCategoryDataset data = new DefaultCategoryDataset();
        for (MonthSummary month : months) {
            String label = month.month().format(MONTH_LABEL);
            data.addValue(month.expenses() / 100.0, "Expenses", label);
        }
        JFreeChart chart = ChartFactory.createLineChart(null, null, null, data,
                PlotOrientation.VERTICAL, false, true, false);
        CategoryPlot plot = prepare(chart);
        LineAndShapeRenderer renderer = (LineAndShapeRenderer) plot.getRenderer();
        renderer.setSeriesPaint(0, SPENDING);
        renderer.setSeriesStroke(0, new BasicStroke(2.6f));
        renderer.setDefaultShapesVisible(true);
        renderer.setDefaultShape(new java.awt.geom.Ellipse2D.Double(-3, -3, 6, 6));
        return panel(chart, CHART_HEIGHT);
    }

    static JComponent distribution(Map<String, Long> categories) {
        if (categories.isEmpty()) return empty("No expenses recorded for this period.");
        DefaultPieDataset<String> data = new DefaultPieDataset<>();
        categories.forEach((category, amount) -> data.setValue(category, amount / 100.0));
        JFreeChart chart = ChartFactory.createRingChart(null, data, true, true, false);
        stylePie(chart, data, PALETTE);
        RingPlot plot = (RingPlot) chart.getPlot();
        plot.setSeparatorsVisible(false);
        plot.setSectionDepth(.35);
        return panel(chart, CHART_HEIGHT);
    }

    static JComponent saved(long saved, long remaining, boolean hasGoals) {
        if (!hasGoals) return empty("No savings goals yet.");
        DefaultPieDataset<String> data = new DefaultPieDataset<>();
        data.setValue("Saved", saved / 100.0);
        data.setValue("Remaining", remaining / 100.0);
        JFreeChart chart = ChartFactory.createRingChart(null, data, true, true, false);
        stylePie(chart, data, new Color[]{Ui.CYAN, Ui.CONTROL});
        RingPlot plot = (RingPlot) chart.getPlot();
        plot.setSeparatorsVisible(false);
        plot.setSectionDepth(.31);
        return panel(chart, CHART_HEIGHT);
    }

    static JComponent budgetUtilization(List<BudgetUsage> budgets) {
        if (budgets.isEmpty()) return empty("No budgets overlap the selected dates.");
        DefaultCategoryDataset data = new DefaultCategoryDataset();
        for (BudgetUsage usage : budgets) {
            String label = usage.budget().category() + " · " + usage.budget().period().format(MONTH_LABEL);
            data.addValue(usage.percent(), "Used", label);
        }
        JFreeChart chart = ChartFactory.createBarChart(null, null, null, data,
                PlotOrientation.HORIZONTAL, false, true, false);
        CategoryPlot plot = prepare(chart);
        NumberAxis axis = (NumberAxis) plot.getRangeAxis();
        axis.setNumberFormatOverride(new DecimalFormat("0'%'"));
        double maxUsed = budgets.stream().mapToDouble(BudgetUsage::percent).max().orElse(0);
        axis.setRange(0, Math.max(110, maxUsed * 1.07));
        BarRenderer renderer = new BarRenderer() {
            @Override public Paint getItemPaint(int row, int column) {
                return FinanceTables.budgetColor(budgets.get(column).status());
            }
        };
        renderer.setBarPainter(new StandardBarPainter());
        renderer.setShadowVisible(false);
        renderer.setMaximumBarWidth(.12);
        renderer.setDefaultToolTipGenerator((dataset, row, col) -> dataset.getColumnKey(col)
                + " · " + FinanceTables.percent(dataset.getValue(row, col).doubleValue()));
        plot.setRenderer(renderer);
        plot.addRangeMarker(new ValueMarker(100, Ui.MUTED, new BasicStroke(1f, BasicStroke.CAP_BUTT,
                BasicStroke.JOIN_MITER, 1f, new float[]{4f, 4f}, 0f)));
        return panel(chart, CHART_HEIGHT);
    }

    private static void stylePie(JFreeChart chart, DefaultPieDataset<String> data, Color[] colors) {
        base(chart);
        PiePlot plot = (PiePlot) chart.getPlot();
        plot.setBackgroundPaint(Ui.CARD);
        plot.setOutlineVisible(false);
        plot.setShadowPaint(null);
        plot.setSectionOutlinesVisible(false);
        plot.setLabelGenerator(null);
        plot.setIgnoreZeroValues(false);
        for (int index = 0; index < data.getItemCount(); index++) {
            plot.setSectionPaint(data.getKey(index), colors[index % colors.length]);
        }
    }

    private static CategoryPlot prepare(JFreeChart chart) {
        base(chart);
        CategoryPlot plot = chart.getCategoryPlot();
        plot.setBackgroundPaint(Ui.CARD);
        plot.setOutlineVisible(false);
        plot.setRangeGridlinePaint(Ui.BORDER);
        plot.getDomainAxis().setTickLabelPaint(Ui.MUTED);
        plot.getDomainAxis().setAxisLinePaint(Ui.BORDER);
        plot.getDomainAxis().setTickMarksVisible(false);
        if (plot.getOrientation() == PlotOrientation.VERTICAL && plot.getDataset().getColumnCount() > 6) {
            plot.getDomainAxis().setCategoryLabelPositions(CategoryLabelPositions.UP_45);
        }
        NumberAxis axis = (NumberAxis) plot.getRangeAxis();
        axis.setTickLabelPaint(Ui.MUTED);
        axis.setAxisLineVisible(false);
        axis.setTickMarksVisible(false);
        axis.setNumberFormatOverride(new DecimalFormat("₱#,##0.##"));
        return plot;
    }

    private static void base(JFreeChart chart) {
        chart.setBackgroundPaint(Ui.CARD);
        chart.setAntiAlias(true);
        if (chart.getLegend() != null) {
            chart.getLegend().setBackgroundPaint(Ui.CARD);
            chart.getLegend().setItemPaint(Ui.MUTED);
            chart.getLegend().setPosition(RectangleEdge.BOTTOM);
        }
    }

    private static ChartPanel panel(JFreeChart chart, int height) {
        ChartPanel panel = new ChartPanel(chart, false);
        panel.setMinimumDrawWidth(100);
        panel.setMinimumDrawHeight(100);
        panel.setPreferredSize(new Dimension(250, height));
        panel.setOpaque(false);
        return panel;
    }

    private static JPanel empty(String message) {
        JPanel panel = Ui.transparent(new GridBagLayout());
        panel.add(Ui.label(message, 13, false, Ui.MUTED));
        panel.setPreferredSize(new Dimension(250, 72));
        return panel;
    }
}
