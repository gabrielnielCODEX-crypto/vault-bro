package com.vaultbro.ui;

import com.vaultbro.controller.FinanceController;
import com.vaultbro.model.*;
import com.vaultbro.service.FinancialCalculationService;
import com.vaultbro.service.ReportExporter;
import com.vaultbro.util.Ui;
import java.awt.*;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

final class TransactionPanel extends JPanel implements MainFrame.View {
    private final MainFrame owner;
    private final FinanceController finance;
    private String search = "";
    private final JComboBox<String> type = new JComboBox<>(new String[]{"All types", "Income", "Expense"});
    private final JComboBox<String> category = new JComboBox<>();
    private final FinanceTables.Transactions records = new FinanceTables.Transactions();
    private final JLabel count = Ui.label("", 13, true, Ui.MUTED);
    private final JLabel totals = Ui.label("", 12, false, Ui.MUTED);
    private final JLabel emptyMessage = Ui.label("", 14, false, Ui.MUTED);
    private final CardLayout recordCards = new CardLayout();
    private final JPanel tableBody = Ui.transparent(recordCards);
    private final DateFilter dates;
    private final JButton export = Ui.button("Export CSV", false, this::exportTransactions);
    private List<Transaction> inRange = List.of();
    private List<Transaction> visible = List.of();
    private DateRange range = DateRange.ALL;
    private boolean updatingFilters;

    TransactionPanel(MainFrame owner, FinanceController finance) {
        super(new BorderLayout(0, 14));
        this.owner = owner;
        this.finance = finance;
        setBorder(new EmptyBorder(18, 27, 22, 27));

        JButton income = Ui.tintedButton("Add income", Ui.GREEN,
                () -> TransactionDialog.show(owner, finance, null, Transaction.Type.INCOME));
        JButton expense = Ui.tintedButton("Add expense", Ui.RED,
                () -> TransactionDialog.show(owner, finance, null, Transaction.Type.EXPENSE));
        income.setIcon(Symbol.PLUS.icon(Ui.GREEN, 14));
        expense.setIcon(Symbol.PLUS.icon(Ui.RED, 14));
        JButton details = Ui.button("Details", false, () -> TransactionDialog.details(owner, selected()));
        JButton edit = Ui.button("Edit", false, () -> TransactionDialog.show(owner, finance, selected(), null));
        JButton delete = Ui.tintedButton("Delete", Ui.RED, this::delete);
        export.setIcon(Symbol.EXPORT.icon(Ui.MUTED, 15));
        FinanceTables.bindRowActions(records.table, details, edit, delete);

        JPanel tools = Ui.card(new GridLayout(0, 1, 0, 7), 12);
        JPanel actions = Ui.transparent(new FlowLayout(FlowLayout.LEFT, 7, 0));
        for (JButton action : new JButton[]{income, expense, details, edit, delete, export}) actions.add(action);
        tools.add(actions);
        JPanel choices = Ui.transparent(new FlowLayout(FlowLayout.LEFT, 7, 0));
        choices.add(Ui.fieldLabel("Type", type));
        choices.add(type);
        choices.add(Ui.fieldLabel("Category", category));
        choices.add(category);
        tools.add(choices);
        JPanel dateRow = Ui.transparent(new BorderLayout(6, 0));
        dates = new DateFilter(false, value -> {
            range = value;
            if (!updatingFilters) Ui.run(this, this::refresh);
        });
        dateRow.add(dates, BorderLayout.WEST);
        dateRow.add(Ui.actions(Ui.button("Reset filters", false, this::resetFilters)), BorderLayout.EAST);
        tools.add(dateRow);
        add(tools, BorderLayout.NORTH);

        JPanel card = Ui.card(new BorderLayout(0, 10), 12);
        tableBody.add(FinanceTables.tableScroll(records.table, 320), "table");
        JPanel blank = Ui.transparent(new GridBagLayout());
        emptyMessage.setIcon(Symbol.TRANSACTIONS.icon(Ui.LAVENDER, 22));
        emptyMessage.setIconTextGap(10);
        blank.add(emptyMessage);
        tableBody.add(blank, "empty");
        card.add(tableBody);
        JPanel footer = Ui.transparent(new BorderLayout(10, 0));
        footer.add(count, BorderLayout.WEST);
        footer.add(totals, BorderLayout.EAST);
        card.add(footer, BorderLayout.SOUTH);
        add(card);

        categories();
        type.addActionListener(event -> {
            if (updatingFilters) return;
            updatingFilters = true;
            try {
                categories();
            } finally {
                updatingFilters = false;
            }
            applyFilters();
        });
        category.addActionListener(event -> applyFilters());
    }

    @Override public void refresh() throws SQLException {
        inRange = finance.searchTransactions("", null, null, range);
        applyFilters();
    }

    @Override public void search(String text) {
        search = text;
        applyFilters();
    }

    private void applyFilters() {
        if (updatingFilters) return;
        String chosenCategory = category.getSelectedIndex() <= 0 ? null : (String) category.getSelectedItem();
        visible = FinanceController.filterTransactions(inRange, search, selectedType(), chosenCategory);
        records.set(visible);
        count.setText(visible.size() + (visible.size() == 1 ? " transaction" : " transactions"));
        var summary = FinancialCalculationService.totals(visible, List.of());
        totals.setText("Income  " + Money.format(summary.income()) + "     Expenses  " + Money.format(summary.expenses())
                + "     Net  " + Money.format(summary.balance()));
        boolean filtered = !search.isBlank() || selectedType() != null || chosenCategory != null || !range.equals(DateRange.ALL);
        emptyMessage.setText(filtered ? "No transactions match these filters." : "Add an income or expense to get started.");
        recordCards.show(tableBody, visible.isEmpty() ? "empty" : "table");
    }

    private void resetFilters() {
        updatingFilters = true;
        try {
            owner.clearSearch();
            type.setSelectedIndex(0);
            categories();
            dates.reset();
        } finally {
            updatingFilters = false;
        }
        Ui.run(this, this::refresh);
    }

    private Transaction.Type selectedType() {
        return switch (type.getSelectedIndex()) {
            case 1 -> Transaction.Type.INCOME;
            case 2 -> Transaction.Type.EXPENSE;
            default -> null;
        };
    }

    private void categories() {
        var options = new LinkedHashSet<String>();
        options.add("All categories");
        if (selectedType() != Transaction.Type.EXPENSE) options.addAll(Categories.INCOME);
        if (selectedType() != Transaction.Type.INCOME) options.addAll(Categories.EXPENSES);
        category.setModel(new DefaultComboBoxModel<>(options.toArray(String[]::new)));
    }

    private Transaction selected() {
        return visible.get(records.table.convertRowIndexToModel(records.table.getSelectedRow()));
    }

    private void exportTransactions() {
        List<Transaction> rows = new ArrayList<>(records.table.getRowCount());
        for (int row = 0; row < records.table.getRowCount(); row++) {
            rows.add(visible.get(records.table.convertRowIndexToModel(row)));
        }
        DateRange datesAtExport = range;
        ReportExportDialog.show(owner, export, ReportExporter.Format.TRANSACTIONS,
                path -> new ReportExporter().exportTransactions(path, datesAtExport, rows));
    }

    private void delete() {
        Transaction record = selected();
        if (Ui.confirm(owner, "Delete Transaction", "Permanently delete transaction #" + record.getId() + "?")) {
            Ui.run(this, () -> {
                finance.deleteTransaction(record.getId());
                owner.dataChanged();
            });
        }
    }
}
