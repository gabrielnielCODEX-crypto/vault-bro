package com.vaultbro.ui;

import com.vaultbro.model.Budget;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.Arrays;
import java.util.concurrent.atomic.AtomicInteger;
import javax.swing.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

final class EditingControlsTest {
    @Test void budgetEditorDistinguishesAnUnknownDayFromASavedDate() throws Exception {
        SwingUtilities.invokeAndWait(() -> {
            YearMonth month = YearMonth.of(2028, 2);
            Budget earlier = new Budget(1, "Overall", 10000, month);
            BudgetForm legacy = new BudgetForm(earlier, null);
            assertEquals("", budgetDate(legacy).getText());
            YearMonth otherMonth = YearMonth.now().plusMonths(1);
            assertEquals(otherMonth.atDay(1).toString(), budgetDate(new BudgetForm(null, otherMonth)).getText());
            Budget dated = new Budget(1, "Overall", 10000, month, LocalDate.of(2028, 2, 29));
            assertEquals("2028-02-29", budgetDate(new BudgetForm(dated, null)).getText());
            budgetDate(legacy).setText("2028-03-12");
            assertTrue(Arrays.stream(legacy.getComponents())
                    .anyMatch(c -> c instanceof JLabel label && label.getText().contains("March 2028")));
        });
    }

    private static JTextField budgetDate(BudgetForm form) {
        return Arrays.stream(form.getComponents()).filter(JLabel.class::isInstance).map(JLabel.class::cast)
                .filter(label -> "Budget date".equals(label.getText()))
                .map(label -> (JTextField) label.getLabelFor()).findFirst().orElseThrow();
    }

    @Test void enterOpensDetailsOnlyWhenARowIsSelected() throws Exception {
        SwingUtilities.invokeAndWait(() -> {
            JTable table = new JTable(new Object[][]{{"Groceries"}}, new String[]{"Category"});
            JButton details = new JButton(), edit = new JButton(), delete = new JButton();
            AtomicInteger opens = new AtomicInteger();
            details.addActionListener(event -> opens.incrementAndGet());
            FinanceTables.bindRowActions(table, details, edit, delete);
            Object key = table.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT)
                    .get(KeyStroke.getKeyStroke("ENTER"));
            Action open = table.getActionMap().get(key);
            open.actionPerformed(null);
            assertEquals(0, opens.get());
            table.setRowSelectionInterval(0, 0);
            open.actionPerformed(null);
            assertEquals(1, opens.get());
            table.clearSelection();
            assertFalse(edit.isEnabled());
            assertFalse(delete.isEnabled());
        });
    }
}
